//
//  RatingViewController.swift
//  Adama
//
//  Created by MAD-MAC on 12/09/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class RatingViewController: UIViewController {

    @IBOutlet weak var ratingNumberLbl: UILabel!
    
    @IBOutlet weak var cosmosRatingView: CosmosView!
    
    
     var ticketId:String?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

         self.view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        print(ticketId as Any)
        
        cosmosRatingView.didTouchCosmos = didTouchCosmos
        cosmosRatingView.didFinishTouchingCosmos = didFinishTouchingCosmos
        updateRating()
        
        
        // Do any additional setup after loading the view.
    }
    
    private func updateRating() {
        let value = cosmosRatingView.rating
        self.ratingNumberLbl.text = RatingViewController.formatValue(value)
    }
    
    
    private class func formatValue(_ value: Double) -> String {
        return String(format: "%0.2f", value)
    }
    
    private func didTouchCosmos(_ rating: Double){
        ratingNumberLbl.text = RatingViewController.formatValue(rating)
    }
    
    private func didFinishTouchingCosmos(_ rating: Double){
        self.ratingNumberLbl.text = RatingViewController.formatValue(rating)
    }


    @IBAction func submitBtn(_ sender: Any) {
        
        let userid = UserDefaults.standard.object(forKey:"UserId") as! Int
        
        let params = ["ticket_id":"\(ticketId!)","user_id":"\(userid)","rating_number":"\( ratingNumberLbl.text!)"]
        
        print(params)
        
        Service.shared.POSTService(serviceType: API.addRating, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
            
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                print(message as Any)
                print(responseDetails as Any)
                print(responseDetails["status"] as Any)
                
                if responseDetails["status"] == 200 {
                    
//                    let getData = responseDetails["data"]?.array
//
//                    for getTask in getData!{
//
//                        let name = getTask["name"].string
//                        let Id = getTask["id"].int
//
//                        self.namesArray.append(name!)
//                        self.id.append(Id!)
//                        print(self.namesArray)
//
//                    }
//
//                    self.table.reloadData()
                    
                     self.view.removeFromSuperview()
                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
                    SingleToneClass.shared.dismissProgressLoading(WithDelay: 0.50)
                    
                    
                    
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                     self.view.removeFromSuperview()
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
                
                
            }else{
                 self.view.removeFromSuperview()
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    exit(0)
                    
                }
                
            }
            
            
        }
        
        
        
    }
}

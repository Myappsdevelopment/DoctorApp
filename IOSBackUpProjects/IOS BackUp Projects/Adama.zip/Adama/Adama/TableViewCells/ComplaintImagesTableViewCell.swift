//
//  ComplaintImagesTableViewCell.swift
//  Adama
//
//  Created by MAD-MAC on 17/10/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class ComplaintImagesTableViewCell: UITableViewCell {

    @IBOutlet weak var closeBtn: UIButton!
    
    @IBOutlet weak var ImageNameLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

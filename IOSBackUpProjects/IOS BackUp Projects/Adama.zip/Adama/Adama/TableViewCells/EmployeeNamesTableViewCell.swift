//
//  EmployeeNamesTableViewCell.swift
//  Adama
//
//  Created by MAD-MAC on 11/09/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class EmployeeNamesTableViewCell: UITableViewCell {

    @IBOutlet weak var namesLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//
//  ComplaintListTableViewCell.swift
//  Adama
//
//  Created by MAD-MAC on 18/10/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class ComplaintListTableViewCell: UITableViewCell {

    
    @IBOutlet weak var view: UIView!
    @IBOutlet weak var productLbl: UILabel!
    @IBOutlet weak var ActionLbl: UILabel!
    @IBOutlet weak var sizeLbl: UILabel!
    @IBOutlet weak var zoneLbl: UILabel!
    @IBOutlet weak var batchNoLbl: UILabel!
    @IBOutlet weak var dealerNameLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var assignedBtn: UIButton!
    @IBOutlet weak var rejectedBtn: UIButton!
    @IBOutlet weak var statusAssignedLbl: UILabel!
    @IBOutlet weak var assignedStack: UIStackView!
    @IBOutlet weak var statusCollon: UILabel!
    @IBOutlet weak var assignedCollon: UILabel!
    @IBOutlet weak var currentStatusLbl: UILabel!
    @IBOutlet weak var actionAssignLbl: UILabel!
    
    @IBOutlet weak var natureOfComplaintLbl: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

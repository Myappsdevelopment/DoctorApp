//
//  ComplaintBoxCollectionViewCell.swift
//  Adama
//
//  Created by MAD-MAC on 12/11/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class ComplaintBoxCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageView: UIView!
    @IBOutlet weak var selectedImage: UIImageView!
    
    @IBOutlet weak var deleteBtn: UIButton!
    
}

//
//  ChattingTableViewCell.swift
//  Adama
//
//  Created by MAD-MAC on 18/09/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class ChattingTableViewCell: UITableViewCell {

    @IBOutlet weak var textMessageLbl: UILabel!
    
    @IBOutlet weak var nameLbl: UILabel!
    
    
    @IBOutlet weak var dateLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//
//  KBCollectionViewCell.swift
//  Adama
//
//  Created by MAD-MAC on 10/10/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class KBCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageName: UIImageView!
    
    @IBOutlet weak var imageView: UIView!
}

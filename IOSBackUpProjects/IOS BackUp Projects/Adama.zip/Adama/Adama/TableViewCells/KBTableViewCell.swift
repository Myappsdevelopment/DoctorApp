//
//  KBTableViewCell.swift
//  Adama
//
//  Created by MatrixStream_01 on 30/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class KBTableViewCell: UITableViewCell,UICollectionViewDelegate,UICollectionViewDataSource {

    @IBOutlet weak var plusBtn: UIButton!
    @IBOutlet weak var idLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var collection: UICollectionView!
    @IBOutlet weak var collectionHeight: NSLayoutConstraint!
    
    var get:[getProImg] = []
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        collection.delegate = self
        collection.dataSource = self
        
     //   plusBtn.addTarget(self, action: #selector(self.downArrowTapped(_:)), for: .touchUpInside)
        // Initialization code
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       
        print(get.count)
        return get.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! KBCollectionViewCell
        
        if let url = URL(string: get[indexPath.row].ImageName!) {
        print(url)
            cell.imageName.kf.setImage(with:url)
            cell.imageView?.layer.cornerRadius = 10
            cell.imageView?.layer.borderWidth = 1
            cell.imageView?.layer.borderColor = UIColor.black.cgColor
        }
        //  cell.imageName.image = imageBaseUrl[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {



        let itemsPerRow:CGFloat = 4
        let hardCodedPadding:CGFloat = 5

        let itemWidth = (collectionView.bounds.width / itemsPerRow) - 2 * itemsPerRow

        let itemHeight = (collectionView.bounds.height / 2) - hardCodedPadding



        return CGSize(width: itemWidth, height: itemHeight)

    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

        SingleToneClass.shared.showProgressLoading(title: "File Downloading")
        SingleToneClass.shared.showProgressLoading(WithDelay: 10)

       // let imagestring = String((imagePath) +  ((get?.attachfiles[indexPath.row].file_name)!))
      //  print(imagestring)



        if let url = URL(string: get[indexPath.row].ImageName!),
            let data = try? Data(contentsOf: url),
            let image = UIImage(data: data)
        {
            UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
           // SingleToneClass.shared.dismissProgressLoading()
            //SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "File Saved In PhotoGallery") {
          // SingleToneClass.shared.dismissProgressLoading(WithDelay: 10)
            SingleToneClass.shared.dismissProgressLoadingWithSucess(message: "File Saved")

              //  self.navigationController?.popViewController(animated: true)

            
        }







    }
    
    
    
}

//
//  ReportsTableViewCell.swift
//  Adama
//
//  Created by MAD-MAC on 26/12/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class ReportsTableViewCell: UITableViewCell {

    
    @IBOutlet weak var detailsView: UIView!
    
    @IBOutlet weak var ticketLbl: UILabel!
    
    @IBOutlet weak var assignFromLbl: UILabel!
    
    
    @IBOutlet weak var assignToLbl: UILabel!
    
    
    @IBOutlet weak var assignDateLbl: UILabel!
    
    
    @IBOutlet weak var firstAssignLbl: UILabel!
    
    
    @IBOutlet weak var reAssignLbl: UILabel!
    
    
    @IBOutlet weak var priorityLbl: UILabel!
    
    
    @IBOutlet weak var statusLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

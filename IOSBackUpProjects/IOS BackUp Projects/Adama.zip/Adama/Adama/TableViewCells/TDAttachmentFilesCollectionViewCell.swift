//
//  TDAttachmentFilesCollectionViewCell.swift
//  Adama
//
//  Created by MAD-MAC on 17/12/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class TDAttachmentFilesCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageDisplayView: UIView!
    
    
    @IBOutlet weak var imageDisplay: UIImageView!
    
    @IBOutlet weak var cancelBtn: UIButton!
    
    
}

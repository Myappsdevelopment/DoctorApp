//
//  TDCollectionViewCell.swift
//  Adama
//
//  Created by MAD-MAC on 18/11/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class TDCollectionViewCell: UICollectionViewCell {
    
    
 
    
    
    @IBOutlet weak var imageDisplayView: UIView!
    @IBOutlet weak var DisplayImage: UIImageView!
    
    @IBOutlet weak var downloadBtn: UIButton!
    
    
    @IBOutlet weak var countLbl: UILabel!
    
    
    @IBOutlet weak var nameLbl: UILabel!
    
    
    
    
}

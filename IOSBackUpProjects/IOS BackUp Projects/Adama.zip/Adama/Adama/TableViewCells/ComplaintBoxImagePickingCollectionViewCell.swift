//
//  ComplaintBoxImagePickingCollectionViewCell.swift
//  Adama
//
//  Created by MAD-MAC on 21/11/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class ComplaintBoxImagePickingCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageDisplayView: UIView!
    
    @IBOutlet weak var imageDisplay: UIImageView!
    
    @IBOutlet weak var imageNameDisplayLbl: UILabel!
    
    @IBOutlet weak var cancelBtn: UIButton!
    
}

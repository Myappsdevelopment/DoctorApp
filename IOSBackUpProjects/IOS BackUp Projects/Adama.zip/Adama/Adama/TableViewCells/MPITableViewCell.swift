//
//  MPITableViewCell.swift
//  Adama
//
//  Created by MatrixStream_01 on 30/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class MPITableViewCell: UITableViewCell {

  
   
    
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var taskId: UILabel!
    @IBOutlet weak var intiateDateStackView: UIStackView!
    @IBOutlet weak var intiatedLbl: UILabel!
    @IBOutlet weak var view2Height: NSLayoutConstraint!
    @IBOutlet weak var firstAssignLbl: UILabel!
    @IBOutlet weak var view3Height: NSLayoutConstraint!
    @IBOutlet weak var hideView: UIView!
    @IBOutlet weak var hide2View: UIView!
    @IBOutlet weak var intiateStackView: UIStackView!
    @IBOutlet weak var assignToBtn: UIButton!
    
    @IBOutlet weak var priorityLbl: UILabel!
    @IBOutlet weak var categoryLbl: UILabel!
    @IBOutlet weak var intiatedDateLbl: UILabel!
    @IBOutlet weak var firstAssignNameLbl: UILabel!
    @IBOutlet weak var priorityStatusLbl: UILabel!
    @IBOutlet weak var currentStatusLbl: UILabel!
    @IBOutlet weak var plusBtn: UIButton!
    @IBOutlet weak var issueSCLbl: UILabel!
    @IBOutlet weak var cellView: UIView!
    
    @IBOutlet weak var actionLbl: UILabel!
    @IBOutlet weak var descriptionLbl: UILabel!
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }


    
    }


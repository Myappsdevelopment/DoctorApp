//
//  NTVCollectionViewCell.swift
//  Adama
//
//  Created by MAD-MAC on 06/11/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class NTVCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var SelectedImage: UIImageView!
    
    @IBOutlet weak var deleteBtn: UIButton!
    @IBOutlet weak var imageView: UIView!
    
    @IBOutlet weak var imageNameLbl: UILabel!
    override func awakeFromNib() {
        SelectedImage.layer.cornerRadius = 5
        SelectedImage.clipsToBounds = true
    }
    
}

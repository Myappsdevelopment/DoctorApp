//
//  NTVTableViewCell.swift
//  Adama
//
//  Created by Raju Matta on 17/09/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class NTVTableViewCell: UITableViewCell {

    @IBOutlet weak var imageNameLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

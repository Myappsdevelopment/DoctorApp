//
//  TDKnowledgeBaseCollectionViewCell.swift
//  Adama
//
//  Created by MAD-MAC on 04/12/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class TDKnowledgeBaseCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imagedisplayView: UIView!
    
    
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var downloadBtn: UIButton!
    
    @IBOutlet weak var countLbl: UILabel!
    
    @IBOutlet weak var nameLbl: UILabel!
    
    
    
    
    
}

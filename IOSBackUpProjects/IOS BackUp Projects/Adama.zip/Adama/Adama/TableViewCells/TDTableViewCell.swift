//
//  TDTableViewCell.swift
//  Adama
//
//  Created by MAD-MAC on 18/11/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class TDTableViewCell: UITableViewCell {

    
  
    
    @IBOutlet weak var imageDisplayView: UIView!
    
    @IBOutlet weak var displayImage: UIImageView!
    
    
    
    @IBOutlet weak var DeleteBtn: UIButton!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

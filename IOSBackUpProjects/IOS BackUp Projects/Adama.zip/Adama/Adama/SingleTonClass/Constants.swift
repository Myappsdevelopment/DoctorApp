//
//  Constants.swift
//  VaniInstitute
//
//  Created by Raju Matta on 03/01/19.
//  Copyright © 2019 VaniInstitute. All rights reserved.
//

import Foundation

class Constants{
    
 //  static var baseUrl = "http://3.83.246.139/adama/api/"
    static var baseUrl = "http://adama-lb-934848189.ap-south-1.elb.amazonaws.com/api/"
    
}
struct API {
    
    static var login = Constants.baseUrl + "login"
    static var forgot = Constants.baseUrl + "forgot_password"
    static var OTP = Constants.baseUrl + "verify_otp"
    static var confirmPassword = Constants.baseUrl + "reset_password"
    static var changePassword = Constants.baseUrl + "change_password"
    static var dashBoard = Constants.baseUrl + "dashboard"
    static var selectDepartment = Constants.baseUrl + "get_department"
    static var getSubDepartment =  Constants.baseUrl + "get_subdepartment"
    static var getSubSubDepartment = Constants.baseUrl + "get_sub_subdepartment"
    static var addTask = Constants.baseUrl + "add_newtask"
    static var addTicket = Constants.baseUrl + "add_newticket"
    static var listingTask = Constants.baseUrl + "task_listing"
    static var listingTicket = Constants.baseUrl + "ticket_listing"
    static var updateProfile = Constants.baseUrl + "update_profile"
    static var employeeList = Constants.baseUrl + "employee_list"
    static var assignTicket = Constants.baseUrl + "assign_ticket"
    static var assignTask = Constants.baseUrl + "assign_task"
    static var addRating = Constants.baseUrl + "add_rating"
    static var getKnowledgeResolution = Constants.baseUrl + "get_knowledge_resolution"
    static var product = Constants.baseUrl + "products"
    static var productSize = Constants.baseUrl + "productsize"
    static var zone = Constants.baseUrl + "zones"
    static var addComplaint = Constants.baseUrl + "add_camplaint"
    static var listComplaintS = Constants.baseUrl + "list_camplaints"
    static var updateTicketStatus = Constants.baseUrl + "update_ticket_status"
    static var addTicketComment = Constants.baseUrl + "add_ticket_comment"
    static var getTicketComment = Constants.baseUrl + "get_ticket_comment"
    static var submitTicket =  Constants.baseUrl + "list_createdticket"
    static var listNotifications = Constants.baseUrl + "list_notification"
    static var assignComplaint = Constants.baseUrl + "assign_complaint"
    static var addKnowledge = Constants.baseUrl + "add_know ledge"
    static var deleteNotifications = Constants.baseUrl + "delete_notification"
    static var addResolutionNote = Constants.baseUrl + "add_resolution_note"
    static var submittedComplaint = Constants.baseUrl + "list_submitted_complaints"
    static var assignedComplaintlist = Constants.baseUrl + "list_assing_complaints"
    static var getComplaintComments = Constants.baseUrl + "get_complain_comments"
    static var addComplaintComments = Constants.baseUrl + "add_complain_comment"
    static var dashboardticketsList = Constants.baseUrl + "ticketlist"
    static var Reports = Constants.baseUrl + "generate_report"
    static var chatHistory = Constants.baseUrl + "chat_history"
    static var complaintReports = Constants.baseUrl + "report_customer_complain"
}


struct DetailsStore {
 //   static var loginDetails:[String:Any] = [:]  //memory is allocated
    static var loginDetails : [String:Any]? // memory not allocated

    static  var page:Bool?
    
    static var pending:Bool?
    static var resolved:Bool?
    static var highPriority:Bool?
    static var overdue:Bool?
    static var unassigned:Bool?
    static var reassigned:Bool?
    
    static var resolution:Bool?
    static var submittedComplaint:Bool?
    static var assignedComplaint:Bool?
    static var customerComplaint:Bool?
    static var homeTicketDettails:Bool?
    static var allTickets:Bool?
    static var assignedTickets:Bool?
    static var submittedTickets:Bool?
    static var backGroundColor:Bool?
    static var camera:Bool?
    static var ticketdetails:Bool?
    
    
   static var ticket:Bool?
   static var dashboard:Bool?
   static var knowledgeBase:Bool?
   static var profile:Bool?
   static var changePassword:Bool?
   static var customerComplaintSideMenu:Bool?
   static var assignedComplaintSideMenu:Bool?
   static var submittedComplaintSideMenu:Bool?
   static var notification:Bool?
   static var reports:Bool?
   static var complaintReports:Bool?

}


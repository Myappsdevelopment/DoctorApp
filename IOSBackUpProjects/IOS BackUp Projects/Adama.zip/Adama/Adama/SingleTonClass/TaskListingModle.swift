//
//  TaskListingModle.swift
//  Adama
//
//  Created by Raju Matta on 05/09/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import Foundation

struct TaskList {
   static var selectedIndex:Int?

    var assingFrom:[AssignFrom] = []
    var assignTo:[AssignTo] = []
    var firstuser:[FirstUser] = []
    var reassignuser:[ReAssignUser] = []
    var attachfiles:[AttachFiles] = []
    var knowledgeBaseFiles:[KnowledgeBaseFiles] = []
    var assign_date:String?
    var first_assignid:Int?
    var re_assignid:Int?
    var priority:Int?
    var c_status:Int?
    var created_at:String?
    var id:Int?
    var searchId:String?
    var description:String?
    var total_rating:Int?
    var issueSubCategory:[IssueSubCategory] = []
    var subsubdepartment:[SubSubDepartment] = []
    var creator_mobile:String?
    var creator_email:String?
}


struct AttachFiles {
    var file_name:String?
    var ticket_id:Int?
    var id:Int?
    
    
    static var getattachments:[AttachFiles] = []
    static var baseImagePath:String?
    static var photoArray = [Data]()
    static var selectedAssets=[String]()
}



struct KnowledgeBaseFiles {
    
    var ticket_id:Int?
    var id:Int?
    var path:String?
    var note_file:String?
    
    
}


struct AssignFrom {
    
    var id:Int?
    var dName:String?
    
}

struct IssueSubCategory {
    var id:Int?
    var Name:String?
}

struct AssignTo {
    var id:Int?
    var dName:String?
}

struct FirstUser {
    var id:Int?
    var name:String?
}


struct ReAssignUser {
    var id:Int?
    var name:String?
}


struct SubSubDepartment{
    var id:Int?
    var name:String?
}

struct Message {
    
    let message: String
    
    init(author: String, message: String) {
        
        self.message = message
    }
}


struct Products {
    var studentImage:[getProImg] = []
    init(){}
}

struct getProImg {
    var ImageName:String?
}


struct Ids {
   // static var shared = Ids()
     static var departmentIds = Int()
    static var subDepartmentIds = Int()
    static var categoryIds = String()
    static var subCategoryIds = Int()
    static var priorityIds = String()
    init() {
        
    }
}



struct ProductDetails {
    var id:Int?
    var name:String?
    init(){}
}
struct Chat {
    var emp:[Emp]? = []
    var usr:[User] = []
}

struct Emp {
    var date:String?
    var message:String?
    var id:Int?
    var empName:[EmpName] = []
}
struct User {
    var date:String?
    var message:String?
    var id:Int?
    var usrName:[UsrName] = []


}

struct EmpName {
    var name:String?
}

struct UsrName {
    var name:String?
}

struct Priority {
    var id:Int?
    var name:String?
    init() {}
}

struct nature {
    var id:Int?
    var name:String?
    init() {}
}

//
//  shared.swift
//  Mahendra logistics
//
//  Created by VamsiKrishna on 7/13/18.
//  Copyright © 2018 HJSoftware. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON
import EVReflection

class Service{
    
    static let shared=Service()
    init() {
    }
    
    
    
    func GETService(extraParam : String, onTaskCompleted : @escaping (JSON)->(Void) ) {
        
        print(extraParam)
        
        let header = ["Content-Type" : "application/json"]
        guard let url = URL(string: "\(extraParam)") else { return }
        //  Alamofire.request(url, method: .get,encoding:JSONEncoding.default, headers: header).responseJSON
        Alamofire.request(url, method: .get,encoding:JSONEncoding(options: []), headers: header).responseJSON
            { response in
                
                print(response)
                
                let jsonData = JSON(response.result.value as Any)
                onTaskCompleted(jsonData)
        }
    }
    
    
    func POSTService(serviceType : String,parameters : [String:String], onTaskCompleted : @escaping (JSON)->(Void)) {
        print(serviceType)
        guard let url = URL(string: "\(serviceType)") else { return }
        print(parameters)
        
        
        let header = ["Content-Type": "application/json"]
        
        
        //        Alamofire.request(url, method: .post, parameters: parameters,headers: header).responseJSON{ response in
        
        Alamofire.request(url, method: .post, parameters: parameters,encoding:JSONEncoding(options: []), headers: header).responseJSON{ response in
            
            switch response.result {
            case .success(let value):
                let jsonData = JSON(response.result.value as Any)
                onTaskCompleted(jsonData)

            case .failure(let error):
                debugPrint(error.localizedDescription)
                SingleToneClass.shared.dismissProgressLoadingWithError(message: "Server problem")
                SingleToneClass.shared.dismissProgressLoading(WithDelay: 5)
            }
            print(response)
            
        }
    }
    
    
    
    func makeUploadRequest(serviceType : String,parameters : [String:Any], completion: @escaping (JSON) -> ()) {
        
        guard let url = URL(string: "\(serviceType)") else { return }
        
        let manager = Alamofire.SessionManager.default
        manager.session.configuration.timeoutIntervalForRequest = 180
        
        manager.upload(multipartFormData: { multipartFormData in
            multipartFormData.parameter(with: parameters)
            
        }, to: url, method: .post, headers: nil, encodingCompletion: { encodingResult in
            
            switch encodingResult {
            case .success(let request, _, _):
                request.responseJSON(completionHandler: { (response) in
                    switch response.result {
                    case .success(let value):
                        let jsonData = JSON(response.result.value as Any)
                        completion(jsonData)
                        print(jsonData)
                    case .failure(let error):
                        debugPrint(error.localizedDescription)
                    }
                })
                
                request.uploadProgress(closure: { (progress) in
                    print("Upload Progress: \(progress.fractionCompleted)")
                })
                
            case .failure(let error):
                debugPrint(error.localizedDescription)
                break
            }
        })
    }
 
    func makeUploadRequest1(serviceType : String,parameters : [String:Any], completion: @escaping (JSON) -> ()) {
        
        
        guard let url = URL(string: "\(serviceType)") else { return }
        print(url)
        let manager = Alamofire.SessionManager.default
        manager.session.configuration.timeoutIntervalForRequest = 180
        
        manager.upload(multipartFormData: { multipartFormData in
            multipartFormData.parameter1(with: parameters)
            
        }, to: url, method: .post, headers: nil, encodingCompletion: { encodingResult in
            
            switch encodingResult {
            case .success(let request, _, _):
                request.responseJSON(completionHandler: { (response) in
                    switch response.result {
                    case .success(let value):
                        let jsonData = JSON(response.result.value as Any)
                        completion(jsonData)
                        
                    case .failure(let error):
                        debugPrint(error.localizedDescription)
                    }
                })
                
                request.uploadProgress(closure: { (progress) in
                    print("Upload Progress: \(progress.fractionCompleted)")
                })
                
            case .failure(let error):
                debugPrint(error.localizedDescription)
                break
            }
        })
    }
    

    
}



struct AGImageInfo {
    var fileName: String
    var type: AGContentMIME
    var data: Data
}

enum AGContentMIME: String {
    case png = "image/png"
    case video = "mov"
    case pdf = "pdf"
    
}

struct AGImageUpdate {
    var fileName: String
    var type: String
    var data: Data
}

extension MultipartFormData {
    var timestamp: String {
        return "\(NSDate().timeIntervalSince1970 * 1000)"
    }
    
    func parameter(with parameters: Parameters){
        for param in parameters {
            if let agImageInfo = param.value as? AGImageInfo {
                append(agImageInfo.data, withName: param.key, fileName: agImageInfo.fileName, mimeType: agImageInfo.type.rawValue)
            }
            else{
                
                if let str = param.value as? String, let convertedValue = str.data(using: String.Encoding.utf8) {
                    append(convertedValue, withName: param.key)
                }
                else if let number = param.value as? NSNumber, let data = "\(number)".data(using: String.Encoding.utf8){
                    append(data, withName: param.key)
                }
                else if let data = (param.value as AnyObject).data(using: String.Encoding.utf8.rawValue) {
                    append(data, withName: param.key)
                }
                else{
                    append("\(param.value)".data(using: String.Encoding.utf8)!, withName: param.key)
                }
            }
        }
    }
    
    
    func parameter1(with parameters: Parameters){
        for param in parameters {
            if let agImageInfo = param.value as? [AGImageUpdate] {
                
                
                for i in 0..<agImageInfo.count{
                    
                    
                    append(agImageInfo[i].data, withName: param.key, fileName: agImageInfo[i].fileName, mimeType: agImageInfo[i].type)
                    
                }
                
            }
            else{
                
                if let str = param.value as? String, let convertedValue = str.data(using: String.Encoding.utf8) {
                    append(convertedValue, withName: param.key)
                }
                else if let number = param.value as? NSNumber, let data = "\(number)".data(using: String.Encoding.utf8){
                    append(data, withName: param.key)
                }
                else if let data = (param.value as AnyObject).data(using: String.Encoding.utf8.rawValue) {
                    append(data, withName: param.key)
                }
                else{
                    append("\(param.value)".data(using: String.Encoding.utf8)!, withName: param.key)
                }
            }
        }
    }
    
    
    
    
    
}




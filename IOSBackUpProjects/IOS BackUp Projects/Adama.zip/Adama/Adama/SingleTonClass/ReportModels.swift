//
//  ReportModels.swift
//  Adama
//
//  Created by MAD-MAC on 26/12/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import Foundation


struct reports {
    
    var TicketId : String?
    var assignFrom : String?
    var assignTo : String?
    var assignDate : String?
    var firstAssign : String?
    var reAssign : String?
    var priority : String?
    var status : String?
    var submittedDate : String?
    var submittedByEmployeeId : String?
    var submittedByName : String?
    var issueCategory : String?
    var issueSubCategory : String?
    var resolvedDate : String?
    
    
}


struct complaintReports {
    
    var zone : String?
    var product : String?
    var date : String?
    var size : String?
    var dealerName : String?
    var batchNo : String?
    var status : String?

}




struct chat {
    var ticketId : String?
    var name : String?
    var comments : String?
}


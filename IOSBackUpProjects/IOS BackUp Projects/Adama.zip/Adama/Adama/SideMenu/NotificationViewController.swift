//
//  NotificationViewController.swift
//  Adama
//
//  Created by MAD-MAC on 19/10/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class NotificationViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    @IBOutlet weak var sideMenuBtn: UIBarButtonItem!
    @IBOutlet weak var table: UITableView!
    @IBOutlet weak var noDataImage: UIImageView!
    @IBOutlet weak var clearAllBarBtn: UIBarButtonItem!
    
    let userId = UserDefaults.standard.object(forKey: "UserId") as! Int
    let loginDepartmentId = UserDefaults.standard.object(forKey: "DepartmentId") as! Int
    
    
    var messageArray = [String]()
    var dateArray = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

  
    
        clearAllBarBtn.isEnabled = false
        self.navigationController?.isNavigationBarHidden = false
        self.title = "Notification"
        
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white
        
        
      
        
        notificationList()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func clearAllBtn(_ sender: Any) {
        
        
        let alert = UIAlertController(title: "LOGOUT", message: "Are you sure,you want to remove all Notifications?", preferredStyle: .alert)
        
        
        
        alert.addAction(UIAlertAction(title: "Yes", style: .cancel, handler: { (confirmAction) in
            
            self.removeNotifications()
            
            
        }))
        
        
        alert.addAction(UIAlertAction(title: "No", style: .default, handler: { (cancelAction) in }))
        
        
        present(alert, animated: true, completion: nil)
        
        
        
        
        
    }
    
    
    
    
    func removeNotifications () {
        
        
        SingleToneClass.shared.showProgressLoading(title: "Please Wait")
        
        let params = ["user_id":"\(userId)","login_department_id":"\(loginDepartmentId)"] as [String : Any]
        print(params)
        
        Service.shared.POSTService(serviceType: API.deleteNotifications, parameters: params as! [String : String] ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            print(responseDetails as Any)
            
            if responseDetails["status"] == "200" {
                
                self.messageArray.removeAll()
                self.dateArray.removeAll()
                self.table.reloadData()
                
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
                SingleToneClass.shared.dismissProgressLoading(WithDelay: 10)
                
                
                
                
            }else if responseDetails["status"] == 419 {
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) {
                    exit(0)
                }
                
            } else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
                self.table.isHidden = true
                self.noDataImage.isHidden = false
            }
            
        }
        
    }
    
    

    
    func notificationList ()  {
        
        
       
        
        let params = ["department_id":"\(loginDepartmentId)","user_id":"\(userId)","login_department_id":"\(loginDepartmentId)"] as [String : Any]
        print(params)
        
        Service.shared.POSTService(serviceType: API.listNotifications, parameters: params as! [String : String] ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["success"]?.string
            print(message as Any)
            print(responseDetails as Any)
            
            if responseDetails["success"] == "Notification List." {
                
                 let data = responseDetails["data"]?.array
                    
                
                    
                if data?.isEmpty == true {
                    self.table.isHidden = true
                    self.noDataImage.isHidden = false
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Data Not Found") { }
                   
                 
                   
                }else{
                     self.clearAllBarBtn.isEnabled = true
                    self.table.isHidden = false
                    self.noDataImage.isHidden = true
                 
                
                    for i in data!{
                        let message = i ["message"].string
                      //  let date = i["updated_at"].string
                       
                        let resultDate = i["updated_at"].string
                        
                        let dateFormatterGet = DateFormatter()
                        dateFormatterGet.dateFormat = "yyyy-MM-dd HH:mm:ss"
                        
                        let dateFormatterPrint = DateFormatter()
                        dateFormatterPrint.dateFormat = "dd-MM-yyyy"
                        
                        if let date = dateFormatterGet.date(from: resultDate!) {
                            let dates = dateFormatterPrint.string(from: date)
                            // DetailsStore.endDate = self.endDateTF.text!
                            self.dateArray.append(dates)
                        }
                        
                        
                        
                        self.messageArray.append(message!)
                        print(self.messageArray)
//                        self.dateArray.append(date!)
//                        print(self.dateArray)
                       
                
                        
                    }
                    
                    self.table.reloadData()
                    
                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
                    SingleToneClass.shared.dismissProgressLoading(WithDelay: 10)
                    
                }
                
                
            }else if responseDetails["status"] == 419 {
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) {
                    exit(0)
                }
                
            } else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
                self.table.isHidden = true
                self.noDataImage.isHidden = false
            }
            
        }
        
        
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messageArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for:indexPath) as! NotificationsTableViewCell
        
//let gray1 = UIColor(red: 247/255, green: 247/255, blue: 247/255, alpha: 1.0)
        cell.dateLbl.text = dateArray[indexPath.row]
        cell.textLbl.text = messageArray[indexPath.row]
        
        cell.cellView.layer.cornerRadius = 10
        cell.cellView.clipsToBounds = true
        cell.cellView.layer.borderWidth = 0.3
        cell.cellView.layer.borderColor = UIColor.black.cgColor
        
        return cell
    }
    

}

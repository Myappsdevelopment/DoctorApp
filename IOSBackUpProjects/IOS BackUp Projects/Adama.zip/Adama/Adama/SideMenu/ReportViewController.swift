//
//  ReportViewController.swift
//  Adama
//
//  Created by MAD-MAC on 23/12/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import CoreXLSX

class ReportViewController: UIViewController,UITextFieldDelegate,UIPickerViewDelegate,UIPickerViewDataSource,UIDocumentInteractionControllerDelegate {


    @IBOutlet weak var fromDateTF: UITextField!
    @IBOutlet weak var ToDateTF: UITextField!
    @IBOutlet weak var currentStatusTF: TextField!
    @IBOutlet weak var submitBtn: UIButton!
    
  
    
    
    var reportList:[reports] = []
    var complaintList:[complaintReports] = []
    var reportDetails : reports!
    var complaintDetails : complaintReports!
    
    let picker = UIPickerView()
    let toolBar = UIToolbar()
    var selectedTF = UITextField()
    
    let datepicker=UIDatePicker()
    let currentDate = Date()
    let finalFormatter = DateFormatter()
   
    var cStatus = String()
    let currentStatus = ["All","Pending","Overdue","Resolved","Reopen"]
    
    let userId = UserDefaults.standard.object(forKey: "UserId") as! Int
    let loginDepartmentId = UserDefaults.standard.object(forKey: "DepartmentId") as! Int
    
    

    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        if DetailsStore.reports == true {
            self.navigationItem.title = "Reports"
        }else if DetailsStore.complaintReports == true {
            self.navigationItem.title = "ComplaintReport"
        }
        
        
        
        self.navigationController?.isNavigationBarHidden = false
        
     
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.tabBarController?.tabBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white
        
        
        fromDateTF.delegate = self
        ToDateTF.delegate = self
        currentStatusTF.delegate = self
        picker.delegate = self
        picker.dataSource = self
        
        
        submitBtn.layer.cornerRadius = 10
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }

        
        createPicker()
        
        // Do any additional setup after loading the view.
    }
    

    
    func createPicker() {
        
        
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
       // self.ToDateTF.text = dateFormatter.string(from: currentDate)
        
        datepicker.datePickerMode = .date
        datepicker.setDate(Date(), animated: true)
        
        let pickerView = picker
        pickerView.backgroundColor = .white
        pickerView.showsSelectionIndicator = true
        
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action:#selector(donePicker))
        doneButton.tintColor = UIColor.black
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action:#selector(canclePicker))
        cancelButton.tintColor = UIColor.black
        //datepicker.addTarget(self, action: #selector(datePickerValueChange), for:.valueChanged )
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.barTintColor = .white
        
        
        let calendar = NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian);
        
        let components = calendar?.components([NSCalendar.Unit.year,NSCalendar.Unit.month,NSCalendar.Unit.day,NSCalendar.Unit.hour,NSCalendar.Unit.minute], from: currentDate )
        
        let maximumYear = (components?.year)!
        print(maximumYear)
        let maximumMonth = (components?.month)!
        let maximumDay = (components?.day)!
        
        let comps = NSDateComponents()
        comps.year = +maximumYear
        comps.month = +maximumMonth
        comps.day = +maximumDay
        print(comps.day)
        
        
       // datepicker.minimumDate = currentDate
        
        
        self.fromDateTF.inputView = datepicker
        self.fromDateTF.inputAccessoryView = toolBar
        
        self.ToDateTF.inputView = datepicker
        self.ToDateTF.inputAccessoryView = toolBar
        
        self.currentStatusTF.inputView = pickerView
        self.currentStatusTF.inputAccessoryView = toolBar
        
    }
    
    
    
    
    @objc func donePicker() {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        
        
        if selectedTF == self.fromDateTF {
            
            self.fromDateTF.text = dateFormatter.string(from: datepicker.date)
            self.fromDateTF.resignFirstResponder()
        
        }else if selectedTF == self.ToDateTF {
            self.ToDateTF.text = dateFormatter.string(from: datepicker.date)
            self.ToDateTF.resignFirstResponder()
        }else if selectedTF == self.currentStatusTF{
            self.currentStatusTF.text = currentStatus[picker.selectedRow(inComponent: 0)]
            self.currentStatusTF.resignFirstResponder()
        }
        
        
    }
    
    @objc func canclePicker() {
        
        self.selectedTF.resignFirstResponder()
        
    }
    
    
    
    @IBAction func submitBtn(_ sender: Any) {
        
        if !fromDateTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select From Date") {
                self.fromDateTF.becomeFirstResponder()
            }
        
        }else if !ToDateTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select To Date") {
                self.ToDateTF.becomeFirstResponder()
            }
        }else if !currentStatusTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select CurrentStatus") {
                self.currentStatusTF.becomeFirstResponder()
            }
        }else{
            SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
         
            if DetailsStore.reports == true {
                ReportService()
            }else if DetailsStore.complaintReports == true {
                ComplaintService()
            }
        }

    }
    
    
    func ReportService() {
           
           if currentStatusTF.text == "All" {
               cStatus = "all"
           }else if currentStatusTF.text == "Pending" {
               cStatus = "0"
           }else if currentStatusTF.text == "Overdue" {
               cStatus = "1"
           }else if currentStatusTF.text == "Resolved" {
               cStatus = "2"
           }else if currentStatusTF.text == "Reopen" {
               cStatus = "3"
           }
           
           
           
                   let f = fromDateTF.text!
                   let t = ToDateTF.text!
           
                   let dateFormatter = DateFormatter()
                   dateFormatter.dateFormat = "dd-MM-yyyy"
           
                   let showDate = dateFormatter.date(from: f)
                   let showDate2 = dateFormatter.date(from: t)
           
                    dateFormatter.dateFormat = "yyyy-MM-dd"
           
                   let fromDate = dateFormatter.string(from: showDate!)
                   let toDate = dateFormatter.string(from: showDate2!)

           let params = ["user_id":"\(userId)","login_department_id":"\(loginDepartmentId)","from_date":fromDate,"to_date":toDate,"c_status":cStatus] as [String : Any]
           print(params)
           
           Service.shared.POSTService(serviceType: API.Reports, parameters: params as! [String : String] ) { (response) -> (Void) in
               
               print(response)
               SingleToneClass.shared.dismissProgressLoading()
               guard let responseDetails = response .dictionary else{return}
               
               let message = responseDetails["message"]?.string
               print(message as Any)
               print(responseDetails as Any)
               
               if responseDetails["status"] == 200 {
                   
                   
                   let data = responseDetails["data"]?.array
                  // self.table.isHidden = false
                   
                   self.fromDateTF.text = ""
                   self.ToDateTF.text = ""
                   self.currentStatusTF.text = ""
                   self.reportDetails = reports()
                   
                   
                   for i in data! {
             
                    
                       self.reportDetails.TicketId = i["ticket_id"].string
                       self.reportDetails.assignFrom = i["assign_from"].string
                       self.reportDetails.assignTo = i["assign_to"].string
                       self.reportDetails.assignDate = i["assign_date"].string
                       self.reportDetails.firstAssign = i["first_assign"].string
                       self.reportDetails.reAssign = i["reassign"].string
                       self.reportDetails.priority = i["priority"].string
                       self.reportDetails.status = i["status"].string
                       self.reportDetails.submittedDate = i["submitted_date"].string
                       self.reportDetails.submittedByEmployeeId = i["submitted_empid"].string
                       self.reportDetails.submittedByName = i["submitted_name"].string
                       self.reportDetails.issueCategory = i["category"].string
                       self.reportDetails.issueSubCategory = i["subcategory"].string
                       self.reportDetails.resolvedDate = i["resloved_date"].string
                       
                       
                       
                       self.reportList.append(self.reportDetails)
                       self.creatCSV()
                   }
                 
                   
               }else if responseDetails["status"] == 419 {
                   
                   SingleToneClass.shared.dismissProgressLoading()
                   SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) {
                       exit(0)
                   }
                   
               } else{
                   
                   SingleToneClass.shared.dismissProgressLoading()
                   SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
                  
               }
               
           }
           
           
           
           
       }
       
       
       
       func creatCSV() -> Void {
      
           let fileName = getDocumentsDirectory().appendingPathComponent("\(self.fromDateTF.text!)-\(self.ToDateTF.text!).csv")
       
           var csvText = "TicketId,AssignFrom,AssignTo,AssignDate,FirstAssign,ReAssign,Priority,Status,SubmittedDate,SubmittedByEmployeeId,SubmittedByName,IssueCategory,IssueSubCategory,ResolvedDate\n"
           
           for reportDetails in reportList {
               let newLine = "\(String(describing: reportDetails.TicketId!)),\(String(describing: reportDetails.assignFrom!)),\(String(describing: reportDetails.assignTo!)),\(String(describing: reportDetails.assignDate!)),\(String(describing: reportDetails.firstAssign!)),\(String(describing: reportDetails.reAssign!)),\(String(describing: reportDetails.priority!)),\(String(describing: reportDetails.status!)),\(String(describing: reportDetails.submittedDate!)),\(String(describing: reportDetails.submittedByEmployeeId!)),\(String(describing: reportDetails.submittedByName!)),\(String(describing: reportDetails.issueCategory!)),\(String(describing: reportDetails.issueSubCategory!)),\(String(describing: reportDetails.resolvedDate!)),\n"
               csvText.append(newLine)
           }
           
           do {
               try csvText.write(to: fileName, atomically: true, encoding: String.Encoding.utf8)
           
             
              
           } catch {
               print("Failed to create file")
               print("\(error)")
           }
          
           SingleToneClass.shared.dismissProgressLoading()
           SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "File Saved In Iphone/Files/Adama") {
               
             
           }
       }


    
    func ComplaintService ()  {
        
        if currentStatusTF.text == "All" {
            cStatus = "all"
        }else if currentStatusTF.text == "Pending" {
            cStatus = "0"
        }else if currentStatusTF.text == "Overdue" {
            cStatus = "1"
        }else if currentStatusTF.text == "Resolved" {
            cStatus = "2"
        }else if currentStatusTF.text == "Reopen" {
            cStatus = "3"
        }
        
        
        
                let f = fromDateTF.text!
                let t = ToDateTF.text!
        
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "dd-MM-yyyy"
        
                let showDate = dateFormatter.date(from: f)
                let showDate2 = dateFormatter.date(from: t)
        
                 dateFormatter.dateFormat = "yyyy-MM-dd"
        
                let fromDate = dateFormatter.string(from: showDate!)
                let toDate = dateFormatter.string(from: showDate2!)

        let params = ["user_id":"\(userId)","login_department_id":"\(loginDepartmentId)","from_date":fromDate,"to_date":toDate,"c_status":cStatus] as [String : Any]
        print(params)
        
        Service.shared.POSTService(serviceType: API.complaintReports, parameters: params as! [String : String] ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            print(responseDetails as Any)
            
            if responseDetails["status"] == 200 {
                
                
                let data = responseDetails["data"]?.array
               // self.table.isHidden = false
                
                self.fromDateTF.text = ""
                self.ToDateTF.text = ""
                self.currentStatusTF.text = ""
                self.complaintDetails = complaintReports()
                
                
                for i in data! {
          
                 
                    self.complaintDetails.zone = i["zone"].string
                    self.complaintDetails.product = i["product"].string
                    self.complaintDetails.date = i["date"].string
                    self.complaintDetails.size = i["size"].string
                    self.complaintDetails.dealerName = i["dealer_name"].string
                    self.complaintDetails.batchNo = i["batch_no"].string
                    self.complaintDetails.status = i["status"].string
                   
                    
                    
                    
                    self.complaintList.append(self.complaintDetails)
                    self.creatCSV1()
                }
              
                
            }else if responseDetails["status"] == 419 {
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) {
                    exit(0)
                }
                
            } else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
               
            }
            
        }
        
        
        
        
    }
    
    
    
    func creatCSV1() -> Void {
        
             let fileName = getDocumentsDirectory().appendingPathComponent("\(self.fromDateTF.text!)-\(self.ToDateTF.text!).csv")
         
             var csvText = "Zone,Product,Date,Size,DealerName,BatchNo,Status\n"
             
             for complaintDetails in complaintList {
                 let newLine = "\(String(describing: complaintDetails.zone!)),\(String(describing: complaintDetails.product!)),\(String(describing: complaintDetails.date!)),\(String(describing: complaintDetails.size!)),\(String(describing: complaintDetails.dealerName!)),\(String(describing: complaintDetails.batchNo!)),\(String(describing: complaintDetails.status!)),\n"
                 csvText.append(newLine)
             }
             
             do {
                 try csvText.write(to: fileName, atomically: true, encoding: String.Encoding.utf8)
             
               
                
             } catch {
                 print("Failed to create file")
                 print("\(error)")
             }
            
             SingleToneClass.shared.dismissProgressLoading()
             SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "File Saved In Iphone/Files/Adama") {
                 
               
             }
         }

    
    
    
    
    
    
    
    
    
    
    
    
    
    private func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
      
        return paths[0]
    }
    
    func documentInteractionControllerViewControllerForPreview(_ controller: UIDocumentInteractionController) -> UIViewController
    {
        return self
    }

    
    
    func showFileWithPath(path: String){
        let isFileFound:Bool? = FileManager.default.fileExists(atPath: path)
        print(isFileFound as Any)
        if isFileFound == false {
            let viewer = UIDocumentInteractionController(url: URL(fileURLWithPath: path))
            
            viewer.delegate = self
            viewer.presentPreview(animated: true)
        }

    }

    
    
    
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        print(reportList.count)
//        return reportList.count
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//
//          let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ReportsTableViewCell
//
//
//        cell.detailsView.layer.masksToBounds = false
//        cell.detailsView.layer.shadowColor = UIColor.black.cgColor
//        cell.detailsView.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
//        cell.detailsView.layer.shadowOpacity = 0.5
//        cell.detailsView.layer.cornerRadius = 20
//
//        cell.ticketLbl.text = reportList[indexPath.row].TicketId
//        cell.assignFromLbl.text = reportList[indexPath.row].assignFrom
//        cell.assignToLbl.text = reportList[indexPath.row].assignTo
//        cell.assignDateLbl.text = reportList[indexPath.row].assignDate
//        cell.firstAssignLbl.text = reportList[indexPath.row].firstAssign
//        cell.reAssignLbl.text = reportList[indexPath.row].reAssign
//        cell.priorityLbl.text = reportList[indexPath.row].priority
//        cell.statusLbl.text = reportList[indexPath.row].status
//
//        return cell
//
//
//    }
    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 100
//    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if selectedTF == self.currentStatusTF {
            return currentStatus.count
        }else {
            return 0
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        
        if selectedTF == self.currentStatusTF {
            return currentStatus[row]
        }else {
            return [String]()[row]
        }
        
    }
    
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        self.selectedTF = textField
        return true
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

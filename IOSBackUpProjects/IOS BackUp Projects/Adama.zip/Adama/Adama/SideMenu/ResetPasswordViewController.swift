//
//  ResetPasswordViewController.swift
//  Adama
//
//  Created by MAD-MAC on 26/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class ResetPasswordViewController: UIViewController {

    @IBOutlet weak var sideMenuBtn: UIBarButtonItem!
    @IBOutlet weak var existingPwdTF: TextField!
    @IBOutlet weak var newPwdTF: TextField!
    @IBOutlet weak var confirmPwdTF: TextField!
    @IBOutlet weak var updateBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.navigationController?.isNavigationBarHidden = false
        self.title = "Change Password"
        
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white
        self.updateBtn.layer.cornerRadius = 10
       
        // Do any additional setup after loading the view.
    }
    
    @IBAction func confirmBtn(_ sender: Any) {
        
        if !existingPwdTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter old password") {
                self.existingPwdTF.becomeFirstResponder()
            }
        }   else if !newPwdTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter new password") {
                self.newPwdTF.becomeFirstResponder()
            }
        } else if confirmPwdTF.text != newPwdTF.text {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "New password and confirm password must be same") {
                self.confirmPwdTF.becomeFirstResponder()
            }
            
        } else {
              SingleToneClass.shared.showProgressLoading(title: "Please wait...")
            serviceCall()
            
        }
        
  
        
    }
    
    
    func serviceCall()  {
       
        let userId = UserDefaults.standard.object(forKey: "UserId") as! Int
         let depid=UserDefaults.standard.object(forKey: "DepartmentId") as! Int
        print(userId as Any)
        
        let params = ["user_id":"\(userId)","old_password":existingPwdTF.text!,"new_password":confirmPwdTF.text!,"login_department_id":"\(depid)"]
        print(params)
        
         Service.shared.POSTService(serviceType: API.changePassword, parameters: params ) { (response) -> (Void) in
        
            
            print(response)
             SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            print(responseDetails as Any)
            
            if responseDetails["code"] == "200"{
            
                
//                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
//                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "accountVC") as! accountVC
//                self.present(nextViewController, animated:true, completion:nil)
                
                let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
                let gotoOTP = storyBoard.instantiateViewController(withIdentifier: "MPIViewController") as! MPIViewController
                self.navigationController?.pushViewController(gotoOTP, animated: true)
                
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
                
            }else if responseDetails["status"] == 419 {
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) {
                    exit(0)
                }
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
            }
            
        }
        
        
    }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  ComplaintPickerViewController.swift
//  Adama
//
//  Created by MAD-MAC on 17/10/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class ComplaintPickerViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate,UITextFieldDelegate {
    
    @IBOutlet weak var searchTF: TextField!
    
    @IBOutlet weak var table: UITableView!
    var saveDetails:[ProductDetails] = []
    var searchResult:[ProductDetails] = []
    var savePri:[Priority] = []
    var productValue:Int?
    var productNames:[String]=["--None--"]
    var productId:[Int]=[0]
    var tagValue:Int?
    
    var searchActive : Bool = false
    var filteredData: [String]!
    var search = false
    var selectedTF = UITextField()
    
    
    let userId = UserDefaults.standard.object(forKey: "UserId") as! Int
    let loginDepartmentId = UserDefaults.standard.object(forKey: "DepartmentId") as! Int
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        print(tagValue as Any)
        if tagValue == 1 || tagValue == 15 {
            productService()
        }else if tagValue == 2 || tagValue == 16 {
          productSizeService()
        }else if tagValue == 3 || tagValue == 17{
             zoneService()
        }else if tagValue == 4  || tagValue == 18 {
            SingleToneClass.shared.dismissProgressLoading()
            productNames = ["Select Nature Of Complain","Damage","Labelling","Less Wt","Leakage","Material Quality","Printing","Shorting","Other"]
            
            productId = [1,2,3,4,5,6,7,8,9]
            
            for i in 0..<productNames.count{
                
                var ob = Priority()
                
                for j  in 0..<productId.count{
                    
                    ob.id = productId[j]
                    ob.name = productNames[i]
                }
                savePri.append(ob)
                
                
            }
            table.reloadData()
            print(savePri)
            
        }else if tagValue == 5 {
            selectDepartment()
        }else if tagValue == 6 {
            getSubDepartment()
        }else if tagValue == 7 {
            Ids.categoryIds = ""
            getcategoryAndSubCategory()
        }else if tagValue == 8 {
            getcategoryAndSubCategory()
        }else if tagValue == 9 {
            SingleToneClass.shared.dismissProgressLoading()
            productNames = ["High","Medium","Low"]
            productId = [2,3,1]
            
            for i in 0..<productNames.count{
                
                var ob = Priority()
                
                for j  in 0..<productId.count{
                    
                    ob.id = productId[j]
                    ob.name = productNames[i]
                }
                savePri.append(ob)

                
            }
            table.reloadData()
            print(savePri)
        }else if tagValue == 10 {
            selectDepartment()
        }else if tagValue == 11 {
            getSubDepartment()
        }else if tagValue == 12 {
            Ids.categoryIds = ""
            getcategoryAndSubCategory()
        }else if tagValue == 13 {
            getcategoryAndSubCategory()
        }else if tagValue == 14 {
//            SingleToneClass.shared.dismissProgressLoading()
//            productNames  = ["IT","Plant","Management","sales & Marketing","Operations","Supply Chain-Operation"]
//            productId = [1,2,3,4,5,6]
//            for i in 0..<productNames.count{
//
//                var ob = Priority()
//
//                for j  in 0..<productId.count{
//
//                    ob.id = productId[j]
//                    ob.name = productNames[i]
//                }
//                savePri.append(ob)
//
//
//            }
//            table.reloadData()
            selectDepartment()
        }
        
        
        
 
        
        searchTF.delegate = self
     searchTF.addTarget(self, action: #selector(self.textFieldDidChange(_:)), for: UIControl.Event.editingChanged)
        // Do any additional setup after loading the view.
    }
    
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        
        print(selectedTF.text!)
        print(searchTF.text!)
//        searchResult = saveDeatils.filter { item in
//            return item.lowercased().contains(searchTF.text!.lowercased())
//        }
        
        let searchText = NSPredicate(format:"self contains[cd]%@",searchTF.text!)
        searchResult = saveDetails.filter{searchText.evaluate(with: $0.name)}
       // searchResult = savePri.filter{searchText.evaluate(with: $0.name)}
       
        
        print(searchResult)
        if searchResult.isEmpty == false{
            
            search = true
            table.reloadData()
            
        }else{
            
            search = false
            table.reloadData()
            
        }
    }

    
    
//
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//        if selectedTF == searchTF {
//        print(searchTF.text as Any)
//        searchResult = productNames.filter({ $0.uppercased() == textField.text
//
//        })
//
//        print(searchResult)
//        if searchResult.isEmpty == false{
//
//            search = true
//            table.reloadData()
//
//        }else{
//
//            search = false
//            table.reloadData()
//
//        }
//        }
//        return true
//    }
//
    
    
    
    
    
    
    

    @IBAction func closeBtn(_ sender: Any) {
      //  dismiss(animated: true, completion: nil)
         self.view.removeFromSuperview()
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
         self.selectedTF = textField
        return true
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if search {
            return searchResult.count
        }else{
            if saveDetails.isEmpty == true {
                return savePri.count
            }else{
                return saveDetails.count
            }
        //return departmentNames.count
    }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ComplaintPickerTableViewCell
        if search {
            cell.nameLbl.text = searchResult[indexPath.row].name
            productValue = searchResult[indexPath.row].id
        }else{
            if saveDetails.isEmpty == true {
                cell.nameLbl.text = savePri[indexPath.row].name
                
            }else{
                cell.nameLbl.text = saveDetails[indexPath.row].name
            productValue = saveDetails[indexPath.row].id
            //cell.nameLbl.text = productNames[indexPath.row]
        }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if search{
            
//            let imageDataDict:[String: Any] = ["product":searchResult[indexPath.row].name!,"TextfieldTag":tagValue!,"id":searchResult[indexPath.row].id!]
//            if tagValue == 5 || tagValue == 6 || tagValue == 7 || tagValue == 8{
//                let low = NotificationCenter.default
//                low.post(name: Notification.Name("Low1"), object: nil,userInfo: imageDataDict)
//            }
//            else{
//                let low = NotificationCenter.default
//                low.post(name: Notification.Name("Low1"), object: nil,userInfo: imageDataDict)
//
//            }
            
            if tagValue == 5 || tagValue == 6 || tagValue == 7 || tagValue == 8 || tagValue == 15 || tagValue == 16 || tagValue == 17 {

                let imageDataDict:[String: Any] = ["product": searchResult[indexPath.row].name!,"TextfieldTag":tagValue!,"id":searchResult[indexPath.row].id!]

                let low = NotificationCenter.default

                low.post(name: Notification.Name("Low1"), object: nil,userInfo: imageDataDict)

//            }else if tagValue == 9 || tagValue == 18 {
//
//                let imageDataDict:[String: Any] = ["product": savePri[indexPath.row].name!,"TextfieldTag":tagValue!,"id":savePri[indexPath.row].id!]
//
//
//                let low = NotificationCenter.default
//
//                low.post(name: Notification.Name("Low1"), object: nil,userInfo: imageDataDict)
//
//
//            }else if tagValue == 4 {
//                let imageDataDict:[String: Any] = ["product": savePri[indexPath.row].name!,"TextfieldTag":tagValue!,"id":savePri[indexPath.row].id!]
//                let low = NotificationCenter.default
//                low.post(name: Notification.Name("Low2"), object: nil,userInfo: imageDataDict)


            } else if tagValue == 1 || tagValue == 2 || tagValue == 3 {
                let imageDataDict:[String: Any] = ["product": searchResult[indexPath.row].name!,"TextfieldTag":tagValue!,"id":searchResult[indexPath.row].id!]
                let low = NotificationCenter.default
                low.post(name: Notification.Name("Low2"), object: nil,userInfo: imageDataDict)

            }else if tagValue == 10 || tagValue == 11 || tagValue == 12 || tagValue == 13{

                let imageDataDict:[String: Any] = ["product": searchResult[indexPath.row].name!,"TextfieldTag":tagValue!,"id":searchResult[indexPath.row].id!]

                let low = NotificationCenter.default

                low.post(name: Notification.Name("Low3"), object: nil,userInfo: imageDataDict)

//            }else if tagValue == 14 {
//
//
//                //        let imageDataDict:[String: Any] = ["product": savePri[indexPath.row].name!,"TextfieldTag":tagValue!,"id":savePri[indexPath.row].id!]
//                //        let low = NotificationCenter.default
//                //        low.post(name: Notification.Name("Low4"), object: nil,userInfo: imageDataDict)
//
//                let imageDataDict:[String: Any] = ["product": saveDetails[indexPath.row].name!,"TextfieldTag":tagValue!,"id":saveDetails[indexPath.row].id!]
//
//                let low = NotificationCenter.default
//
//                low.post(name: Notification.Name("Low4"), object: nil,userInfo: imageDataDict)



            }
            
            
            
            
        }else{
     
           

       if tagValue == 5 || tagValue == 6 || tagValue == 7 || tagValue == 8 || tagValue == 15 || tagValue == 16 || tagValue == 17 {
        
         let imageDataDict:[String: Any] = ["product": saveDetails[indexPath.row].name!,"TextfieldTag":tagValue!,"id":saveDetails[indexPath.row].id!]
        
            let low = NotificationCenter.default
      
            low.post(name: Notification.Name("Low1"), object: nil,userInfo: imageDataDict)
        
       }else if tagValue == 9 || tagValue == 18 {
     
        let imageDataDict:[String: Any] = ["product": savePri[indexPath.row].name!,"TextfieldTag":tagValue!,"id":savePri[indexPath.row].id!]
        
        
        let low = NotificationCenter.default
        
        low.post(name: Notification.Name("Low1"), object: nil,userInfo: imageDataDict)
        
        
       }else if tagValue == 4 {
          let imageDataDict:[String: Any] = ["product": savePri[indexPath.row].name!,"TextfieldTag":tagValue!,"id":savePri[indexPath.row].id!]
        let low = NotificationCenter.default
        low.post(name: Notification.Name("Low2"), object: nil,userInfo: imageDataDict)
        
        
       } else if tagValue == 1 || tagValue == 2 || tagValue == 3  {
         let imageDataDict:[String: Any] = ["product": saveDetails[indexPath.row].name!,"TextfieldTag":tagValue!,"id":saveDetails[indexPath.row].id!]
        let low = NotificationCenter.default
        low.post(name: Notification.Name("Low2"), object: nil,userInfo: imageDataDict)
        
        }else if tagValue == 10 || tagValue == 11 || tagValue == 12 || tagValue == 13{
                
                let imageDataDict:[String: Any] = ["product": saveDetails[indexPath.row].name!,"TextfieldTag":tagValue!,"id":saveDetails[indexPath.row].id!]
                
                let low = NotificationCenter.default
                
                low.post(name: Notification.Name("Low3"), object: nil,userInfo: imageDataDict)
                
       }else if tagValue == 14 {
        
        
//        let imageDataDict:[String: Any] = ["product": savePri[indexPath.row].name!,"TextfieldTag":tagValue!,"id":savePri[indexPath.row].id!]
//        let low = NotificationCenter.default
//        low.post(name: Notification.Name("Low4"), object: nil,userInfo: imageDataDict)
        
        let imageDataDict:[String: Any] = ["product": saveDetails[indexPath.row].name!,"TextfieldTag":tagValue!,"id":saveDetails[indexPath.row].id!]
        
        let low = NotificationCenter.default
        
        low.post(name: Notification.Name("Low4"), object: nil,userInfo: imageDataDict)
        
        
        
            }
            
            
            
            
        }
        
        self.view.removeFromSuperview()
        
       // dismiss(animated: true, completion: nil)
    }
    
    
    
    func productService()  {
        
        let params:[String:String] = [:]
        
        Service.shared.POSTService(serviceType: API.product, parameters: params ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                print(message as Any)
                print(responseDetails as Any)
                print(responseDetails["status"] as Any)
                
                if responseDetails["status"] == 200 {
                    
                    let data = responseDetails["data"]?.array
                    
                  
                    
                    for i in data! {
                        

                         var obj = ProductDetails()
                        
                        obj.id = i["id"].int!
                        obj.name = i["p_name"].string
                        self.saveDetails.append(obj)
                        
                    }
                  print(self.saveDetails)
                    self.table.reloadData()
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        
                    }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
        }
        
        
    }
    
    
    func productSizeService()  {
         SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
        let params:[String:String] = [:]
        
        Service.shared.POSTService(serviceType: API.productSize, parameters: params ) { (response) -> (Void) in
            
            print(response)
            // SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                print(message as Any)
                print(responseDetails as Any)
                print(responseDetails["status"] as Any)
                
                if responseDetails["status"] == 200 {
                    
                    let data = responseDetails["data"]?.array
                    
                  SingleToneClass.shared.dismissProgressLoading()
                    
                    for i in data! {
                        

                        var obj = ProductDetails()
                        
                        obj.id = i["id"].int!
                        obj.name = i["size"].string
                        self.saveDetails.append(obj)
                        
                       
                        
                    }
                    
                    self.table.reloadData()
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        
                    }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
        }
        
        
    }
    
    func zoneService()  {
        
        let params:[String:String] = [:]
        
        Service.shared.POSTService(serviceType: API.zone, parameters: params ) { (response) -> (Void) in
            
            print(response)
             SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                print(message as Any)
                print(responseDetails as Any)
                print(responseDetails["status"] as Any)
                
                if responseDetails["status"] == 200 {
                    
                    let data = responseDetails["data"]?.array
                    
               
                    
                    for i in data! {
                    
                        var obj = ProductDetails()
                        
                        obj.id = i["id"].int!
                        obj.name = i["name"].string
                        self.saveDetails.append(obj)
                    }
                    
                    self.table.reloadData()
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        
                    }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
        }
        
        
    }
    
    
    func selectDepartment()  {
        
        
        let params = ["user_id":"\(userId)","login_department_id":"\(loginDepartmentId)"]
        // let params:[String:String] = [:]
        
        Service.shared.POSTService(serviceType: API.selectDepartment, parameters: params ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                print(message as Any)
                print(responseDetails as Any)
                print(responseDetails["status"] as Any)
                
                if responseDetails["status"] == 200 {
                    
                    if let data = responseDetails["data"]?.array {
                        

                        for i in data {
                            
                            var obj = ProductDetails()

                            obj.id = i["id"].int!
                            obj.name = i["d_name"].string
                            self.saveDetails.append(obj)
                            


                            
                        }
                      print(self.saveDetails)
                        self.table.reloadData()
                        
                     
                    }else{
                        SingleToneClass.shared.dismissProgressLoading()
                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "No Data Found") {
                        
                            
                        }
                    }
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        
                    }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
        }
        
        
    }
    
    func getSubDepartment()  {
     
        let params = ["department_id" : "\(String(describing: Ids.departmentIds ))","user_id":"\(userId)","login_department_id":"\(loginDepartmentId)"]
        print(params)
     
        Service.shared.POSTService(serviceType: API.getSubDepartment, parameters: params) { (response) -> (Void) in
            
            print(response)
             SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                print(message as Any)
                print(responseDetails as Any)
                print(responseDetails["status"] as Any)
                
                if responseDetails["status"] == 200 {
                
                    if let data = responseDetails["data"]?.array {
        
                        for i in data {

                            var obj = ProductDetails()
                            
                            obj.id = i["id"].int!
                            obj.name = i["SubDepartment_name"].string
                            self.saveDetails.append(obj)
                           
                        }
                        self.table.reloadData()
                     
                    }else{
                        SingleToneClass.shared.dismissProgressLoading()
                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "No Data Found") {
                          
                        }
                    }
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                     
                    }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
        }
        
    }
    
    func getcategoryAndSubCategory ()  {
        

        let params = ["department_id" : String (Ids.departmentIds),"sub_department_id": String(Ids.subDepartmentIds),"user_id":"\(userId)","login_department_id":"\(loginDepartmentId)","parent_id":Ids.categoryIds]
        print(params)
       
        Service.shared.POSTService(serviceType: API.getSubSubDepartment, parameters: params) { (response) -> (Void) in
            
            print(response)
             SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                print(message as Any)
                print(responseDetails as Any)
                print(responseDetails["status"] as Any)
                
                if responseDetails["status"] == 200 {
                  //  self.subCategoryTF.isEnabled = true
                    
                    if  let data = responseDetails["data"]?.array {
                        
                        for i in data {
                            
                            var obj = ProductDetails()
                            
                            obj.id = i["id"].int!
                            obj.name = i["name"].string
                            self.saveDetails.append(obj)
                            
                            // self.createPicker()
                        }
                        self.table.reloadData()
                    }else{
                        SingleToneClass.shared.dismissProgressLoading()
                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "No Data Found") {
                            
                        }
                    }
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        // self.subCategoryTF.isEnabled = false
                        //  self.subSubDepartmentTF.resignFirstResponder()
                    }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
        }
        
        

        
    }
    
    
}

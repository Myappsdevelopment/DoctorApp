//
//  ComplaintListViewController.swift
//  Adama
//
//  Created by MAD-MAC on 18/10/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class ComplaintListViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
  

    @IBOutlet weak var table: UITableView!
    
    @IBOutlet weak var sideMenuBtn: UIBarButtonItem!
    
    @IBOutlet weak var noDataImage: UIImageView!
    
    
    var productArray = [String]()
    var sizeArray = [String]()
    var zoneArray = [String]()
    var batchNoArray = [String]()
    var dealerNameArray = [String]()
    var dateArray = [String]()
    var actionArray = [String]()
    var statusArray = [Int]()
    var complaintId = [Int]()
    var natureOfComplaint = [String]()
    var quantityAffected = [String]()
    var dealerCode = [String]()
    var mobileNo = [String]()
    var imageArray = [String]()
    
    
    
    var selectedIndex: Int = 0
    var assignedBtnHide = ""
    
    let userId = UserDefaults.standard.object(forKey: "UserId") as! Int
    let userType = UserDefaults.standard.object(forKey: "UserType") as! Int
    let loginDepartmentId = UserDefaults.standard.object(forKey: "DepartmentId") as! Int
    let empId = UserDefaults.standard.object(forKey: "EmployeeId") as! String
    
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        SingleToneClass.shared.showProgressLoading(title: "Please wait...")
        
        
        if DetailsStore.submittedComplaint == true {
            
            
            self.navigationController?.isNavigationBarHidden = false
            self.title = "Submitted Complaint"
            
            self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
            self.navigationController?.navigationBar.tintColor = .white
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
            self.navigationController?.navigationBar.isTranslucent = false
            self.navigationController?.view.backgroundColor = .white
            
            productArray.removeAll()
            sizeArray.removeAll()
            zoneArray.removeAll()
            batchNoArray.removeAll()
            dealerNameArray.removeAll()
            dateArray.removeAll()
            actionArray.removeAll()
            statusArray.removeAll()
            complaintId.removeAll()
            natureOfComplaint.removeAll()
            quantityAffected.removeAll()
            dealerCode.removeAll()
            mobileNo.removeAll()
            imageArray.removeAll()
            SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
            submittedComplaintService()
            
            
        }else if DetailsStore.assignedComplaint == true {
            
            
            self.navigationController?.isNavigationBarHidden = false
            self.title = "Assigned Complaint"
            
            self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
            self.navigationController?.navigationBar.tintColor = .white
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
            self.navigationController?.navigationBar.isTranslucent = false
            self.navigationController?.view.backgroundColor = .white
            
            productArray.removeAll()
            sizeArray.removeAll()
            zoneArray.removeAll()
            batchNoArray.removeAll()
            dealerNameArray.removeAll()
            dateArray.removeAll()
            actionArray.removeAll()
            statusArray.removeAll()
            complaintId.removeAll()
            natureOfComplaint.removeAll()
            quantityAffected.removeAll()
            dealerCode.removeAll()
            mobileNo.removeAll()
            imageArray.removeAll()
             SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
            assignedComplaintService()
            
            
        }else if DetailsStore.customerComplaint == true{
            
            
          
            
            self.navigationController?.isNavigationBarHidden = false
            self.title = "Customer Complaint"
            
            self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
            self.navigationController?.navigationBar.tintColor = .white
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
            self.navigationController?.navigationBar.isTranslucent = false
            self.navigationController?.view.backgroundColor = .white
            
            productArray.removeAll()
            sizeArray.removeAll()
            zoneArray.removeAll()
            batchNoArray.removeAll()
            dealerNameArray.removeAll()
            dateArray.removeAll()
            actionArray.removeAll()
            statusArray.removeAll()
            complaintId.removeAll()
            natureOfComplaint.removeAll()
            quantityAffected.removeAll()
            dealerCode.removeAll()
            mobileNo.removeAll()
            imageArray.removeAll()
            SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
            listComplaintsService()
        }
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
    }
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let low = NotificationCenter.default
        low.addObserver(self, selector: #selector(userLow), name: Notification.Name("Complaint"), object: nil)
        
         // Do any additional setup after loading the view.
    }
    
    @objc func userLow(){

       self.viewWillAppear(true)
        
    }
    
    
    func listComplaintsService () {
        
        
        let params = ["user_id":"\(userId)","type":"\(userType)","login_department_id":"\(loginDepartmentId)"] as [String : Any]
        print(params)
        
        Service.shared.POSTService(serviceType: API.listComplaintS, parameters: params as! [String : String] ) { (response) -> (Void) in
            
            print(response)
          
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            print(responseDetails as Any)
            
            if responseDetails["status"] == 200 {
                
                 let data = responseDetails["data"]?.array
                let baseimage = responseDetails["image_path"]?.string
                UserDefaults.standard.set(baseimage, forKey: "BaseImagePath")
                
                
                if data!.isEmpty == true{
                    self.table.isHidden = true
                    self.noDataImage.isHidden = false
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "No records found") { }
                }else{
                
                
                self.table.isHidden = false
                    self.noDataImage.isHidden = true
                    
                    for i in data!{
                    
                    
                    let id = i["id"].int
                    let batchNo = i ["batch_no"].string
                    let dealerName = i["dealers_name"].string
                    let date = i["manufacturing_date"].string
                    
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd"
                    
                    
                    let showDate = dateFormatter.date(from: date!)
                    dateFormatter.dateFormat = "dd-MM-yyyy"
                    let resultString = dateFormatter.string(from: showDate!)
                    print(resultString)
                    
                    let product = i["products"].dictionary
                    
                    let productName = product!["p_name"]?.string
                    
                    let packageSize = i["package_size"].dictionary
                    let  size = packageSize!["size"]?.string
                    
                    let zones = i["zones"].dictionary
                    let zoneName = zones!["name"]?.string
                    
                    let status = i["status"].int
                 //   let action = i["action_id"].int
                    
                        
                      let assign = i["complaint_assign"].dictionary
                  
                        if assign == nil {
                            self.actionArray.append("-")
                        }else{
                            let complaintName = assign!["name"]?.string
                            self.actionArray.append(complaintName!)
                        }
                        
                        
                        
                        let natureComplaint = i["nature_of_complaint"].string
                        let quantity = i["quantity"].string
                        
                        var dealerCode = String()
                        if i["dealers_code"].string?.isEmpty == true {
                            dealerCode = "-"
                        }else{
                            dealerCode = i["dealers_code"].string ?? "-"
                        }
                        
                       
                        let mobileNo = i["mobile_no"].string
                        
                        let attach = i["attach_files"].array
                        
                        if attach == [] {
                            self.imageArray.append("-")
                        }else{
                        
                        for j in attach! {
                            
                            let image = j["image"].string
                            // let imagepath = baseimage! + image!
                            
                            self.imageArray.append(image!)
                        }
                        }
                        print(attach!)
                        
                    self.productArray.append(productName!)
                    self.sizeArray.append(size!)
                    self.zoneArray.append(zoneName!)
                    self.batchNoArray.append(batchNo!)
                    self.dealerNameArray.append(dealerName!)
                    self.dateArray.append(resultString)
                    self.statusArray.append(status!)
                    self.complaintId.append(id!)
                    self.quantityAffected.append(quantity!)
                    self.natureOfComplaint.append(natureComplaint!)
                    self.dealerCode.append(dealerCode)
                    self.mobileNo.append(mobileNo!)
                    
         
                    
                }
                
                self.table.reloadData()
                
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
                    SingleToneClass.shared.dismissProgressLoading(WithDelay: 10)
                
                }
                
            }else if responseDetails["status"] == 419 {
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) {
                    exit(0)
                }
                
            } else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
            }
            
        }
        
        
    }
    
    
    
    func submittedComplaintService()  {
        
        
        let params = ["user_id":"\(userId)","login_department_id":"\(loginDepartmentId)"] as [String : Any]
        print(params)
        
        Service.shared.POSTService(serviceType: API.submittedComplaint, parameters: params as! [String : String] ) { (response) -> (Void) in
            
            print(response)
          
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            print(responseDetails as Any)
            
            if responseDetails["status"] == 200 {
                
                 let data = responseDetails["data"]?.array
                let baseimage = responseDetails["image_path"]?.string
                UserDefaults.standard.set(baseimage, forKey: "BaseImagePath")
                
                if data!.isEmpty == true{
                    self.table.isHidden = true
                    self.noDataImage.isHidden = false
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "No records found") { }
                }else{
                
                
                    self.table.isHidden = false
                    self.noDataImage.isHidden = true
                    
                    for i in data!{
                        
                        
                        let id = i["id"].int
                        let batchNo = i ["batch_no"].string
                        let dealerName = i["dealers_name"].string
                        let date = i["manufacturing_date"].string
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"
                        
                        
                        let showDate = dateFormatter.date(from: date!)
                        dateFormatter.dateFormat = "dd-MM-yyyy"
                        let resultString = dateFormatter.string(from: showDate!)
                        print(resultString)
                        
                        let product = i["products"].dictionary
                        let productName = product!["p_name"]?.string
                        
                        let packageSize = i["package_size"].dictionary
                        let  size = packageSize!["size"]?.string
                        
                        let zones = i["zones"].dictionary
                        let zoneName = zones!["name"]?.string
                        
                        let status = i["status"].int
                     //   let action = i["action_id"].int
                        let natureComplaint = i["nature_of_complaint"].string
                        let quantity = i["quantity"].string
                        let dealerCode = i["dealers_code"].string
                        let mobileNo = i["mobile_no"].string
                        
                        let attach = i["attach_files"].array
                        
                        if attach == [] {
                            self.imageArray.append("-")
                        }else{
                        for j in attach! {
                            
                            let image = j["image"].string
                           // let imagepath = baseimage! + image!
                            
                            self.imageArray.append(image!)
                        }
                        }
                        
                        let assign = i["complaint_assign"].dictionary
                       
                        if assign == nil {
                            self.actionArray.append("-")
                        }else{
                            let complaintName = assign!["name"]?.string
                            self.actionArray.append(complaintName!)
                        }
                        
                        self.productArray.append(productName!)
                        self.sizeArray.append(size!)
                        self.zoneArray.append(zoneName!)
                        self.batchNoArray.append(batchNo!)
                        self.dealerNameArray.append(dealerName!)
                        self.dateArray.append(resultString)
                        self.statusArray.append(status!)
                        self.complaintId.append(id!)
                       
                        self.quantityAffected.append(quantity!)
                        self.natureOfComplaint.append(natureComplaint!)
                        self.dealerCode.append(dealerCode!)
                        self.mobileNo.append(mobileNo!)
                        
                        
                    }
                    
                    self.table.reloadData()
                    
                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
                    SingleToneClass.shared.dismissProgressLoading(WithDelay: 10)
                    
                
                }
                
            }else if responseDetails["status"] == 419 {
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) {
                    exit(0)
                }
                
            } else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
            }
           
        }
        
        
    }
    
    
    
    
    func assignedComplaintService()  {
        
        
        let params = ["user_id":"\(userId)","login_department_id":"\(loginDepartmentId)"] as [String : Any]
        print(params)
        
        Service.shared.POSTService(serviceType: API.assignedComplaintlist, parameters: params as! [String : String] ) { (response) -> (Void) in
            
            print(response)
           
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            print(responseDetails as Any)
            
            if responseDetails["status"] == 200 {
                
                let data = responseDetails["data"]?.array
                let baseimage = responseDetails["image_path"]?.string
                UserDefaults.standard.set(baseimage, forKey: "BaseImagePath")
                
                if data!.isEmpty == true{
                    self.table.isHidden = true
                    self.noDataImage.isHidden = false
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "No records found") { }
                }else{
                    
                    
                    self.table.isHidden = false
                    self.noDataImage.isHidden = true
                    
                    for i in data!{
                        
                        
                        let id = i["id"].int
                        let batchNo = i ["batch_no"].string
                        let dealerName = i["dealers_name"].string
                        let date = i["manufacturing_date"].string
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"
                        
                        
                        let showDate = dateFormatter.date(from: date!)
                        dateFormatter.dateFormat = "dd-MM-yyyy"
                        let resultString = dateFormatter.string(from: showDate!)
                        print(resultString)
                        
                        let product = i["products"].dictionary
                        let productName = product!["p_name"]?.string
                        
                        let packageSize = i["package_size"].dictionary
                        let  size = packageSize!["size"]?.string
                        
                        let zones = i["zones"].dictionary
                        let zoneName = zones!["name"]?.string
                        
                        let status = i["status"].int
                    //    let action = i["action_id"].int
                        let natureComplaint = i["nature_of_complaint"].string
                        let quantity = i["quantity"].string
                        let dealerCode = i["dealers_code"].string
                        let mobileNo = i["mobile_no"].string
                        
                        let attach = i["attach_files"].array
                        
                        if attach == [] {
                            self.imageArray.append("-")
                        }else{
                        for j in attach! {
                            
                            let image = j["image"].string
                            // let imagepath = baseimage! + image!
                            
                            self.imageArray.append(image!)
                        }
                        }
                        
                        let assign = i["complaint_assign"].dictionary
                        
                        if assign == nil {
                            self.actionArray.append("-")
                        }else{
                            let complaintName = assign!["name"]?.string
                            self.actionArray.append(complaintName!)
                        }
                        
                        
                        self.productArray.append(productName!)
                        self.sizeArray.append(size!)
                        self.zoneArray.append(zoneName!)
                        self.batchNoArray.append(batchNo!)
                        self.dealerNameArray.append(dealerName!)
                        self.dateArray.append(resultString)
                        self.statusArray.append(status!)
                        self.complaintId.append(id!)
                      //  self.actionArray.append(action!)
                        self.quantityAffected.append(quantity!)
                        self.natureOfComplaint.append(natureComplaint!)
                        self.dealerCode.append(dealerCode!)
                        self.mobileNo.append(mobileNo!)
                        
                        
                    }
                    
                    self.table.reloadData()
                    
                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
                    SingleToneClass.shared.dismissProgressLoading(WithDelay: 10)
                    
                    
                }
                
            }else if responseDetails["status"] == 419 {
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) {
                    exit(0)
                }
                
            } else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
            }
            
        }
        
        
    }
    
    
    

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
   
        return productArray.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for:indexPath) as! ComplaintListTableViewCell
        
        if DetailsStore.submittedComplaint == true || DetailsStore.assignedComplaint == true {
            cell.actionAssignLbl.isHidden = true
            cell.assignedStack.isHidden = true
            cell.assignedCollon.isHidden = true
            cell.currentStatusLbl.isHidden = false
            cell.statusAssignedLbl.isHidden = false
            cell.statusCollon.isHidden = false
        }else{
            cell.actionAssignLbl.isHidden = false
            cell.assignedStack.isHidden = false
            cell.assignedCollon.isHidden = false

        }
        
        cell.view.layer.cornerRadius = 20
        
        cell.view.layer.masksToBounds = false
         cell.view.layer.shadowColor = UIColor.black.cgColor
         cell.view.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
         cell.view.layer.shadowOpacity = 0.5
      //   cell.view.layer.shadowPath = shadowPath.cgPath
        
        
        
        
        cell.productLbl.text = productArray[indexPath.row]
        cell.sizeLbl.text = sizeArray[indexPath.row]
        cell.zoneLbl.text = zoneArray[indexPath.row]
        cell.batchNoLbl.text = batchNoArray[indexPath.row]
        cell.natureOfComplaintLbl.text = natureOfComplaint[indexPath.row]
        cell.dealerNameLbl.text = dealerNameArray[indexPath.row]
        cell.dateLbl.text = dateArray[indexPath.row]
        
//        if actionArray.isEmpty == true {
//            print(actionArray)
//            cell.ActionLbl.text = "-"
//        }else{
//            cell.ActionLbl.text = "Assigned To \(actionArray[indexPath.row])"
//        }
        
        cell.ActionLbl.text = "Assigned To \(actionArray[indexPath.row])"
        let status = "\(statusArray[indexPath.row])"
        if status == "\(1)" {
           
            cell.statusAssignedLbl.text = "Assigned To \(actionArray[indexPath.row])"
        }else if status == "\(2)" {
            cell.statusAssignedLbl.text = "Rejected"
        }else if status == "\(3)" {
            cell.statusAssignedLbl.text = "Complaint Close"
        }else if status == "\(0)" {
            cell.statusAssignedLbl.text = "Pending"
        }
        let id = complaintId[indexPath.row]
        print(id)

        
      
        
        
        
        
        let showBtnStatus = statusArray[indexPath.row]
        
        if showBtnStatus == 0 {
            cell.assignedBtn.isHidden = false
            cell.rejectedBtn.isHidden = false
            cell.ActionLbl.isHidden = true
             cell.assignedBtn.titleLabel?.adjustsFontSizeToFitWidth = true
            cell.rejectedBtn.titleLabel?.adjustsFontSizeToFitWidth = true
        }else if showBtnStatus == 1 {
            cell.assignedBtn.isHidden = true
            cell.rejectedBtn.isHidden = true
            cell.ActionLbl.isHidden = false
//            if actionArray[indexPath.row] == 0 {
//                cell.ActionLbl.text = "-"
//
//            }else{
//                cell.ActionLbl.text = "Assigned To\(actionArray[indexPath.row])"
//            }
            
            
        }else if showBtnStatus == 2 {
            cell.assignedBtn.isHidden = true
            cell.rejectedBtn.isHidden = false
            cell.rejectedBtn.setTitle("Rejected", for: .normal)
            cell.ActionLbl.isHidden = true
            cell.rejectedBtn.isEnabled = false
        }else{
            cell.assignedBtn.isHidden = true
            cell.rejectedBtn.isHidden = true
            cell.ActionLbl.isHidden = true
        }
        
        cell.assignedBtn.tag = indexPath.row
        cell.rejectedBtn.tag = indexPath.row
        
      
     
        
         cell.assignedBtn.addTarget(self, action: #selector(self.AssignedAction(_:)), for: .touchUpInside)
        
          cell.rejectedBtn.addTarget(self, action: #selector(self.RejectedAction(_:)), for: .touchUpInside)
        
        return cell
    }
    
        
    @objc func AssignedAction(_ sender: UIButton){
        
     
            
            let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EmployeeDetailsViewController") as! EmployeeDetailsViewController
            self.addChild(POPUPVC)
            POPUPVC.ticketId = complaintId[sender.tag]
//            POPUPVC.assignToId =  storeTaskList[sender.tag].assignTo[0].id
//            POPUPVC.assignFromId = storeTaskList[sender.tag].assingFrom[0].id
           POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
            self.view.addSubview(POPUPVC.view)
            POPUPVC.didMove(toParent: self)
        
        
       
    }
    
    
    
    @objc func RejectedAction(_ sender: UIButton){
        
        SingleToneClass.shared.showProgressLoading(title: "Please Wait.....")
        
        if self.selectedIndex == sender.tag {
            
            print(complaintId[sender.tag])
            let id = complaintId[sender.tag]
            
            
            let params = ["complaint_id":"\(id)","status":"\(String(describing: 2))","login_department_id":"\(loginDepartmentId)","user_id":"\(userId)","emp_id":empId]
            
            print(params)
            
            Service.shared.POSTService(serviceType: API.assignComplaint, parameters: params ) { (response) -> (Void) in
                
                print(response)
                
                SingleToneClass.shared.dismissProgressLoading()
                guard let responseDetails = response .dictionary else{return}
                
                if let message = responseDetails["success"]?.string {
                    
                
                    
                    if responseDetails["success"] == "Complaint Rejected successfully." {
                        
                        if DetailsStore.submittedComplaint == true {
                            self.submittedComplaintService()
                        }else if DetailsStore.assignedComplaint == true {
                            self.assignedComplaintService()
                        }else if DetailsStore.customerComplaint == true {
                            self.listComplaintsService()
                        }

                        
                    }else if responseDetails["status"] == 419 {
                        
                        SingleToneClass.shared.dismissProgressLoading()
                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                            exit(0)
                        }
                        
                    }else{
                        SingleToneClass.shared.dismissProgressLoading()
                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                        }
                    
                    
                    }else{
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                        
                    }
                    
                }
                
                
            }
            
        }

    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
     //   let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ComplaintListTableViewCell
        
        
        let emp = storyboard?.instantiateViewController(withIdentifier: "TDViewController") as! TDViewController
        DetailsStore.resolution = true
    
        emp.productNameData = productArray[indexPath.row]
        emp.packSizeData = sizeArray[indexPath.row]
        emp.wareHouseData =  zoneArray[indexPath.row]
        emp.batchNoData = batchNoArray[indexPath.row]
        emp.natureComplaintData = natureOfComplaint[indexPath.row]
        emp.quantityAffectedData = quantityAffected[indexPath.row]
        emp.dealerNameData = dealerNameArray[indexPath.row]
        emp.dealerCodeData = dealerCode[indexPath.row]
        emp.mobileNoData = mobileNo[indexPath.row]
        emp.DataDetailsData = dateArray[indexPath.row]
        emp.CurrentStatusData = "\(statusArray[indexPath.row])"
        emp.complaintId = complaintId[indexPath.row]
       
        if imageArray.isEmpty == false {
        emp.imageArray = [imageArray[indexPath.row]]
            print(emp.imageArray)
        }
        
           navigationController?.pushViewController(emp, animated: true)
        
        
    }
    
    
    
    
    
    
    
    
    
 
}

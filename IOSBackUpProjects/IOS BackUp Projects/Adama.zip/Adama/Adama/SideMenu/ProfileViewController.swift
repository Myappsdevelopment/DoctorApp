//
//  ProfileViewController.swift
//  Adama
//
//  Created by MAD-MAC on 26/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import Alamofire
import Kingfisher

class ProfileViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var sideMenuBtn: UIBarButtonItem!
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var profileImageBtn: UIButton!
    @IBOutlet weak var editBtn: UIButton!
    
    @IBOutlet weak var nameTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var mobileNoTF: UITextField!
    @IBOutlet weak var departmentNameTF: UITextField!
    @IBOutlet weak var dojTF: UITextField!
    @IBOutlet weak var employeeIdTF: UITextField!
    @IBOutlet weak var designationTF: UITextField!
    @IBOutlet weak var reportingManagerTF: UITextField!
    @IBOutlet weak var workLocationTF: UITextField!
    @IBOutlet weak var wareHouseTF: UITextField!
    @IBOutlet weak var zoneTF: UITextField!
    @IBOutlet weak var regionTF: UITextField!
    @IBOutlet weak var headQuaterTF: UITextField!
    @IBOutlet weak var territoryTF: UITextField!
    
    
    @IBOutlet weak var viewHeight: NSLayoutConstraint!
    @IBOutlet weak var textFieldsStackView: UIStackView!
    
    @IBOutlet weak var territoryStackView: UIStackView!
    @IBOutlet weak var headQuaterStackView: UIStackView!
    @IBOutlet weak var regionStackView: UIStackView!
    @IBOutlet weak var zoneStackView: UIStackView!
    @IBOutlet weak var wareHouseStackView: UIStackView!
    
    @IBOutlet weak var cameraBtn: UIButton!
    @IBOutlet weak var saveBtn: UIButton!
    @IBOutlet weak var hardwareTF: UITextField!
    @IBOutlet weak var softwareTF: UITextView!
    
    
    
    var profileIMageData: Data?
    let picker = UIImagePickerController()
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cameraBtn.isEnabled = false
        
        if UserDefaults.standard.object(forKey: "SubDepartmentName") as! String == "Field" || UserDefaults.standard.object(forKey: "SubDepartmentName") as! String == "Warehouse" {
            wareHouseStackView.isHidden = false
            zoneStackView.isHidden = false
            regionStackView.isHidden = false
            headQuaterStackView.isHidden = false
            territoryStackView.isHidden = false
            viewHeight.constant = 1420
        }else{
            wareHouseStackView.isHidden = true
            zoneStackView.isHidden = true
            regionStackView.isHidden = true
            headQuaterStackView.isHidden = true
            territoryStackView.isHidden = true
            viewHeight.constant = 1100
        }
        
        
        
        imageView.layer.cornerRadius =  profileImageBtn.bounds.size.width / 2
        self.imageView.clipsToBounds = true
        imageView.layer.borderWidth = 1
        //imageView.layer.masksToBounds = false
        imageView.layer.borderColor = UIColor.black.cgColor
        
        
        profileImageBtn.layer.cornerRadius =  profileImageBtn.bounds.size.width / 2
        self.profileImageBtn.clipsToBounds = true
        profileImageBtn.layer.borderWidth = 1
     //   profileImageBtn.layer.masksToBounds = false
        profileImageBtn.layer.borderColor = UIColor.black.cgColor
        
        

        saveBtn.layer.cornerRadius = 10
        softwareTF.layer.cornerRadius = 5
        
        
        self.navigationController?.isNavigationBarHidden = false
          self.title = "Profile"
        
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white
        // Do any additional setup after loading the view.
        picker.delegate = self
        
      
        loadDetails()
        
    }
    
    
    
    func loadDetails() {
        
        
        
        self.nameTF.text = UserDefaults.standard.object(forKey: "Name") as? String
        self.employeeIdTF.text = UserDefaults.standard.object(forKey: "EmployeeId") as? String
        self.emailTF.text = UserDefaults.standard.object(forKey: "Email") as? String
        self.mobileNoTF.text = UserDefaults.standard.object(forKey: "MobileNo") as? String
        self.departmentNameTF.text = UserDefaults.standard.object(forKey: "DepartmentName") as? String
        
        self.dojTF.text = UserDefaults.standard.object(forKey: "DateOfJoining") as? String
        self.designationTF.text = UserDefaults.standard.object(forKey: "Designation") as? String
        self.reportingManagerTF.text = UserDefaults.standard.object(forKey: "ReportingManager") as? String
        self.workLocationTF.text = UserDefaults.standard.object(forKey: "Location") as? String
        self.wareHouseTF.text = UserDefaults.standard.object(forKey: "WareHouse") as? String
      
        self.zoneTF.text = UserDefaults.standard.object(forKey: "Zone") as? String
        self.regionTF.text = UserDefaults.standard.object(forKey: "Region") as? String
        self.headQuaterTF.text = UserDefaults.standard.object(forKey: "HeadQuater") as? String
        self.territoryTF.text = UserDefaults.standard.object(forKey: "Territory") as? String
        self.hardwareTF.text = UserDefaults.standard.object(forKey: "Hardware") as? String
        self.softwareTF.text = UserDefaults.standard.object(forKey: "Software") as? String
        
        
 


        if let picture = UserDefaults.standard.object(forKey: "ProfileImage"){
            
            let imageRes = ImageResource(downloadURL: URL(string: picture as! String)!)
            print(imageRes)
            
            imageView.kf.setImage(with: imageRes)
            print(imageView as Any)
            print(imageView.image as Any)

            
        }
        

        
    }
    

    func saveServiceCall()  {
        SingleToneClass.shared.dismissProgressLoading()

        let userid = UserDefaults.standard.object(forKey:"UserId") as! Int
        let depid=UserDefaults.standard.object(forKey: "DepartmentId") as! Int
        print(userid)
        var params: [String: Any] = [
            "user_id": "\(userid)",
            "name": nameTF.text!,
            "mobile_no": mobileNoTF.text!,
            "login_department_id": "\(depid)"
        ]
        
        if let data = self.profileIMageData {
            params["logo"] = AGImageInfo(fileName: "file.jpeg", type: .png, data: data)
        }
    
        print(params)
        
        
        Service.shared.makeUploadRequest(serviceType: API.updateProfile, parameters: params) { response in

            print(response)

            guard let responseDetails = response .dictionary else{return}

            if let message = responseDetails["message"]?.string {

                print(message as Any)
                print(responseDetails as Any)
                print(responseDetails["status"] as Any)

                if responseDetails["status"] == 200 {
                    
                    
                    let data = responseDetails["data"]?.dictionary
                    
                
                    
                 
                    let name = data!["name"]?.string
                    let email = data!["email"]?.string
                    let mobileNo = data!["mobile_no"]?.string
                   
                    let departmentName = data!["department_name"]?.string
                    let role = data!["role"]?.string
                   
                    
                    let image = responseDetails["image_path"]?.string
                    let logo = data!["logo"]?.string
                    
                    let profileImage = image! + logo!
                    print(profileImage)
                    
                    
                    
                    
               
                    
                    
                    UserDefaults.standard.set(profileImage, forKey: "ProfileImage")
        
                    UserDefaults.standard.set(name, forKey: "Name")
                    UserDefaults.standard.set(email, forKey: "Email")
                    UserDefaults.standard.set(mobileNo, forKey: "MobileNo")
                    UserDefaults.standard.set(departmentName, forKey: "DepartmentName")
                    UserDefaults.standard.set(role, forKey: "Role")
                   
                    
                    
                      self.viewDidLoad()
                    
                    

                   SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }


            }else{

                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {

                }



        }

    }

    }

    
    @IBAction func saveBtn(_ sender: Any) {
       
        
        saveServiceCall()
        
        
        
        editBtn.isHidden = false
        saveBtn.isHidden = true
        nameTF.isEnabled = false
        emailTF.isEnabled = false
        mobileNoTF.isEnabled = false
        departmentNameTF.isEnabled = false
      //  roleTF.isEnabled = false
        profileImageBtn.isEnabled = false
        cameraBtn.isEnabled = false
       
     
        
    }
    
    @IBAction func editBtn(_ sender: Any) {
        
        saveBtn.isHidden = false
        nameTF.isEnabled = true
        mobileNoTF.isEnabled = true
        editBtn.isHidden = true
        //profileImageBtn.isEnabled = true
        cameraBtn.isEnabled = true
        
        
        if UserDefaults.standard.object(forKey: "SubDepartmentName") as! String == "Field" || UserDefaults.standard.object(forKey: "SubDepartmentName") as! String == "Warehouse" {
             viewHeight.constant = 1500
        }
        
        
       
        
    }
    
    @IBAction func imageBtn(_ sender: Any) {
        
        let alertController = UIAlertController(title: "Profile Picture", message: "", preferredStyle: .actionSheet)
        
        let sendButton = UIAlertAction(title: "Gallery", style: .default, handler: { (action) -> Void in
            
             let picker = UIImagePickerController()
              picker.delegate = self
            self.picker.sourceType = .photoLibrary
            self.present(self.picker, animated: true, completion: nil)
            
            //dismiss(animated: true, completion: nil)
        })
        
        let  deleteButton = UIAlertAction(title: "Camera", style: .default, handler: { (action) -> Void in
            
            let picker = UIImagePickerController()
            picker.delegate = self
            
            self.picker.sourceType = .camera
            self.present(self.picker, animated: true, completion: nil)
            //dismiss(animated: true, completion: nil)
            
            
        })
      
        
        let cancelButton = UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) -> Void in
            
        })
        
        
        alertController.addAction(sendButton)
        alertController.addAction(deleteButton)
        alertController.addAction(cancelButton)
        
        self.present(alertController, animated: true, completion: nil)
        
    }
    

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        guard let image = info[.originalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        print(image)
      
            imageView.image = image
//            imageView.layer.cornerRadius = 50
//            imageView.clipsToBounds = true
        
        imageView.layer.cornerRadius =  imageView.bounds.size.width / 2
        self.imageView.clipsToBounds = true
        imageView.layer.borderWidth = 1
    
        imageView.layer.borderColor = UIColor.black.cgColor
        
        
        profileImageBtn.layer.cornerRadius =  profileImageBtn.bounds.size.width / 2
        self.profileImageBtn.clipsToBounds = true
        profileImageBtn.layer.borderWidth = 1
      
        profileImageBtn.layer.borderColor = UIColor.black.cgColor
       
       

            let imageData = image.jpegData(compressionQuality: 0.8)
            self.profileIMageData = imageData
        
    }
    
    
    

    
    
}
    


    
    





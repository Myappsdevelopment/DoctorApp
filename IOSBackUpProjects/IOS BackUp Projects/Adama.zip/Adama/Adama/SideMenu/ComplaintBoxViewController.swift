//
//  ComplaintBoxViewController.swift
//  Adama
//
//  Created by MAD-MAC on 17/10/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class ComplaintBoxViewController: UIViewController,UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UICollectionViewDelegate,UICollectionViewDataSource {
 
    
    
    
    @IBOutlet weak var collections: UICollectionView!
    @IBOutlet weak var sideMenuBtn: UIBarButtonItem!
    @IBOutlet weak var viewHeight: NSLayoutConstraint!
    
    
    @IBOutlet weak var productTF: TextField!
    @IBOutlet weak var productSizeTF: TextField!
    @IBOutlet weak var zoneTF: TextField!
    @IBOutlet weak var batchNoTF: TextField!
    @IBOutlet weak var manufacturingTF: TextField!
    @IBOutlet weak var dealerNameTF: TextField!
    @IBOutlet weak var natureOfCompaniesTF: TextField!
    @IBOutlet weak var quantityAffectedTF: TextField!
    @IBOutlet weak var aboutCompanyTF: TextField!
    @IBOutlet weak var mobileNoTF: TextField!
    @IBOutlet weak var dealerCodeTF: TextField!
    
    var selectedTF = UITextField()
    
    let datepicker=UIDatePicker()
    let currentDate = Date()
    let finalFormatter = DateFormatter()
    
    
    let toolBar = UIToolbar()
    let picker = UIPickerView()
    let imagePicker = UIImagePickerController()
    var profileIMageData: Data?
    var selectedAssets=[UIImage]()
    var photoArray = [Data]()
    var selectedIndex: Int = 0
    
    var productId = Int()
    var productSizeId = Int()
    var ZoneId = Int()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        
        let low1 = NotificationCenter.default
        low1.addObserver(self, selector: #selector(userLow), name: Notification.Name("Low1"), object: nil)
     
        let low = NotificationCenter.default
        low.addObserver(self, selector: #selector(prodcutsInfo(_:)), name: Notification.Name("Low2"), object: nil)

        

        
        self.navigationController?.isNavigationBarHidden = false
        self.title = "Complaint Box"
        
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white
        
        
        
        productTF.delegate = self
        productSizeTF.delegate = self
        zoneTF.delegate = self
        manufacturingTF.delegate = self
        natureOfCompaniesTF.delegate = self
        imagePicker.delegate = self
        

        createPicker()
        
    }
    
    @objc func userLow(){
        
        view.removeFromSuperview()
    }
    func createPicker() {
        

        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        self.manufacturingTF.text = dateFormatter.string(from: currentDate)
        
        datepicker.datePickerMode = .date
        datepicker.setDate(Date(), animated: true)
        
 
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action:#selector(donePicker))
        doneButton.tintColor = UIColor.black
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action:#selector(canclePicker))
        cancelButton.tintColor = UIColor.black
        //datepicker.addTarget(self, action: #selector(datePickerValueChange), for:.valueChanged )
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.barTintColor = .white
        
        
        let calendar = NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian);
        
        let components = calendar?.components([NSCalendar.Unit.year,NSCalendar.Unit.month,NSCalendar.Unit.day,NSCalendar.Unit.hour,NSCalendar.Unit.minute], from: currentDate )
        
        let maximumYear = (components?.year)!
        print(maximumYear)
        let maximumMonth = (components?.month)!
        let maximumDay = (components?.day)!
        
        let comps = NSDateComponents()
        comps.year = +maximumYear
        comps.month = +maximumMonth
        comps.day = +maximumDay
        print(comps.day)
        
    
        datepicker.minimumDate = currentDate
        
        
        self.manufacturingTF.inputView = datepicker
        self.manufacturingTF.inputAccessoryView = toolBar
        
        
    }
    
    
    
    
    @objc func donePicker() {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        
        
        if selectedTF == self.manufacturingTF {
            
        
                self.manufacturingTF.text = dateFormatter.string(from: datepicker.date)
                self.manufacturingTF.resignFirstResponder()
            
          
            
        }
        

    }
    
    @objc func canclePicker() {
        
        self.selectedTF.resignFirstResponder()
        
    }
    
    
    @IBAction func cameraBtn(_ sender: Any) {
        let picker = UIImagePickerController()
        picker.delegate = self
        
        self.imagePicker.sourceType = .camera
        self.present(self.imagePicker, animated: true, completion: nil)
        
    }
    
    

    @IBAction func ImageAttachBtn(_ sender: Any) {
        
        
        let alertController = UIAlertController(title: "Attach Image From", message: "", preferredStyle: .actionSheet)
        
        let sendButton = UIAlertAction(title: "Gallery", style: .default, handler: { (action) -> Void in
            
            
            
            self.imagePicker.sourceType = .photoLibrary
            self.present(self.imagePicker, animated: true, completion: nil)
            
            
            
        })
        
        
        let  deleteButton = UIAlertAction(title: "Camera", style: .default, handler: { (action) -> Void in
            let picker = UIImagePickerController()
            picker.delegate = self
            
            self.imagePicker.sourceType = .camera
            self.present(self.imagePicker, animated: true, completion: nil)
            
        })
        
        
        let cancelButton = UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) -> Void in
            
        })
        
        
        alertController.addAction(sendButton)
        alertController.addAction(deleteButton)
        
        alertController.addAction(cancelButton)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        
        guard let image = info[.originalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        print(image)
        
        
        if let imageURL = info[UIImagePickerController.InfoKey.referenceURL] as? NSURL {
         //   let result = PHAsset.fetchAssets(withALAssetURLs: [imageURL as URL], options: nil)
          //  print(result)
            let imageName  = imageURL.lastPathComponent!
            print(imageName)
            self.selectedAssets.append(image)
            
            
            DispatchQueue.main.async {
                self.collections.isHidden = false
                self.collections.reloadData()
                
            }
            let image1 = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
            self.dismiss(animated: true) {
                print(image1 as Any)
            }
            
            
            let imageData = image.jpegData(compressionQuality: 0.8)
            
            print(imageData?.count as Any)
            print(imageData as Any)
            
            
            self.photoArray.append(imageData!)
            
            print("\(photoArray)")
            
            
        }else{
            self.selectedAssets.append(image)
            self.collections.isHidden = false
            DispatchQueue.main.async {
                self.collections.isHidden = false
                self.collections.reloadData()
            }
            let imageData = image.jpegData(compressionQuality: 0.8)
            self.photoArray.append(imageData!)
            
            print("\(photoArray)")
        }
        
        
        
    }
    
    @IBAction func submitBtn(_ sender: Any) {
       
        
        if productTF.text == "" || productTF.text == "-Select-" || productTF.text == "--None--" {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Product Details") {
                self.productTF.becomeFirstResponder()
            }
        }else if productSizeTF.text == "" || productSizeTF.text == "-Select-" || productSizeTF.text == "--None--" {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select ProductSize Details") {
                self.productSizeTF.becomeFirstResponder()
            }
        }else if zoneTF.text == "" || zoneTF.text == "-Select-" || zoneTF.text == "--None--" {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Zone Details") {
                self.zoneTF.becomeFirstResponder()
            }
        }else if !batchNoTF.isValidTextField(){
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Enter Batch No") {
                self.batchNoTF.becomeFirstResponder()
            }
        }else if !dealerNameTF.isValidTextField(){
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Enter Dealer Name") {
                self.dealerNameTF.becomeFirstResponder()
            }
        }else if !dealerCodeTF.isValidTextField(){
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Enter Dealer Code") {
                self.dealerCodeTF.becomeFirstResponder()
            }
        }else if natureOfCompaniesTF.text == "" {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Nature Of Complaint Details") {
                self.natureOfCompaniesTF.becomeFirstResponder()
            }
        }else if !quantityAffectedTF.isValidTextField(){
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Enter Quantity Details") {
                self.quantityAffectedTF.becomeFirstResponder()
            }
        }else if photoArray == []{
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Attach one Proof Picture") {
               
            }
        }else if !aboutCompanyTF.isValidTextField(){
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Enter Brief About Complain") {
                self.aboutCompanyTF.becomeFirstResponder()
            }
        }else if !mobileNoTF.isValidMobileNumberTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Enter Mobile Number") {
                self.mobileNoTF.becomeFirstResponder()
            }
        }else{
            addComplaintService()
            SingleToneClass.shared.showProgressLoading(title: "Please Wait..")
        }
        
    }
    
    
    func addComplaintService()  {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        
        let showDate = dateFormatter.date(from: manufacturingTF.text!)
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let resultString = dateFormatter.string(from: showDate!)
        print(resultString)
      
        let userid = UserDefaults.standard.object(forKey:"UserId") as! Int
        let depid=UserDefaults.standard.object(forKey: "DepartmentId") as! Int
        
        var params:[String:Any] = ["user_id" : userid,
                                   "product" : productId,
                                   "size" : productSizeId,
                                   "zone" : ZoneId,
                                   "batch_no" : batchNoTF.text!,
                                   "m_date" : resultString ,
                                   "dealer_name" : dealerNameTF.text!,
                                   "dealer_code" : dealerCodeTF.text!,
                                   "quantity" : quantityAffectedTF.text!,
                                   "mobile_no" : mobileNoTF.text!,
                                   "nature_of_complaint" : natureOfCompaniesTF.text!,
                                   "description" : aboutCompanyTF.text!,
                                   "login_department_id":depid]
        
        

     
          //   params["proof"] = AGImageUpdate(fileName: "file.jpeg", type: .png, data: self.photoArray)
       
     
        print(params)
     
        
        Service.shared.makeUploadRequest1(serviceType: API.addComplaint, parameters: params) { response in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                
                if responseDetails["status"] == 200 {
                    
                    self.productTF.text = ""
                    self.productSizeTF.text = ""
                    self.zoneTF.text = ""
                    self.batchNoTF.text = ""
                    self.dealerNameTF.text = ""
                    self.natureOfCompaniesTF.text = ""
                    self.quantityAffectedTF.text = ""
                    self.aboutCompanyTF.text = ""
                    self.mobileNoTF.text = ""
                   
                    self.photoArray.removeAll()
                    

                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
                    SingleToneClass.shared.dismissProgressLoading(WithDelay: 0.50)
                    
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
        }
        
    }
    
    
    
    
    
    
    
    @objc func prodcutsInfo(_ notification: NSNotification){
        
//       view.removeFromSuperview()
      
        if let dict = notification.userInfo as NSDictionary? {
            if let name = dict["product"] as? String{
                let id = dict["id"] as! Int
                let a = dict["TextfieldTag"] as! Int
                print(a)
                if a == 1 {
                    self.productTF.text = name
                    productId = id
                    print(productId)
                }else if a == 2 {
                    self.productSizeTF.text = name
                    productSizeId = id
                    print(productSizeId)
                }else if a == 3 {
                    self.zoneTF.text = name
                    ZoneId = id
                    print(ZoneId)
                }else if a == 4 {
                    self.natureOfCompaniesTF.text = name
                }
                
                

            }
        }
        
    }
    
   
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if photoArray.count == 0 {
            self.collections.isHidden = true
            viewHeight.constant = 850
           // self.attachmentLbl.text = "0 Files Selected"
        }else{
            viewHeight.constant = 1050
        }
        print(photoArray.count)
        return photoArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ComplaintBoxCollectionViewCell
        
        cell.selectedImage.image = selectedAssets[indexPath.row]
        cell.imageView.layer.cornerRadius = 10
        cell.imageView.layer.borderWidth = 1
        cell.imageView.layer.borderColor = UIColor.black.cgColor
        
//        DispatchQueue.main.async {
//          //  self.attachmentLbl.text = "\(self.selectedAssets.count) Files Selected"
//        }
        
        cell.deleteBtn.tag = indexPath.row
        cell.deleteBtn.addTarget(self, action: #selector(self.downArrowTapped(_:)), for: .touchUpInside)
        
        return cell
    }
    
    @objc func downArrowTapped(_ sender: UIButton) {
        
        
        if self.selectedIndex == sender.tag {
            self.selectedIndex = sender.tag
            selectedAssets.remove(at: sender.tag)
            photoArray.remove(at: sender.tag)
            print(photoArray)
        }else{
            self.selectedIndex = 0
            //  let row=IndexPath.row
            selectedAssets.remove(at: sender.tag)
            photoArray.remove(at: sender.tag)
            
        }
        self.collections.reloadData()
    }
    
    
    
    
    
    
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        print(photoArray.count)
//        return photoArray.count
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ComplaintImagesTableViewCell
//
//        print(selectedAssets.count)
//        // let some=String(selectedAssets.count)
//        cell.ImageNameLbl.text = selectedAssets[indexPath.row]
////        DispatchQueue.main.async {
////            self.attachmentLbl.text = "\(self.selectedAssets.count) Files Selected"
////        }
//
//        return cell
//    }
//
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let row=indexPath.row
//        selectedAssets.remove(at: row)
//        photoArray.remove(at: row)
//        table.reloadData()
//        print(photoArray)
//        print(selectedAssets)
//    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        self.selectedTF = textField
        
        return true
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == self.productTF || textField == self.productSizeTF || textField == self.zoneTF || textField == self.natureOfCompaniesTF {
            
            let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
             POPUPVC.tagValue = textField.tag
            SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
            self.addChild(POPUPVC)
            POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
            self.view.addSubview(POPUPVC.view)
            POPUPVC.didMove(toParent: self)
             self.selectedTF.resignFirstResponder()
            
            
 
        
           
        }
        
    }
    
    
}

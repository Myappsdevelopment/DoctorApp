//
//  SideMenuViewController.swift
//  Adama
//
//  Created by MAD-MAC on 26/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import Kingfisher

class SideMenuViewController: UIViewController {
  

    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var adminLbl: UILabel!
    @IBOutlet weak var managementLbl: UILabel!
    @IBOutlet weak var ticketBtn: UIButton!
    @IBOutlet weak var dashboardBtn: UIButton!
    @IBOutlet weak var knowledgeBtn: UIButton!
    @IBOutlet weak var profileBtn: UIButton!
    @IBOutlet weak var changePasswordBtn: UIButton!
    @IBOutlet weak var customerComplaintBtn: UIButton!
    @IBOutlet weak var assignedComplaintBtn: UIButton!
    @IBOutlet weak var submittedComplaintBtn: UIButton!
    @IBOutlet weak var notificationBtn: UIButton!
    @IBOutlet weak var reportsBtn: UIButton!
    @IBOutlet weak var logoutBtn: UIButton!
    
    
    @IBOutlet weak var complaintReportBtn: UIButton!
    
    
    let loginType = UserDefaults.standard.object(forKey: "UserType") as! Int
    let departmentName = UserDefaults.standard.object(forKey: "DepartmentName") as! String
    let location = UserDefaults.standard.object(forKey: "Location") as! String
    
    
      let green = UIColor(red: 28/255, green: 180/255, blue: 80/255, alpha: 1.0)
      let white = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1.0)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.isNavigationBarHidden = true
        

        
        profileImage.layer.borderWidth = 1
        profileImage.layer.masksToBounds = false
        profileImage.layer.borderColor = UIColor.black.cgColor
        profileImage.layer.cornerRadius = profileImage.frame.height/2
        profileImage.clipsToBounds = true

        
        if let picture = UserDefaults.standard.object(forKey: "ProfileImage"){
            
            let imageRes = ImageResource(downloadURL: URL(string: picture as! String)!)
            print(imageRes)
            
            profileImage.kf.setImage(with: imageRes)
            print(profileImage as Any)

        }
        
        self.nameLbl.text = UserDefaults.standard.object(forKey: "Name") as? String
        self.adminLbl.text = UserDefaults.standard.object(forKey: "EmployeeId") as? String
       
        self.managementLbl.text = UserDefaults.standard.object(forKey: "DepartmentName") as? String
        
        
        
        if loginType == 2 || loginType == 5 {
            dashboardBtn.isHidden = false
        }else{
            dashboardBtn.isHidden = true
        }
        
        
        if loginType == 2 && departmentName == "Plant" || location == "Plant" {
            customerComplaintBtn.isHidden = false
        }else{
            customerComplaintBtn.isHidden = true
        }
        
        if departmentName == "Plant" || location == "Plant" {
            if loginType != 2 {
                assignedComplaintBtn.isHidden = false
            }else{
                assignedComplaintBtn.isHidden = true
            }
        }else{
            assignedComplaintBtn.isHidden = true
        }
        
        
        if loginType == 2 {
            reportsBtn.isHidden = false
        }else{
            reportsBtn.isHidden = true
        }
        
        if DetailsStore.ticket == true {
            self.ticketBtn.setTitleColor(white, for: [])
            self.ticketBtn.backgroundColor = green
        }else if DetailsStore.dashboard == true {
            self.dashboardBtn.setTitleColor(white, for: [])
            self.dashboardBtn.backgroundColor = green
        }else if DetailsStore.knowledgeBase == true {
            self.knowledgeBtn.setTitleColor(white, for: [])
            self.knowledgeBtn.backgroundColor = green
        }else if DetailsStore.profile == true{
            self.profileBtn.setTitleColor(white, for: [])
            self.profileBtn.backgroundColor = green
        }else if DetailsStore.changePassword == true {
            self.changePasswordBtn.setTitleColor(white, for: [])
            self.changePasswordBtn.backgroundColor = green
        }else if DetailsStore.customerComplaintSideMenu == true {
            self.customerComplaintBtn.setTitleColor(white, for: [])
            self.customerComplaintBtn.backgroundColor = green
        }else if DetailsStore.assignedComplaintSideMenu == true {
            self.assignedComplaintBtn.setTitleColor(white, for: [])
            self.assignedComplaintBtn.backgroundColor = green
        }else if DetailsStore.submittedComplaintSideMenu == true {
            self.submittedComplaintBtn.setTitleColor(white, for: [])
            self.submittedComplaintBtn.backgroundColor = green
        }else if DetailsStore.notification == true {
            self.notificationBtn.setTitleColor(white, for: [])
            self.notificationBtn.backgroundColor = green
        }else if DetailsStore.reports == true {
            self.reportsBtn.setTitleColor(white, for: [])
            self.reportsBtn.backgroundColor = green
        }else if DetailsStore.complaintReports == true {
            self.complaintReportBtn.setTitleColor(white, for: [])
            self.complaintReportBtn.backgroundColor = green
        }
        
        
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func ticketBtn(_ sender: Any) {
        
          self.ticketBtn.setTitleColor(white, for: [])
          self.ticketBtn.backgroundColor = green
          
        DetailsStore.ticket = true
            DetailsStore.dashboard = false
            DetailsStore.knowledgeBase = false
            DetailsStore.profile = false
            DetailsStore.changePassword = false
            DetailsStore.customerComplaintSideMenu = false
            DetailsStore.assignedComplaintSideMenu = false
            DetailsStore.submittedComplaintSideMenu = false
            DetailsStore.notification = false
            DetailsStore.reports = false
            DetailsStore.complaintReports = false
        

        
        let emp = storyboard?.instantiateViewController(withIdentifier: "MPIViewController") as! MPIViewController
        
                    DetailsStore.pending = false
                    DetailsStore.resolved = false
                    DetailsStore.highPriority = false
                    DetailsStore.overdue = false
                    DetailsStore.unassigned = false
                    DetailsStore.reassigned = false
        
        
        navigationController?.pushViewController(emp, animated: true)
        
 
    }
    
    
    
    @IBAction func dashboardBtn(_ sender: Any) {
        
        self.dashboardBtn.setTitleColor(white, for: [])
         self.dashboardBtn.backgroundColor = green
        
        DetailsStore.ticket = false
        DetailsStore.dashboard = true
        DetailsStore.knowledgeBase = false
        DetailsStore.profile = false
        DetailsStore.changePassword = false
        DetailsStore.customerComplaintSideMenu = false
        DetailsStore.assignedComplaintSideMenu = false
        DetailsStore.submittedComplaintSideMenu = false
        DetailsStore.notification = false
        DetailsStore.reports = false
        DetailsStore.complaintReports = false
        
    let vc = storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    
    
    @IBAction func knowledgeBaseBtn(_ sender: Any) {
        
        self.knowledgeBtn.setTitleColor(white, for: [])
         self.knowledgeBtn.backgroundColor = green
        
        
        DetailsStore.ticket = false
        DetailsStore.dashboard = false
        DetailsStore.knowledgeBase = true
        DetailsStore.profile = false
        DetailsStore.changePassword = false
        DetailsStore.customerComplaintSideMenu = false
        DetailsStore.assignedComplaintSideMenu = false
        DetailsStore.submittedComplaintSideMenu = false
        DetailsStore.notification = false
        DetailsStore.reports = false
          DetailsStore.complaintReports = false
        
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "KBViewController") as! KBViewController
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    
    @IBAction func profileBtn(_ sender: Any) {
        
        
        self.profileBtn.setTitleColor(white, for: [])
        self.profileBtn.backgroundColor = green
       
        
        DetailsStore.ticket = false
        DetailsStore.dashboard = false
        DetailsStore.knowledgeBase = false
        DetailsStore.profile = true
        DetailsStore.changePassword = false
        DetailsStore.customerComplaintSideMenu = false
        DetailsStore.assignedComplaintSideMenu = false
        DetailsStore.submittedComplaintSideMenu = false
        DetailsStore.notification = false
        DetailsStore.reports = false
          DetailsStore.complaintReports = false
        
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "ProfileViewController")
        navigationController?.pushViewController(vc!, animated: true)
        
    }
    
    
    
    @IBAction func changePasswordBtn(_ sender: Any) {
        
        self.changePasswordBtn.setTitleColor(white, for: [])
        self.changePasswordBtn.backgroundColor = green
        
        
        DetailsStore.ticket = false
        DetailsStore.dashboard = false
        DetailsStore.knowledgeBase = false
        DetailsStore.profile = false
        DetailsStore.changePassword = true
        DetailsStore.customerComplaintSideMenu = false
        DetailsStore.assignedComplaintSideMenu = false
        DetailsStore.submittedComplaintSideMenu = false
        DetailsStore.notification = false
        DetailsStore.reports = false
          DetailsStore.complaintReports = false
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "ResetPasswordViewController")
        navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    
    
    @IBAction func customerComplaintBtn(_ sender: Any) {
        
        self.customerComplaintBtn.setTitleColor(white, for: [])
        self.customerComplaintBtn.backgroundColor = green
        
        
        DetailsStore.ticket = false
        DetailsStore.dashboard = false
        DetailsStore.knowledgeBase = false
        DetailsStore.profile = false
        DetailsStore.changePassword = false
        DetailsStore.customerComplaintSideMenu = true
        DetailsStore.assignedComplaintSideMenu = false
        DetailsStore.submittedComplaintSideMenu = false
        DetailsStore.notification = false
        DetailsStore.reports = false
          DetailsStore.complaintReports = false
        
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "ComplaintListViewController")
                DetailsStore.assignedComplaint = false
                DetailsStore.submittedComplaint = false
                DetailsStore.customerComplaint = true
        navigationController?.pushViewController(vc!, animated: true)
        
        
        
    }
    
    
    @IBAction func assignedComplaintBtn(_ sender: Any) {
        
        self.assignedComplaintBtn.setTitleColor(white, for: [])
        self.assignedComplaintBtn.backgroundColor = green
        
        
        DetailsStore.ticket = false
        DetailsStore.dashboard = false
        DetailsStore.knowledgeBase = false
        DetailsStore.profile = false
        DetailsStore.changePassword = false
        DetailsStore.customerComplaintSideMenu = false
        DetailsStore.assignedComplaintSideMenu = true
        DetailsStore.submittedComplaintSideMenu = false
        DetailsStore.notification = false
        DetailsStore.reports = false
          DetailsStore.complaintReports = false
        
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "ComplaintListViewController")
        
            DetailsStore.assignedComplaint = true
            DetailsStore.submittedComplaint = false
            DetailsStore.customerComplaint = false
        
        navigationController?.pushViewController(vc!, animated: true)
        
        
        
    }
    
    
    @IBAction func submittedComplaintBtn(_ sender: Any) {
        
        self.submittedComplaintBtn.setTitleColor(white, for: [])
        self.submittedComplaintBtn.backgroundColor = green
        
        
        DetailsStore.ticket = false
        DetailsStore.dashboard = false
        DetailsStore.knowledgeBase = false
        DetailsStore.profile = false
        DetailsStore.changePassword = false
        DetailsStore.customerComplaintSideMenu = false
        DetailsStore.assignedComplaintSideMenu = false
        DetailsStore.submittedComplaintSideMenu = true
        DetailsStore.notification = false
        DetailsStore.reports = false
          DetailsStore.complaintReports = false
        
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "ComplaintListViewController")
        
                DetailsStore.submittedComplaint = true
                DetailsStore.assignedComplaint = false
                DetailsStore.customerComplaint = false
        navigationController?.pushViewController(vc!, animated: true)
        
        
        
    }
    
    
    @IBAction func notificationBtn(_ sender: Any) {
        
        self.notificationBtn.setTitleColor(white, for: [])
        self.notificationBtn.backgroundColor = green
        
        
        DetailsStore.ticket = false
        DetailsStore.dashboard = false
        DetailsStore.knowledgeBase = false
        DetailsStore.profile = false
        DetailsStore.changePassword = false
        DetailsStore.customerComplaintSideMenu = false
        DetailsStore.assignedComplaintSideMenu = false
        DetailsStore.submittedComplaintSideMenu = false
        DetailsStore.notification = true
        DetailsStore.reports = false
          DetailsStore.complaintReports = false
        
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "NotificationViewController")
        navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    @IBAction func reportBtn(_ sender: Any) {
        self.reportsBtn.setTitleColor(white, for: [])
        self.reportsBtn.backgroundColor = green
        
        DetailsStore.ticket = false
        DetailsStore.dashboard = false
        DetailsStore.knowledgeBase = false
        DetailsStore.profile = false
        DetailsStore.changePassword = false
        DetailsStore.customerComplaintSideMenu = false
        DetailsStore.assignedComplaintSideMenu = false
        DetailsStore.submittedComplaintSideMenu = false
        DetailsStore.notification = false
        DetailsStore.reports = true
        DetailsStore.complaintReports = false
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "ReportViewController") as! ReportViewController
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    @IBAction func complaintReportBtn(_ sender: Any) {
        
            self.complaintReportBtn.setTitleColor(white, for: [])
            self.complaintReportBtn.backgroundColor = green
              
              DetailsStore.ticket = false
              DetailsStore.dashboard = false
              DetailsStore.knowledgeBase = false
              DetailsStore.profile = false
              DetailsStore.changePassword = false
              DetailsStore.customerComplaintSideMenu = false
              DetailsStore.assignedComplaintSideMenu = false
              DetailsStore.submittedComplaintSideMenu = false
              DetailsStore.notification = false
              DetailsStore.reports = false
              DetailsStore.complaintReports = true
              
              let vc = storyboard?.instantiateViewController(withIdentifier: "ReportViewController") as! ReportViewController
              navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func logoutBtn(_ sender: Any) {
        
        let alert = UIAlertController(title: "LOGOUT", message: "Are you sure,you want to exit?", preferredStyle: .alert)
        
        
        
        alert.addAction(UIAlertAction(title: "Yes", style: .cancel, handler: { (confirmAction) in
        
            UserDefaults.standard.removePersistentDomain(forName:Bundle.main.bundleIdentifier!)
                UserDefaults.standard.synchronize()
        
        
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController")
        
                self.navigationController?.pushViewController(vc!, animated: true)
            
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: "LogOut Successful")
            
                SingleToneClass.shared.dismissProgressLoading(WithDelay: 5)
        
        
        }))
        
        
        alert.addAction(UIAlertAction(title: "No", style: .default, handler: { (cancelAction) in }))
        
        
        present(alert, animated: true, completion: nil)
        
        }
    
 
 
  
}

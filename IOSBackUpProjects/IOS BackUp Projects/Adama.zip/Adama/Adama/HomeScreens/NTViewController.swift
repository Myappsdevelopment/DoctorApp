//
//  NTViewController.swift
//  Adama
//
//  Created by MatrixStream_01 on 29/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import Photos
import AssetsLibrary
import AVFoundation
import Alamofire
import MobileCoreServices


class NTViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIDocumentPickerDelegate {

   
    @IBOutlet weak var boxNoTF: TextField!
   
    @IBOutlet weak var view2Height: NSLayoutConstraint!
    
    @IBOutlet weak var collectionView2: UICollectionView!
    @IBOutlet weak var view1Height: NSLayoutConstraint!
    @IBOutlet weak var collections: UICollectionView!
    
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var priorityTF: TextField!
    @IBOutlet weak var departmentTF: TextField!
    @IBOutlet weak var subDepartmentTF: TextField!
    @IBOutlet weak var categoryTF: TextField!
    @IBOutlet weak var subCategoryTF: TextField!
    
    @IBOutlet weak var descriptionTV: UITextView!
    
    @IBOutlet weak var attachmentBtn: UIButton!
    @IBOutlet weak var attachmentLbl: UILabel!
    
    
    @IBOutlet weak var submitBtn: UIButton!
    @IBOutlet weak var productNameTF: TextField!
    @IBOutlet weak var packageSizeTF: TextField!
    @IBOutlet weak var wareHouseTF: TextField!
    @IBOutlet weak var batchNoTF: TextField!
    @IBOutlet weak var manufactureTF: TextField!
    @IBOutlet weak var dealerNameTF: TextField!
    @IBOutlet weak var dealerCodeTF: TextField!
    @IBOutlet weak var natureTF: TextField!
    @IBOutlet weak var qualityAffectTF: TextField!
    @IBOutlet weak var briefAboutTF: TextField!
    @IBOutlet weak var mobileNoTF: TextField!
    @IBOutlet weak var priorityLbl: UILabel!
    
    
     let picker = UIPickerView()
     let toolBar = UIToolbar()
     var selectedTF = UITextField()
     var profileIMageData: Data?

    var KnowledgeBase = String()
    
    
    var departmentId:[Int]=[0]
    var departmentNames:[String]=["-Select-"]
    
   
    var subDepartmentId:[Int]=[0]
    var subDepartmentNames:[String]=["-Select-"]
   
    var subSubDepartmentId:[Int]=[]
    var subSubDepartmentNames:[String]=[]
  
    
    var selectedDepartmentId:Int?
    var selectedSubDepartmentId:Int?
    var selectedSubSubDepartmentId:Int?
   
    
    var selectedAssets=[UIImage]()
    var imagePath = UIImage ()
    var selectedAssetsName=[String]()
    var photoArray = [Data]()
    var mediaFileArray = [AGImageUpdate]()
    var imageFormatDisplay=[String]()
    var videoURL: NSURL?
    var imageValue = 0
    
    var priorityValue = 0
    var selectedIndex: Int = 0
    
    var priorityArray = ["Low","Medium","High"]

    
    let datepicker=UIDatePicker()
    let currentDate = Date()
    let finalFormatter = DateFormatter()
    
    
    var productId = Int()
    var productSizeId = Int()
    var ZoneId = Int()
    
    
    let userId = UserDefaults.standard.object(forKey: "UserId") as! Int
    let loginDepartmentId = UserDefaults.standard.object(forKey: "DepartmentId") as! Int
    let createdBy = UserDefaults.standard.object(forKey: "CreatedBy") as! Int
  
    
    override func viewWillAppear(_ animated: Bool) {
        
          let imgBack = UIImage(named:"Arrow")
          navigationController?.navigationBar.backIndicatorImage = imgBack
      navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
        
          navigationItem.leftItemsSupplementBackButton = true
      navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
          self.navigationController?.isNavigationBarHidden = false
          self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
          self.navigationController?.navigationBar.tintColor = .white
      self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
          self.navigationController?.navigationBar.isTranslucent = false
   
      
        if DetailsStore.page == true {
            self.title = "Add Task"
            self.subCategoryTF.isHidden = true
            self.subCategoryTF.isHidden = true
            
          
        }else{
            
           
            if KnowledgeBase == "1" {
                 self.title = "Knowledge Base"
                descriptionTV.isHidden = true
                priorityLbl.text = " Title"
                priorityTF.placeholder = " Title"
               priorityTF.rightImage = nil
              
                
            }else{
                 self.title = "Add Ticket"
                priorityTF.isHidden = false
                priorityLbl.text = "  Priority"
                descriptionTV.text = "  Issue Description"
               
            }
        }
        
        
    }
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
        
        
        descriptionTV.layer.borderWidth = 0.5
        descriptionTV.layer.borderColor = UIColor.white.cgColor
        submitBtn.layer.cornerRadius = 10
        
        subCategoryTF.delegate = self
        departmentTF.delegate = self
        categoryTF.delegate = self
        subDepartmentTF.delegate = self
        priorityTF.delegate = self
        descriptionTV.delegate = self
        

        productNameTF.delegate = self
        packageSizeTF.delegate = self
        wareHouseTF.delegate = self
        manufactureTF.delegate = self
        natureTF.delegate = self
      
        
        
        let low = NotificationCenter.default
        low.addObserver(self, selector: #selector(prodcutsInfo(_:)), name: Notification.Name("Low1"), object: nil)
        
    
        createPicker()
        
        
        
        // Do any additional setup after loading the view.
    }

    
    @objc func prodcutsInfo(_ notification: NSNotification){
        
        if let dict = notification.userInfo as NSDictionary? {
            
            print(dict)
            if let name = dict["product"] as? String{
                let id = dict["id"] as! Int
                let a = dict["TextfieldTag"] as! Int
            
                if a == 5 {
                    self.departmentTF.text = name
                   Ids.departmentIds = id
                    
                    
                    print(Ids.departmentIds)
                    if collections.isHidden == true {
                        view1Height.constant = 300
                    }else{
                        view1Height.constant = 500
                    }
                    
                    
                }else if a == 6 {
                    self.subDepartmentTF.text = name
                    Ids.subDepartmentIds = id
                    print(Ids.subDepartmentIds)
                    
                    if collections.isHidden == true {
                        view1Height.constant = 300
                    }else{
                        view1Height.constant = 500
                    }
                    
                }else if a == 7 {
                 
                    self.categoryTF.text = name
                    Ids.categoryIds = "\(id)"
                    print(Ids.categoryIds)
                    
                    if KnowledgeBase != "1" {
                 
                    if categoryTF.text == "Customer Complaints" {
                        view1.isHidden = false
                        view1Height.constant = 725
                        collectionView2.isHidden = true
                        

                    }else{
                        
                        view1.isHidden = true
              
                        if collections.isHidden == true {
                            view1Height.constant = 300
                        }else{
                            view1Height.constant = 500
                        }
                     }
                   }
                }else if a == 8{
                    self.subCategoryTF.text = name
                    Ids.subCategoryIds = id
                    print(Ids.categoryIds)
                    
                    if collections.isHidden == true {
                        view1Height.constant = 300
                    }else{
                        view1Height.constant = 500
                    }
                    
                }else if a == 9{
                    self.priorityTF.text = name
                    Ids.priorityIds = "\(id)"
                    print(Ids.priorityIds)
                    
                    if collections.isHidden == true {
                        view1Height.constant = 300
                    }else{
                        view1Height.constant = 500
                    }
                    
                }else   if a == 15 {
                    self.productNameTF.text = name
                    productId = id
                    print(productId)
                }else if a == 16 {
                    self.packageSizeTF.text = name
                    productSizeId = id
                    print(productSizeId)
                }else if a == 17 {
                    self.wareHouseTF.text = name
                    ZoneId = id
                    print(ZoneId)
                }else if a == 18 {
                    self.natureTF.text = name
                }
                
                
                
            }
        }
        
    }
    

    
    func createPicker() {
        
        
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        self.manufactureTF.text = dateFormatter.string(from: currentDate)
        
        datepicker.datePickerMode = .date
        datepicker.setDate(Date(), animated: true)
        
        
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action:#selector(donePicker))
        doneButton.tintColor = UIColor.black
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action:#selector(canclePicker))
        cancelButton.tintColor = UIColor.black
       
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.barTintColor = .white
        
        
        let calendar = NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian);
        
        let components = calendar?.components([NSCalendar.Unit.year,NSCalendar.Unit.month,NSCalendar.Unit.day,NSCalendar.Unit.hour,NSCalendar.Unit.minute], from: currentDate )
        
        let maximumYear = (components?.year)!
        print(maximumYear)
        let maximumMonth = (components?.month)!
        let maximumDay = (components?.day)!
        
        let comps = NSDateComponents()
        comps.year = +maximumYear
        comps.month = +maximumMonth
        comps.day = +maximumDay
        print(comps.day)
        
        
        datepicker.minimumDate = currentDate
        
        
        self.manufactureTF.inputView = datepicker
        self.manufactureTF.inputAccessoryView = toolBar
        
        
    }
    
    
    
    
    @objc func donePicker() {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        
        
        if selectedTF == self.manufactureTF {
            
            
            self.manufactureTF.text = dateFormatter.string(from: datepicker.date)
            self.manufactureTF.resignFirstResponder()
            
            
            
        }
        
        
    }
    
    @objc func canclePicker() {
        
        self.selectedTF.resignFirstResponder()
        
    }
    
   
    
    @IBAction func camera(_ sender: Any) {
        
        DetailsStore.camera = true
        
        let picker = UIImagePickerController()
        picker.delegate = self
        
        picker.sourceType = .camera
        self.present(picker, animated: true, completion: nil)
        
        
    }
    

    @IBAction func attachmentBtn(_ sender: Any) {
        
        DetailsStore.camera = false
        
        let alertController = UIAlertController(title: "Choose Attach File", message: "", preferredStyle: .actionSheet)
    
        
        let cameraButton = UIAlertAction(title: "Camera", style: .default, handler: { (action) -> Void in
            
            let picker = UIImagePickerController()
            picker.delegate = self
             DetailsStore.camera = true
            picker.sourceType = .camera
            self.present(picker, animated: true, completion: nil)
            
        })
        
            let imageButton = UIAlertAction(title: "Gallery", style: .default, handler: { (action) -> Void in
        
                let picker = UIImagePickerController()
                picker.delegate = self
   
                picker.sourceType = UIImagePickerController.SourceType.photoLibrary
                self.present(picker, animated: true, completion: nil)
            
            

        })
        
        let videoButton = UIAlertAction(title: "Video Library", style: .default, handler: { (action) -> Void in
          
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.mediaTypes = [kUTTypeMovie as String, kUTTypeVideo as String]
            
            self.present(picker, animated: true, completion: nil)
          
            
            
        })
        
   
        let  documentButton = UIAlertAction(title: "Document", style: .default, handler: { (action) -> Void in

            let documentPicker = UIDocumentPickerViewController(documentTypes: ["public.text", "com.apple.iwork.pages.pages", "public.data"], in: .import)
           
            documentPicker.delegate = self
            self.present(documentPicker, animated: true, completion: nil)

        })


        let cancelButton = UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) -> Void in

        })
        
        alertController.addAction(cameraButton)
        alertController.addAction(imageButton)
        alertController.addAction(videoButton)
        alertController.addAction(documentButton)
        alertController.addAction(cancelButton)
        
        self.present(alertController, animated: true, completion: nil)

        
    }
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {

       // let cico = url as URL
       
        if self.view1.isHidden == true{
            self.collections.isHidden = false
            self.attachmentLbl.isHidden = false
            self.collections.reloadData()
            
        }else{
            self.collectionView2.isHidden = false
          
            self.collectionView2.reloadData()
        }
        
        
        do{
            
            self.imagePath = UIImage(named:"50")!
            self.imageFormatDisplay.append(url.pathExtension)
            self.selectedAssets.append(imagePath)
            
            
            let filePath = url //URL of the PDF
            let fileExtension = filePath.pathExtension
            let name  = "file." + fileExtension
            let fileData = try Data.init(contentsOf: filePath)
            let media =  AGImageUpdate(fileName: name, type: fileExtension, data: fileData)
            mediaFileArray.append(media)
        
            
        }
        catch{

            print(error)
        }
        


    }
    
    
   
 //   fileprivate var currentVC: UIViewController?
    //MARK: - Internal Properties
    var imagePickedBlock: ((UIImage) -> Void)?
    var videoPickedBlock: ((NSURL) -> Void)?
    var filePickedBlock: ((URL) -> Void)?
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
        
        picker.dismiss(animated: true, completion: nil)
    
        if DetailsStore.camera == false {
        
        
        //  To handle image
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            print(image)
            self.imagePickedBlock?(image)
            self.imagePath = image
            self.imageFormatDisplay.append("")
            print(imagePath)

             let imgUrl = info[UIImagePickerController.InfoKey.imageURL] as? URL
            print(imgUrl as Any)
                if let imageData = imagePath.jpegData(compressionQuality: 0.8) {
                     print(imageData)
                    let fileExtension = imgUrl?.pathExtension
                    let name  = "\(String(describing: imgUrl))" + (fileExtension ?? "jpg")
                    print(name)
                    let media =  AGImageUpdate(fileName: name, type: fileExtension ?? "jpg", data: imageData)
                    print(media)
                    mediaFileArray.append(media)
                }
                
        } else{
            print("Something went wrong in  image")

        }
            
    
        // To handle video
        if let videoUrl = info[UIImagePickerController.InfoKey.mediaURL] as? NSURL  {
            print("videourl: ", videoUrl)
            
          
              let fileExtension = videoUrl.pathExtension
              self.imagePath = UIImage(named:"50")!
              self.imageFormatDisplay.append(fileExtension!)
            
            
            //trying compression of video
              let data = NSData(contentsOf: videoUrl as URL)!
              let name  = "file." + (fileExtension ?? "MOV")
              let media =  AGImageUpdate(fileName: name, type: fileExtension ?? "MOV", data: data as Data )
                      
              mediaFileArray.append(media)
   
        }else{
          
            print("Something went wrong in  video")
            
        }
        
        
            self.selectedAssets.append(imagePath)
           
        
            DispatchQueue.main.async {
                if self.view1.isHidden == true{
                    self.collections.isHidden = false
                    self.attachmentLbl.isHidden = false
                    self.collections.reloadData()
        
                }else{
                    self.collectionView2.isHidden = false
                    self.collectionView2.reloadData()
                }
            }
    
            
        }else{
            
            if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
                self.imagePickedBlock?(image)
                self.imagePath = image
                print(imagePath)
                self.imageFormatDisplay.append("")
                

                let imgUrl = info[UIImagePickerController.InfoKey.imageURL] as? URL
                print(imgUrl as Any)
                 
                    if let imageData = imagePath.jpegData(compressionQuality: 0.8) {
                        print(imageData)
                      //  let fileExtension = imgUrl?.pathExtension
                       imageValue = imageValue+1
                        let name  = "Image\(imageValue)." + ("jpg")
                        print(name)
                        let media =  AGImageUpdate(fileName: name, type: "jpg", data: imageData)
                        print(media)
                                          
                        mediaFileArray.append(media)
                   
                }
                    
            } else{
                print("Something went wrong in  image")

            }
                
            
            self.selectedAssets.append(imagePath)
           
            
            DispatchQueue.main.async {
                
                if self.view1.isHidden == true{
                    
                    self.collections.isHidden = false
                    self.attachmentLbl.isHidden = false
                    self.collections.reloadData()

                }else{
                    
                    self.collectionView2.isHidden = false
                    self.collectionView2.reloadData()
                }
            }
            
        }
        
    }
    
    


    
    @IBAction func submitBtn(_ sender: Any) {
    
        if DetailsStore.page == true {
                
            if !subCategoryTF.isValidTextField() {
                    
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select SubCategory") {
                self.subCategoryTF.becomeFirstResponder()
                }
                    
            }else{
                    
                print(priorityValue as Any)
                SingleToneClass.shared.showProgressLoading(title: "Please wait...")
        
                submitAddTaskBtnService()
            }
        }else{
                
            if KnowledgeBase == "1"{
                    
                if !departmentTF.isValidTextField() {
                        
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Department") {
                    self.departmentTF.becomeFirstResponder()
                    }
                        
            }else if !subDepartmentTF.isValidTextField() {
                        
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select SubDepartment") {
                    self.subDepartmentTF.becomeFirstResponder()
                    }
                        
            }else if !categoryTF.isValidTextField() {
                        
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Category") {
                    self.categoryTF.becomeFirstResponder()
                    }
                        
            }else if !subCategoryTF.isValidTextField() {
                        
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select SubCategory") {
                    self.subCategoryTF.becomeFirstResponder()
                    }
                        
            }else if !priorityTF.isValidTextField() {
                        
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Enter Title") {
                    self.priorityTF.becomeFirstResponder()
                    }
                        
            }else{
                        
                    SingleToneClass.shared.showProgressLoading(title: "Please wait...")
                        
                    addKnowledgeService()
                    }
                    
                    
                    
        }else{
                    
            if !departmentTF.isValidTextField() {
                        
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Department") {
                self.departmentTF.becomeFirstResponder()
                }
                        
        }else if !subDepartmentTF.isValidTextField() {
                        
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select SubDepartment") {
                self.subDepartmentTF.becomeFirstResponder()
                }
                        
        }else if !categoryTF.isValidTextField() {
                        
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Category") {
                self.categoryTF.becomeFirstResponder()
                }
                        
        }else if !subCategoryTF.isValidTextField() {
                        
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select SubCategory") {
                self.subCategoryTF.becomeFirstResponder()
                }
                        
        }else if !priorityTF.isValidTextField() {
                        
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select priority") {
                self.priorityTF.becomeFirstResponder()
                }
                        
        }else{
                
                SingleToneClass.shared.showProgressLoading(title: "Please wait...")
                        
                submitAddTicketBtnService()
                        
                }
            }
            
        }
        
        
    }
    
    
    
    
    

    func submitAddTicketBtnService()  {
    
       
        if priorityTF.text == "High" {
            Ids.priorityIds = "2"
        }else if priorityTF.text == "Low" {
            Ids.priorityIds = "1"
        }else {
            Ids.priorityIds = "3"
        }
        
     

          var params:[String:Any] = ["department_id": Ids.departmentIds ,"login_department_id":loginDepartmentId,"description":self.descriptionTV.text!,"user_id":userId,"priority":Ids.priorityIds,"created_by":userId,"sub_department_id":Ids.subDepartmentIds,"sub_sub_department_id":Ids.categoryIds,"subcategory_id":Ids.subCategoryIds]

          print(params)



        params["attachment[]"] = mediaFileArray
          print(params)

          Service.shared.makeUploadRequest1(serviceType: API.addTicket, parameters: params) { response in
        

        
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
             
                if responseDetails["status"] == 200 {
                    
                    let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
                    let gotoOTP = storyBoard.instantiateViewController(withIdentifier: "MPIViewController") as! MPIViewController
                    self.navigationController?.pushViewController(gotoOTP, animated: true)
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
                SingleToneClass.shared.dismissProgressLoading(WithDelay: 0.50)
                    
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
        }

    }

    
    
    func submitAddTaskBtnService()  {

        
        let params =  ["department_id": "\(Ids.departmentIds)" ,"login_department_id":"\(loginDepartmentId)","description":self.descriptionTV.text!,"user_id":"\(userId)","priority":"\(Ids.priorityIds)","created_by":"\(createdBy)","sub_department_id":"\(Ids.subDepartmentIds)","sub_sub_department_id":"\(Ids.categoryIds)","subcategory_id":"\(Ids.subCategoryIds)"]
        
        Service.shared.POSTService(serviceType: API.addTask, parameters: params ) { (response) -> (Void) in
        
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                print(message as Any)
                print(responseDetails as Any)
                print(responseDetails["status"] as Any)
                
                if responseDetails["status"] == 200 {
                    
                    let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
                    let gotoOTP = storyBoard.instantiateViewController(withIdentifier: "MPIViewController") as! MPIViewController
                    self.navigationController?.pushViewController(gotoOTP, animated: true)
                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
                    SingleToneClass.shared.dismissProgressLoading(WithDelay: 0.50)
                    
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
        }
        
    }

    
    @IBAction func submitComplaintBoxBtn(_ sender: Any) {
        
     
            
            
            if productNameTF.text == "" || productNameTF.text == "-Select-" || productNameTF.text == "--None--" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Product Details") {
                    self.productNameTF.becomeFirstResponder()
                }
            }else if packageSizeTF.text == "" || packageSizeTF.text == "-Select-" || packageSizeTF.text == "--None--" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select ProductSize Details") {
                    self.packageSizeTF.becomeFirstResponder()
                }
            }else if wareHouseTF.text == "" || wareHouseTF.text == "-Select-" || wareHouseTF.text == "--None--" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Zone Details") {
                    self.wareHouseTF.becomeFirstResponder()
                }
            }else if !batchNoTF.isValidTextField(){
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Enter Batch No") {
                    self.batchNoTF.becomeFirstResponder()
                }
            }else if !boxNoTF.isValidTextField(){
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Enter Box No") {
                    self.boxNoTF.becomeFirstResponder()
                }
            }else if !dealerNameTF.isValidTextField(){
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Enter Dealer Name") {
                    self.dealerNameTF.becomeFirstResponder()
                }
            }else if !dealerCodeTF.isValidTextField(){
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Enter Dealer Code") {
                    self.dealerCodeTF.becomeFirstResponder()
                }
            }else if natureTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Nature Of Complaint Details") {
                    self.natureTF.becomeFirstResponder()
                }
            }else if !qualityAffectTF.isValidTextField(){
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Enter Quantity Details") {
                    self.qualityAffectTF.becomeFirstResponder()
                }
            }else if photoArray == [] {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Attach one Proof Picture") {
                    
                }
            }else if !briefAboutTF.isValidTextField(){
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Enter Brief About Complain") {
                    self.briefAboutTF.becomeFirstResponder()
                }
            }else if !mobileNoTF.isValidMobileNumberTextField() {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Enter Mobile Number") {
                    self.mobileNoTF.becomeFirstResponder()
                }
            }else{
                addComplaintService()
                SingleToneClass.shared.showProgressLoading(title: "Please Wait..")
            }
            

        
        
    }
    
    
    func addComplaintService()  {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        
        let showDate = dateFormatter.date(from: manufactureTF.text!)
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let resultString = dateFormatter.string(from: showDate!)
        print(resultString)
        
        let userid = UserDefaults.standard.object(forKey:"UserId") as! Int
        let depid=UserDefaults.standard.object(forKey: "DepartmentId") as! Int
        
        var params:[String:Any] = ["user_id" : userid,
                                   "product" : productId,
                                   "size" : productSizeId,
                                   "zone" : ZoneId,
                                   "batch_no" : batchNoTF.text!,
                                   "m_date" : resultString ,
                                   "dealer_name" : dealerNameTF.text!,
                                   "dealer_code" : dealerCodeTF.text!,
                                   "quantity" : qualityAffectTF.text!,
                                   "mobile_no" : mobileNoTF.text!,
                                   "nature_of_complaint" : natureTF.text!,
                                   "description" : briefAboutTF.text!,
                                   "login_department_id":depid,
                                   "box_number":boxNoTF.text!]
        
        
        params["proof"] = mediaFileArray
        print(params)
        
        
        Service.shared.makeUploadRequest1(serviceType: API.addComplaint, parameters: params) { response in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                
                if responseDetails["status"] == 200 {
                    
                    self.productNameTF.text = ""
                    self.packageSizeTF.text = ""
                    self.wareHouseTF.text = ""
                    self.batchNoTF.text = ""
                    self.dealerNameTF.text = ""
                    self.natureTF.text = ""
                    self.qualityAffectTF.text = ""
                    self.briefAboutTF.text = ""
                    self.mobileNoTF.text = ""
                    
                    self.photoArray.removeAll()
                    
                    
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
                    
                SingleToneClass.shared.dismissProgressLoading(WithDelay: 0.50)
                let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
                let gotoOTP = storyBoard.instantiateViewController(withIdentifier: "MPIViewController") as! MPIViewController
                    
                self.navigationController?.pushViewController(gotoOTP, animated: true)
                 
                    
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
        }
        
    }
    
    
    func addKnowledgeService()  {

        var params:[String:Any] = ["department_id": Ids.departmentIds ,"user_id":userId,"title":priorityTF.text!,"sub_department_id":Ids.subDepartmentIds,"category_id":Ids.categoryIds,"subcategory_id":Ids.subCategoryIds]
        
        print(params)
   
        params["files[]"] = mediaFileArray
        print(params)
        
        Service.shared.makeUploadRequest1(serviceType: API.addKnowledge, parameters: params) { response in
            
      
            
        print(response)
        SingleToneClass.shared.dismissProgressLoading()
            
        guard let responseDetails = response .dictionary else{return}
            
        if let message = responseDetails["message"]?.string {
                
                
            if responseDetails["status"] == 200 {
            SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
            SingleToneClass.shared.dismissProgressLoading(WithDelay: 0.50)
                    
                    
            }else if responseDetails["status"] == 419 {
                    
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
            }else{
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
        }
        
    }

}


extension NTViewController : UITextFieldDelegate,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout ,UITextViewDelegate{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        
        if collectionView == collectionView2 {
            
            if mediaFileArray.count == 0 {
                self.collections.isHidden = true
                view1Height.constant = 725
                // self.attachmentLbl.text = "0 Files Selected"
            }else{
                view1Height.constant = 875
            }
            print(mediaFileArray.count)
            return mediaFileArray.count
            
            
        }
 
        
        if mediaFileArray.count == 0 {
            self.collections.isHidden = true
            self.attachmentLbl.text = "0 Files Selected"
                view1Height.constant = 0
        }else{
            
                view1Height.constant = 500
        }

        return selectedAssets.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView == collectionView2 {
          
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ComplaintBoxImagePickingCollectionViewCell
            
            cell.imageDisplay.image = selectedAssets[indexPath.row]
            cell.imageNameDisplayLbl.text = imageFormatDisplay[indexPath.row]
            cell.imageDisplayView.layer.cornerRadius = 10
            cell.imageDisplayView.layer.borderWidth = 1
            cell.imageDisplayView.layer.borderColor = UIColor.black.cgColor
            
           
            
            cell.cancelBtn.tag = indexPath.row
            cell.cancelBtn.addTarget(self, action: #selector(self.downArrowTapped(_:)), for: .touchUpInside)
            
            return cell
        }
        
        
        
        
        
        
      let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! NTVCollectionViewCell

        cell.SelectedImage.image = selectedAssets[indexPath.row]
        print(cell.SelectedImage.image as Any)
        cell.imageNameLbl.text = imageFormatDisplay[indexPath.row]
        cell.imageView.layer.cornerRadius = 10
        cell.imageView.layer.borderWidth = 1
        cell.imageView.layer.borderColor = UIColor.black.cgColor
        
        DispatchQueue.main.async {
        self.attachmentLbl.text = "\(self.selectedAssets.count) Files Selected"
            }
      
             cell.deleteBtn.tag = indexPath.row
            cell.deleteBtn.addTarget(self, action: #selector(self.downArrowTapped(_:)), for: .touchUpInside)

        return cell
    }
    
    @objc func downArrowTapped(_ sender: UIButton) {
  

        if self.selectedIndex == sender.tag {
            self.selectedIndex = sender.tag
            selectedAssets.remove(at: sender.tag)
            imageFormatDisplay.remove(at: sender.tag)
             self.attachmentLbl.text = "\(self.selectedAssets.count) Files Selected"
            mediaFileArray.remove(at: sender.tag)
          
        }else{
            self.selectedIndex = 0
      
            selectedAssets.remove(at: sender.tag)
            self.attachmentLbl.text = "\(self.selectedAssets.count) Files Selected"
            imageFormatDisplay.remove(at: sender.tag)
            mediaFileArray.remove(at: sender.tag)
            
        }
        
        if self.attachmentLbl.text == "0 Files Selected" {
            collections.isHidden = true
        }else{
            collections.isHidden = false
        }
        self.collections.reloadData()
    }
    

    

    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        self.selectedTF = textField
    
        if selectedTF == departmentTF {
           self.subDepartmentTF.text = ""
            self.categoryTF.text = ""
            self.subCategoryTF.text = ""
            self.view1.isHidden = true
            self.view1Height.constant = 300
            

        }else if selectedTF == subDepartmentTF{
            self.categoryTF.text = ""
            self.subCategoryTF.text = ""
            self.view1.isHidden = true
            self.view1Height.constant = 300
            
        }else if selectedTF == categoryTF{
             self.subCategoryTF.text = ""
          
        }
        
        return true
    }
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        
        
         if KnowledgeBase == "1" {
            
            if textField == self.departmentTF   {
                
                
                let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
                POPUPVC.tagValue = textField.tag
                SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                self.addChild(POPUPVC)
                POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
                self.view.addSubview(POPUPVC.view)
                POPUPVC.didMove(toParent: self)
                self.departmentTF.resignFirstResponder()
                
         
            }else if textField == self.subDepartmentTF {
                if departmentTF.text == "" {
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select Department") {
                        
                    }
                    self.subDepartmentTF.resignFirstResponder()
                
                }else{
                    let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
                    POPUPVC.tagValue = textField.tag
                    SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                    self.addChild(POPUPVC)
                    POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
                    self.view.addSubview(POPUPVC.view)
                    POPUPVC.didMove(toParent: self)
                    self.subDepartmentTF.resignFirstResponder()
                }
                
            }else if textField == self.categoryTF {
               
                if departmentTF.text == "" {
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select Department") {
                       
                    }
                     
                    self.categoryTF.resignFirstResponder()
               
                }else if subDepartmentTF.text == "" {
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select SubDepartment") {
                       
                    }
                    
                    self.categoryTF.resignFirstResponder()
               
                }else{
                   
                    let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
                     POPUPVC.tagValue = textField.tag
                    SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                    self.addChild(POPUPVC)
                    POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
                    self.view.addSubview(POPUPVC.view)
                    POPUPVC.didMove(toParent: self)
                    self.categoryTF.resignFirstResponder()
                }
            }else if textField == self.subCategoryTF {
               
                if departmentTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select Department") {
                       
                    }
                    
                    self.subCategoryTF.resignFirstResponder()
               
                }else if subDepartmentTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select SubDepartment") {
                        
                    }
                    
                    self.subCategoryTF.resignFirstResponder()
                
                }else if categoryTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select category") {
                       
                    }
                   
                    self.subCategoryTF.resignFirstResponder()
                
                }else{
                  
                    let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
                    POPUPVC.tagValue = textField.tag
                    SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                    self.addChild(POPUPVC)
                    POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
                    self.view.addSubview(POPUPVC.view)
                    POPUPVC.didMove(toParent: self)
                
                self.subCategoryTF.resignFirstResponder()
             
                }
            }
         }else{
            
            if textField == self.departmentTF  {
                
                let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
                POPUPVC.tagValue = textField.tag
                SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                self.addChild(POPUPVC)
                POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
                self.view.addSubview(POPUPVC.view)
                POPUPVC.didMove(toParent: self)
                self.departmentTF.resignFirstResponder()
                
            }else if textField == self.subDepartmentTF {
              
                if departmentTF.text == "" {
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select Department") {
                        
                    }
                   
                    self.subDepartmentTF.resignFirstResponder()
               
                }else{
                 SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                     let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
                    POPUPVC.tagValue = textField.tag
                  
                    self.addChild(POPUPVC)
                    POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
                    self.view.addSubview(POPUPVC.view)
                    POPUPVC.didMove(toParent: self)
                    self.subDepartmentTF.resignFirstResponder()
               
                }
           
            }else if textField == self.categoryTF {
               
                if departmentTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select Department") {
                      
                    }
                      
                    self.categoryTF.resignFirstResponder()
               
                }else if subDepartmentTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select SubDepartment") {
                       
                    }
                    
                    self.categoryTF.resignFirstResponder()
               
                }else{
                 SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                     let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
                    POPUPVC.tagValue = textField.tag
                   
                    self.addChild(POPUPVC)
                    POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
                    self.view.addSubview(POPUPVC.view)
                    POPUPVC.didMove(toParent: self)
                    self.categoryTF.resignFirstResponder()
               
                }
            
            }else if textField == self.subCategoryTF {
               
                if departmentTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select Department") {
                      
                    }
                    
                    self.subCategoryTF.resignFirstResponder()
                
                }else if subDepartmentTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select SubDepartment") {
                      
                    }
                    
                    self.subCategoryTF.resignFirstResponder()
               
                }else if categoryTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select category") {
                       
                    }
                     
                    self.subCategoryTF.resignFirstResponder()
                
                }else{
                 SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                     let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
                    POPUPVC.tagValue = textField.tag
                   
                    self.addChild(POPUPVC)
                    POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
                    self.view.addSubview(POPUPVC.view)
                    POPUPVC.didMove(toParent: self)
                    self.subCategoryTF.resignFirstResponder()
               
                }
           
            }else if textField == self.priorityTF{
               
                if departmentTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select Department") {
                       
                    }
                     
                    self.priorityTF.resignFirstResponder()
               
                }else if subDepartmentTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select SubDepartment") {
                       
                    }
                    
                    self.priorityTF.resignFirstResponder()
               
                }else if categoryTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select category") {
                        
                    }
                    
                    self.priorityTF.resignFirstResponder()
                
                }else if subCategoryTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select Subcategory") {
                      
                    }
                    
                    self.priorityTF.resignFirstResponder()
              
                }else{
                 SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                     let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
                     POPUPVC.tagValue = textField.tag
                     self.addChild(POPUPVC)
                     POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
                     self.view.addSubview(POPUPVC.view)
                     POPUPVC.didMove(toParent: self)
                     self.priorityTF.resignFirstResponder()
               
                }
            
            }else if textField == self.productNameTF || textField == self.packageSizeTF || textField == self.wareHouseTF || textField == self.natureTF {
                
                let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
                POPUPVC.tagValue = textField.tag
                SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                self.addChild(POPUPVC)
                POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
                self.view.addSubview(POPUPVC.view)
                POPUPVC.didMove(toParent: self)
                self.selectedTF.resignFirstResponder()
                
                
                
                
                
            }
        
 
            
        }
        
    }


    func textViewDidBeginEditing(_ textView: UITextView) {
       
        if textView == descriptionTV {
            descriptionTV.text = ""
        }
    }
    
    
}

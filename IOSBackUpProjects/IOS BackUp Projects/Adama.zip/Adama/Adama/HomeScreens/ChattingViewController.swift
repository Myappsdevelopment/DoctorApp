//
//  ChattingViewController.swift
//  Adama
//
//  Created by MAD-MAC on 18/09/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import PusherSwift

class ChattingViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextViewDelegate {

    var commentArray = [String]()
    var dateArray = [String]()
    var empNameArray = [String]()
    var empIdArray = [String]()
    
    var filteredEmpId = [String]()
    var filteredOtherEmp = [String]()
    var userIdArray = [Int]()
    var saveMessages:[Chat] = []
    var filteredNameArray = [String]()
    var filteredOtherNameArray = [String]()
    var filteredCommentArray = [String]()
    var filteredDateArray = [String]()
    
    var usrMsg:[String] = []
    var empMsg:[String] = []
    var usrname:[String] = []
    var usrdate:[String] = []
    var empname:[String] = []
    var empdate:[String] = []
    
    weak var timer: Timer?
    var startTime: Double = 0
    var time: Double = 0
    
    @IBOutlet weak var NodataImage: UIImageView!
    @IBOutlet weak var table: UITableView!
    @IBOutlet weak var messageTV: UITextView!
    
    

    var ticketId = String()
    var complaintId = String()
    let currentDate = Date()
    
    
    
    let departmentId = UserDefaults.standard.object(forKey: "DepartmentId") as! Int
    let userId = UserDefaults.standard.object(forKey: "UserId") as! Int
    
    let employeeId = UserDefaults.standard.object(forKey: "EmployeeId") as! String
    let employeeName = UserDefaults.standard.object(forKey: "Name")as! String
    
    override func viewDidLoad() {
        super.viewDidLoad()

        messageTV.layer.borderWidth = 2
        messageTV.layer.borderColor = UIColor.black.cgColor
        messageTV.delegate = self
        
        
        let imgBack = UIImage(named:"Arrow")
        print(imgBack as Any)
        navigationController?.navigationBar.backIndicatorImage = imgBack
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
        
        navigationItem.leftItemsSupplementBackButton = true
        navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        
        
        
        self.navigationController?.isNavigationBarHidden = false
        self.navigationItem.title = "Comments"
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
      
        
        
        if DetailsStore.assignedComplaint == true || DetailsStore.submittedComplaint == true || DetailsStore.customerComplaint == true {
            
            getComplaintComments()
            
        }else{
           
            getTicket()
        }
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        startTime = Date().timeIntervalSinceReferenceDate
        timer = Timer.scheduledTimer(timeInterval: 0.300,
                                     target: self,
                                     selector: #selector(advanceTimer(timer:)),
                                     userInfo: nil,
                                     repeats: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        timer?.invalidate()
    }

    
    @objc func advanceTimer(timer: Timer) {
        
        self.usrMsg.removeAll()
        self.usrname.removeAll()
        self.usrdate.removeAll()
        self.empMsg.removeAll()
        self.empname.removeAll()
        self.empdate.removeAll()

        if DetailsStore.assignedComplaint == true || DetailsStore.submittedComplaint == true || DetailsStore.customerComplaint == true {

            getComplaintComments()

        }else{

            getTicket()
        }
        

    }

    
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView == messageTV {
            messageTV.text = ""
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
      
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
        if  section == 0 {
           
            return usrMsg.count
        } else {
           
            return empMsg.count
        }
        

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       

        
        if usrMsg[indexPath.row] == "0"{
            let cell1 = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! Chatting2TableViewCell
                cell1.textMessageLbl.text = empMsg[indexPath.row]
                cell1.nameLbl.text = empname[indexPath.row]
                cell1.dateLbl.text = empdate[indexPath.row]
            return cell1
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ChattingTableViewCell
            
                cell.textMessageLbl.text = usrMsg[indexPath.row]
                cell.nameLbl.text = usrname[indexPath.row]
                cell.dateLbl.text = usrdate[indexPath.row]
                return cell
        }
 
        
    }
    
    
  

    @IBAction func sendBtn(_ sender: Any) {
       
        if messageTV.text == "" {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter text") {
                self.messageTV.becomeFirstResponder()
            }
        }else{
            if DetailsStore.submittedComplaint == true || DetailsStore.assignedComplaint == true || DetailsStore.customerComplaint == true {
                
                addComplaintComments()
                
            }else{
                
                 addComment()
            }
       
        }
    }
    
    

    
    func addComment()  {
        
        
        
        let params = ["ticket_id":ticketId,"comment": messageTV.text!,"login_department_id":"\(departmentId)","user_id":"\(userId)"]
        
        Service.shared.POSTService(serviceType: API.addTicketComment, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
            
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                print(message as Any)
                print(responseDetails as Any)
                print(responseDetails["status"] as Any)
                
                if responseDetails["status"] == 200 {
                  
                    self.usrMsg.removeAll()
                    self.usrname.removeAll()
                    self.usrdate.removeAll()
                    self.empMsg.removeAll()
                    self.empname.removeAll()
                    self.empdate.removeAll()
                    
                    
                    self.getTicket()
                    self.messageTV.text = ""
          
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
            
        }
        
    }
    
    
    
    func getTicket()  {
        
        
        
        let params = ["ticket_id":"\(ticketId)","login_department_id":"\(departmentId)","user_id":"\(userId)"]
        print(params)
        
        Service.shared.POSTService(serviceType: API.getTicketComment, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
            
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                print(message as Any)
                print(responseDetails as Any)
                print(responseDetails["status"] as Any)
                
                if responseDetails["status"] == 200 {
                    
                    
                    self.table.isHidden = false
                    self.NodataImage.isHidden = true
                    
                    let data = responseDetails["data"]?.array
                    
                    
                    
                    if data == [] {
                        self.table.isHidden = true
                        self.NodataImage.isHidden = false
                    }else{
                        self.table.isHidden = false
                        self.NodataImage.isHidden = true
                    }
                    
                    for i in data! {
                        
                   
                        let date = i["created_at"].string
                        
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                        
                        
                        let showDate = dateFormatter.date(from: date!)
                        dateFormatter.dateFormat = "dd-MM-yyyy"
                        let resultString = dateFormatter.string(from: showDate!)
                        print(resultString)
                        
                        
                        
                        
                        
                        let userId1 = i["user_id"].int
                        let user = i["user"].dictionary
                        
                       
                    
                     
                        
                        if self.userId == userId1{
                            
                         
                            self.empMsg.append("1")
                            self.empname.append("1")
                            self.empdate.append("1")
                            self.usrMsg.append(i["comment"].string!)
                            self.usrname.append((user!["name"]?.string!)!)
                            self.usrdate.append(resultString)
                           
                        }else{
                            
                        
                            self.usrMsg.append("0")
                            self.usrname.append("0")
                            self.usrdate.append("0")
                            self.empMsg.append(i["comment"].string!)
                            self.empname.append((user!["name"]?.string!)!)
                            self.empdate.append(resultString)
                          
                            
                        }
                        
                        print(self.usrMsg)
                        print(self.empMsg)
                        

                    }
        
                    self.table.reloadData()
                    
                    
                    
                }else if responseDetails["status"] == 419 {
                    self.table.isHidden = true
                    self.NodataImage.isHidden = false
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
            
        }
    }
    
 
    
    func getComplaintComments()  {
        
     
        
        let params = ["complaint_id":complaintId,"login_department_id":"\(departmentId)","user_id":"\(userId)"]
        print(params)
        
        Service.shared.POSTService(serviceType: API.getComplaintComments, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
            
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
             
                
                if responseDetails["status"] == 200 {
                    
                    
                    self.table.isHidden = false
                    self.NodataImage.isHidden = true
                    
                    let data = responseDetails["data"]?.array
                    
                    
                    
                    if data == [] {
                        self.table.isHidden = true
                        self.NodataImage.isHidden = false
                    }else{
                        self.table.isHidden = false
                        self.NodataImage.isHidden = true
                    }
                    
                    for i in data! {
                        
                        
                        let date = i["created_at"].string
                        
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                        
                        
                        let showDate = dateFormatter.date(from: date!)
                        dateFormatter.dateFormat = "dd-MM-yyyy"
                        let resultString = dateFormatter.string(from: showDate!)
                        print(resultString)
                        
                        
                        
                        
                        
                        let userId1 = i["user_id"].int
                        let user = i["user"].dictionary
                        
                        
                        
                        
                        
                        if self.userId == userId1{
                            
                            
                            self.empMsg.append("1")
                            self.empname.append("1")
                            self.empdate.append("1")
                            self.usrMsg.append(i["message"].string!)
                            self.usrname.append((user!["name"]?.string!)!)
                            self.usrdate.append(resultString)
                            
                        }else{
                            
                            
                            self.usrMsg.append("0")
                            self.usrname.append("0")
                            self.usrdate.append("0")
                            self.empMsg.append(i["message"].string!)
                            self.empname.append((user!["name"]?.string!)!)
                            self.empdate.append(resultString)
                            
                            
                        }
                        
                        print(self.usrMsg)
                        print(self.empMsg)
                        
                        
                    }
                    
                  
                    self.table.reloadData()
                    
                    
                    
                }else if responseDetails["status"] == 419 {
                    self.table.isHidden = true
                    self.NodataImage.isHidden = false
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
            
        }
    }
    
    func addComplaintComments()  {
        
        
        
        let params = ["complaint_id":complaintId,"message": messageTV.text!,"login_department_id":"\(departmentId)","user_id":"\(userId)"]
        
        Service.shared.POSTService(serviceType: API.addComplaintComments, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
            
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
               
                
                if responseDetails["status"] == 200 {
                    
                    self.usrMsg.removeAll()
                    self.usrname.removeAll()
                    self.usrdate.removeAll()
                    self.empMsg.removeAll()
                    self.empname.removeAll()
                    self.empdate.removeAll()
                    
                    self.getComplaintComments()
                    self.messageTV.text = ""
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
            
        }
        
    }
    
}

//
//  KBViewController.swift
//  Adama
//
//  Created by MatrixStream_01 on 29/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import Kingfisher

class KBViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UISearchBarDelegate{
    
    @IBOutlet weak var sidebar: UIBarButtonItem!
    @IBOutlet weak var table: UITableView!
   
    @IBOutlet weak var departmentTF: TextField!
    @IBOutlet weak var subDepartmentTF: TextField!
    @IBOutlet weak var categoryTF: TextField!
    @IBOutlet weak var subCategoryTF: TextField!
    @IBOutlet weak var departmentStackView: UIStackView!
    @IBOutlet weak var subDepartmentStackView: UIStackView!
    @IBOutlet weak var categoryStackView: UIStackView!
    @IBOutlet weak var subCategoryStackView: UIStackView!
    @IBOutlet weak var submitBtn: UIButton!
    @IBOutlet weak var plusBtn: UIButton!
    @IBOutlet weak var searchField: UISearchBar!
    
    @IBOutlet weak var verticalSpacingHeight: NSLayoutConstraint!
    @IBOutlet weak var plusStack: UIStackView!
    
    @IBOutlet weak var submitBtnHeight: NSLayoutConstraint!
   
    
    @IBOutlet weak var borderLineView: UIView!
    
    var imageBaseUrl = [String]()
    var name = [String]()
    var date = [String]()
    
    var productsArray:[Products] = []
    var selectedTF = UITextField()
    
    var selectedIndex: Int = -1
    
    var search = false
    var searchResults = [String]()
    var searchActive : Bool = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        
        if UserDefaults.standard.object(forKey: "Role") as! String == "Support Executive" {
        
            plusStack.isHidden = false
     
        }else{
            
            plusStack.isHidden = true
         
        }
 
          searchField.delegate = self
          table.rowHeight = UITableView.automaticDimension
        
      
    
        self.navigationController?.isNavigationBarHidden = false
         self.navigationItem.title = "Knowledge Base"
        
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.tabBarController?.tabBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white
        // Do any additional setup after loading the view.
        
        departmentTF.delegate = self
        subDepartmentTF.delegate = self
        categoryTF.delegate = self
        subCategoryTF.delegate = self
        submitBtn.layer.cornerRadius = 10
     
        
        let low = NotificationCenter.default
        low.addObserver(self, selector: #selector(prodcutsInfo(_:)), name: Notification.Name("Low3"), object: nil)
        
    }
   

    @objc func prodcutsInfo(_ notification: NSNotification){
        
        if let dict = notification.userInfo as NSDictionary? {
            
            print(dict)
            if let name = dict["product"] as? String{
                let id = dict["id"] as! Int
                let a = dict["TextfieldTag"] as! Int
                //  var ids = Ids()
                if a == 10 {
                    self.departmentTF.text = name
                    Ids.departmentIds = id
                    print(Ids.departmentIds)
                }else if a == 11 {
                    self.subDepartmentTF.text = name
                    Ids.subDepartmentIds = id
                    print(Ids.subDepartmentIds)
                    
                }else if a == 12 {
                    
                    self.categoryTF.text = name
                    Ids.categoryIds = "\(id)"
                    print(Ids.categoryIds)

                }else if a == 13{
                    self.subCategoryTF.text = name
                    Ids.subCategoryIds = id
                    print(Ids.categoryIds)
                   
                }
                
            }
        }
        
    }
    
    
    @IBAction func searchBarBtn(_ sender: Any) {
        
        if search {
            searchField.isHidden = true
            search = false
        }
        else {
            searchField.isHidden = false
            search = true
        }
        
        
    }
    
    
    
    @IBAction func bellBtn(_ sender: Any) {
        
        let emp = storyboard?.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
        navigationController?.pushViewController(emp, animated: true)
    }
    
    @IBAction func submitBtn(_ sender: Any) {
        
        if !departmentTF.isValidTextField() {
            
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Department") {
                self.departmentTF.becomeFirstResponder()
            }
            
        }else if !subDepartmentTF.isValidTextField() {
            
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select SubDepartment") {
                self.subDepartmentTF.becomeFirstResponder()
            }
            
        }else if !categoryTF.isValidTextField() {
            
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Category") {
                self.categoryTF.becomeFirstResponder()
            }
            
        }else if !subCategoryTF.isValidTextField() {
            
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select SubCategory") {
                self.subCategoryTF.becomeFirstResponder()
            }
        }else{
              SingleToneClass.shared.showProgressLoading(title: "Please wait...")
            getKnowledgeResolution()
        }
        

        
    }
    
    
    @IBAction func plusBtn(_ sender: Any) {
        let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let gotoOTP = storyBoard.instantiateViewController(withIdentifier: "NTViewController") as! NTViewController
        gotoOTP.KnowledgeBase = "1"
        self.navigationController?.pushViewController(gotoOTP, animated: true)
    }
    
    
    func getKnowledgeResolution ()  {
        
        let departmentId = UserDefaults.standard.object(forKey: "DepartmentId")as! Int
        print(departmentId as Any)
         let userid = UserDefaults.standard.object(forKey:"UserId") as! Int
        
        let params = ["login_department_id":"\(departmentId )","user_id":"\(userid)","department_id":"\(Ids.departmentIds)","subdepartment_id":"\(Ids.subDepartmentIds)","category_id":"\(Ids.categoryIds)","subcategory_id":"\(Ids.subCategoryIds)"]
        print(params)
        SingleToneClass.shared.dismissProgressLoading()
        Service.shared.POSTService(serviceType: API.getKnowledgeResolution, parameters: params ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            
            if responseDetails["status"] == 200 {
                
               
                let imagePath = (responseDetails["image_path"]?.string)!
           
                let data = responseDetails["data"]?.array
                if data == [] {
                    self.table.isHidden = true
                   // self.noDataImage.isHidden = false
                }else{
                    self.table.isHidden = false
                   // self.noDataImage.isHidden = true
                    
                
                for i in data! {
                     var Details = Products()
                    let name = i["title"].string
                   // let dates = i["updated_at"].string!
                    
                    
                    let resultDate = i["updated_at"].string
                    
                    let dateFormatterGet = DateFormatter()
                    dateFormatterGet.dateFormat = "yyyy-MM-dd HH:mm:ss"
                    
                    let dateFormatterPrint = DateFormatter()
                    dateFormatterPrint.dateFormat = "dd-MM-yyyy"
                    
                    if let date = dateFormatterGet.date(from: resultDate!) {
                       let dates = dateFormatterPrint.string(from: date)
                        // DetailsStore.endDate = self.endDateTF.text!
                        self.date.append(dates)
                    }
                    
                    
                    
                    
                    
                    let knowledge = i["knowledge_files"].array
                    
                    for j in knowledge!{
                        var pro = getProImg()
                        
                        let file = j["file"].string!
                        print(file)
                        pro.ImageName = imagePath + file
                        print(pro.ImageName as Any)
                        Details.studentImage.append(pro)
                        //  self.imageBaseUrl.append(imageName)
                    }

                    self.productsArray.append(Details)
                    self.name.append(name!)
                    
                }
                    self.table.isHidden = false
                    self.table.reloadData()
                }
                
            }else if responseDetails["status"] == 419 {
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) {
                    exit(0)
                }
                
            }else{
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) {
                    self.table.isHidden = true
                  //  self.noDataImage.isHidden = false
                    
                }
            }
        }
    }
    

    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        
                searchResults = name.filter { item in
                    return item.lowercased().contains(searchText.lowercased())
                }
      //  searchResults = name.filter({ $0.id == Int(searchText) || $0.assingFrom[0].dName?.lowercased() == searchText.lowercased() || $0.c_status == Int(searchText)
            
   //     })
        
        
        if searchResults.isEmpty == false{
            
            search = true
            table.reloadData()
            
        }else{
            
            search = false
            table.reloadData()
            
        }
        
        
        
        
    }
    
    
   
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = true
        table.reloadData()
    }
    func searchBarCancelButtonClicked(_ searchBaar: UISearchBar) {
        searchActive = false;
        searchBaar.showsCancelButton = false
        searchBaar.text = ""
        searchBaar.resignFirstResponder()
        searchBaar.endEditing(true)
        table.reloadData()
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        searchActive = false
        self.searchField.endEditing(true)
        table.reloadData()
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if search {
            return searchResults.count
        }else{
           return name.count
        }
        
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! KBTableViewCell
        
         if search{
            
            cell.idLbl.text = searchResults[indexPath.row]
            print(cell.idLbl.text as Any)
            cell.dateLbl.text = "\(date[indexPath.row])"
            cell.get = productsArray[indexPath.row].studentImage
            print(cell.get)
            
            cell.plusBtn.tag = indexPath.row
            
            if indexPath == self.selectedIndexPath {
                table.rowHeight = UITableView.automaticDimension
                cell.collection.reloadData()
                cell.collectionHeight.constant = 150
                cell.plusBtn.setImage(UIImage(named: "mins"), for: .normal)
            }else{
                table.rowHeight = 50
                cell.collectionHeight.constant = 0
                cell.plusBtn.setImage(UIImage(named: "Plus-1"), for: .normal)
            }
            
            cell.plusBtn.addTarget(self, action: #selector(self.downArrowTapped(_:)), for: .touchUpInside)
            //table.rowHeight = 50
            return cell
            
         }else{
            
            cell.idLbl.text = name[indexPath.row]
            print(cell.idLbl.text as Any)
            cell.dateLbl.text = "\(date[indexPath.row])"
            cell.get = productsArray[indexPath.row].studentImage
            print(cell.get)
            
            cell.plusBtn.tag = indexPath.row
            
            if indexPath == self.selectedIndexPath {
                table.rowHeight = UITableView.automaticDimension
                cell.collection.reloadData()
                cell.collectionHeight.constant = 150
                cell.plusBtn.setImage(UIImage(named: "mins"), for: .normal)
            }else{
                table.rowHeight = 50
                cell.collectionHeight.constant = 0
                cell.plusBtn.setImage(UIImage(named: "Plus-1"), for: .normal)
            }
            
            cell.plusBtn.addTarget(self, action: #selector(self.downArrowTapped(_:)), for: .touchUpInside)
            //table.rowHeight = 50
            return cell
            
        }
        
       
    }
    
    
    
    
    @objc func downArrowTapped(_ sender: UIButton) {
    
        
        if self.selectedIndex != sender.tag {
            self.selectedIndex = sender.tag
        }else{
            self.selectedIndex = -1
        }
        self.table.reloadData()
    }
    
    
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        if indexPath == self.selectedIndexPath{
            self.selectedIndexPath = nil
            
            
        }else{
               print(productsArray[indexPath.row].studentImage)
//            if productsArray[indexPath.row].studentImage  != [] {
//                print(productsArray[indexPath.row].studentImage)
//                self.selectedIndexPath = indexPath
//
//            }else{
//                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "No Data Found") {
//
//                }
//            }
            
            self.selectedIndexPath = indexPath
        }
        table.reloadData()
        
    }
    
    
    internal var selectedIndexPath: IndexPath? {
        didSet{
            self.table.beginUpdates()
            self.table.endUpdates()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    
        if indexPath == self.selectedIndexPath {
            return UITableView.automaticDimension

        } else {
            let size = 50
            return CGFloat(size)
        }
    }

    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        self.selectedTF = textField
        
        if selectedTF == departmentTF {
            self.subDepartmentTF.text = ""
            self.categoryTF.text = ""
            self.subCategoryTF.text = ""
            
        }else if selectedTF == subDepartmentTF{
            self.categoryTF.text = ""
            self.subCategoryTF.text = ""
            
        }else if selectedTF == categoryTF{
            self.subCategoryTF.text = ""
            
        }
        
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == self.departmentTF   {
            
            let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
            POPUPVC.tagValue = textField.tag
            SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
            self.addChild(POPUPVC)
            POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
            self.view.addSubview(POPUPVC.view)
            POPUPVC.didMove(toParent: self)
            self.selectedTF.resignFirstResponder()
            
     
            
        }else if textField == self.subDepartmentTF {
            if departmentTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select Department") {
                    
                }
                self.subDepartmentTF.resignFirstResponder()
            }else{
                let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
                POPUPVC.tagValue = textField.tag
                SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                self.addChild(POPUPVC)
                POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
                self.view.addSubview(POPUPVC.view)
                POPUPVC.didMove(toParent: self)
                self.subDepartmentTF.resignFirstResponder()
            }
            
        }else if textField == self.categoryTF {
            if departmentTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select Department") {
                    
                }
                self.categoryTF.resignFirstResponder()
            }else if subDepartmentTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select SubDepartment") {
                    
                }
                self.categoryTF.resignFirstResponder()
            }else{
                let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
                POPUPVC.tagValue = textField.tag
                SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                self.addChild(POPUPVC)
                POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
                self.view.addSubview(POPUPVC.view)
                POPUPVC.didMove(toParent: self)
                self.categoryTF.resignFirstResponder()
            }
        }else if textField == self.subCategoryTF {
            if departmentTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select Department") {
                    
                }
                self.subCategoryTF.resignFirstResponder()
            }else if subDepartmentTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select SubDepartment") {
                    
                }
                self.subCategoryTF.resignFirstResponder()
            }else if categoryTF.text == "" {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select category") {
                    
                }
                self.subCategoryTF.resignFirstResponder()
            }else{
                let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
                POPUPVC.tagValue = textField.tag
                SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                self.addChild(POPUPVC)
                POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
                self.view.addSubview(POPUPVC.view)
                POPUPVC.didMove(toParent: self)
                self.subCategoryTF.resignFirstResponder()
            }
        }
        
    }
    
    
    
    
}

//
//  MPIViewController.swift
//  Adama
//
//  Created by MatrixStream_01 on 29/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//
var eventsDescription = [String]()


import UIKit
import SwiftyJSON
import Toast

class MPIViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,UITabBarDelegate,UISearchBarDelegate {

    
    @IBOutlet weak var allTicketView: UIView!
    @IBOutlet weak var noDataImage: UIImageView!
    @IBOutlet weak var btnStackView: UIStackView!
    @IBOutlet weak var IdHeadingLbl: UILabel!
    @IBOutlet weak var searchBarBtn: UIBarButtonItem!
    @IBOutlet weak var table: UITableView!
    @IBOutlet weak var sideBar: UIBarButtonItem!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var allTicketBtn: UIButton!
    @IBOutlet weak var assignTicketBtn: UIButton!
    @IBOutlet weak var submitTicketBtn: UIButton!
    @IBOutlet weak var assignView: UIView!
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var filterStackView: UIStackView!
    @IBOutlet weak var submitTicketView: UIView!
    @IBOutlet weak var submitTicketStackview: UIStackView!
    @IBOutlet weak var allTicketStackview: UIStackView!
    @IBOutlet weak var assignTicketStackview: UIStackView!
    
    
    @IBOutlet weak var addTicketView: UIView!
    
    
    @IBOutlet weak var assignTicketsView: UIView!
    var storeTaskList:[TaskList] = []
    var searchResult:[TaskList] = []
    
 
    var unchecked = false
    var search = false
    var searchActive : Bool = false
    var filteredData: [String]!
    
    var selectedIndex: Int = -1
    var page = true
    
    var priorityValue = ""
    var assignTicket = "2"
    var status = ""
    var assignType = "0"
    var pageNo = "1"
    var imagePath = String()
    
    var assignBtnName = ""
    var changeStatus = ""
    var Action = ""
    var complaintAssign = ""
    
    let blackColour = UIColor(red: 39/255, green: 39/255, blue: 39/255, alpha: 1.0)
    let grayColour = UIColor(red: 192/255, green: 195/255, blue: 203/255, alpha: 1.0)
    let blueColour = UIColor(red: 97/255, green: 132/255, blue: 165/255, alpha: 1.0)
    let whiteColour = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1.0)
    
    
    let userid = UserDefaults.standard.object(forKey:"UserId") as! Int
    let depid=UserDefaults.standard.object(forKey: "DepartmentId") as! Int
    let type = UserDefaults.standard.object(forKey: "UserType") as! Int
    let subDepartmentId = UserDefaults.standard.object(forKey: "LoginSubDepartmentId") as! Int
    let employeeId = UserDefaults.standard.object(forKey: "EmployeeId")
    
    
    override func viewWillAppear(_ animated: Bool) {
         navigation()

   
        
        allTicketBtn.titleLabel?.adjustsFontSizeToFitWidth = true
        allTicketBtn.titleLabel?.numberOfLines = 1
        allTicketBtn.titleLabel?.minimumScaleFactor = 0.1
        allTicketBtn.clipsToBounds = true
        
        
        assignTicketBtn.titleLabel?.adjustsFontSizeToFitWidth = true
        assignTicketBtn.titleLabel?.numberOfLines = 1
        assignTicketBtn.titleLabel?.minimumScaleFactor = 0.1
        assignTicketBtn.clipsToBounds = true
        
        submitTicketBtn.titleLabel?.adjustsFontSizeToFitWidth = true
        submitTicketBtn.titleLabel?.numberOfLines = 1
        submitTicketBtn.titleLabel?.minimumScaleFactor = 0.1
        submitTicketBtn.clipsToBounds = true
        
        
        SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
        
        if  DetailsStore.page == true {
            
            
            if UserDefaults.standard.object(forKey: "UserType") as! Int == 2 || UserDefaults.standard.object(forKey: "UserType") as! Int == 4 {
                
                allTicketStackview.isHidden = false
                assignTicketStackview.isHidden = false
                submitTicketStackview.isHidden = false
            }else{
                
                assignTicketStackview.isHidden = true
                
            }
            
            self.IdHeadingLbl.text = "Task Id"
            self.navigationItem.title = "Task"
            self.allTicketBtn.isHidden = true
            self.allTicketView.isHidden = true
            
           
            assignTicketBtn.setTitleColor(blackColour, for: [])
            assignTicketBtn.setTitle("ASSIGN TASK", for: [])
            
            
            taskListingService()
            
        }else {
            
            if DetailsStore.pending == true {
               // DetailsStore.pending = false
                addTicketView.isHidden = true
                assignTicketsView.isHidden = true
                let imgBack = UIImage(named:"Arrow")
                print(imgBack as Any)
       
                navigationController?.navigationBar.backIndicatorImage = imgBack
                navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
                
                navigationItem.leftItemsSupplementBackButton = true
                self.navigationItem.leftBarButtonItems = nil
            navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
                
                
                
                self.navigationController?.isNavigationBarHidden = false
            self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
                
            self.navigationController?.navigationBar.tintColor = .white
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
            self.navigationController?.navigationBar.isTranslucent = false
                self.navigationItem.title = "Dashboard Details"
                status = "0"
                pageNo = "1"
                page = false
                btnStackView.isHidden = true
                self.storeTaskList.removeAll()
                dashboardTicketList()
                filterStackView.isHidden = true
                
            } else if DetailsStore.resolved == true {
              //  DetailsStore.resolved = false
            
                addTicketView.isHidden = true
                assignTicketsView.isHidden = true
            
                let imgBack = UIImage(named:"Arrow")
                print(imgBack as Any)
            navigationController?.navigationBar.backIndicatorImage = imgBack
            navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
                
                navigationItem.leftItemsSupplementBackButton = true
                self.navigationItem.leftBarButtonItems = nil
            navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
                
                
                
                self.navigationController?.isNavigationBarHidden = false
            self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
                
            self.navigationController?.navigationBar.tintColor = .white
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
            self.navigationController?.navigationBar.isTranslucent = false
                self.navigationItem.title = "Dashboard Details"
                
                status = "2"
                pageNo = "1"
                page = false
                btnStackView.isHidden = true
                self.storeTaskList.removeAll()
                dashboardTicketList()
                filterStackView.isHidden = true
                
            } else if DetailsStore.highPriority == true {
               // DetailsStore.highPriority = false
            
                addTicketView.isHidden = true
                assignTicketsView.isHidden = true
            
                let imgBack = UIImage(named:"Arrow")
                print(imgBack as Any)
            navigationController?.navigationBar.backIndicatorImage = imgBack
            navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
                
                navigationItem.leftItemsSupplementBackButton = true
                self.navigationItem.leftBarButtonItems = nil
            navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
                
                
                
                self.navigationController?.isNavigationBarHidden = false
            self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
                
            self.navigationController?.navigationBar.tintColor = .white
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
            self.navigationController?.navigationBar.isTranslucent = false
                self.navigationItem.title = "Dashboard Details"
                
                
                priorityValue = "2"
                assignType = "0"
                pageNo = "1"
                page = false
                btnStackView.isHidden = true
                self.storeTaskList.removeAll()
                dashboardTicketList()
                filterStackView.isHidden = true
                
            } else if DetailsStore.overdue == true {
              //  DetailsStore.overdue = false
            
                addTicketView.isHidden = true
                assignTicketsView.isHidden = true
                
                let imgBack = UIImage(named:"Arrow")
                print(imgBack as Any)
            navigationController?.navigationBar.backIndicatorImage = imgBack
            navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
                
                navigationItem.leftItemsSupplementBackButton = true
                self.navigationItem.leftBarButtonItems = nil
            navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
                
                
                
                self.navigationController?.isNavigationBarHidden = false
            self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
                
            self.navigationController?.navigationBar.tintColor = .white
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
            self.navigationController?.navigationBar.isTranslucent = false
                self.navigationItem.title = "Dashboard Details"
                
                status = "1"
                pageNo = "1"
                page = false
                btnStackView.isHidden = true
                self.storeTaskList.removeAll()
                dashboardTicketList()
                filterStackView.isHidden = true
                
            } else if DetailsStore.unassigned == true {
              //  DetailsStore.unassigned = false
            
                addTicketView.isHidden = true
                assignTicketsView.isHidden = true
            
                let imgBack = UIImage(named:"Arrow")
                print(imgBack as Any)
            navigationController?.navigationBar.backIndicatorImage = imgBack
            navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
                
                navigationItem.leftItemsSupplementBackButton = true
                self.navigationItem.leftBarButtonItems = nil
            navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
                
                
                
                self.navigationController?.isNavigationBarHidden = false
            self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
                
            self.navigationController?.navigationBar.tintColor = .white
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
            self.navigationController?.navigationBar.isTranslucent = false
                self.navigationItem.title = "Dashboard Details"
                
                assignType = "1"
                pageNo = "1"
                page = false
            
                btnStackView.isHidden = true
                self.storeTaskList.removeAll()
                dashboardTicketList()
                filterStackView.isHidden = true
                
            } else if DetailsStore.reassigned == true {
               // DetailsStore.reassigned = false
            
                addTicketView.isHidden = true
                assignTicketsView.isHidden = true
                
                let imgBack = UIImage(named:"Arrow")
                print(imgBack as Any)
            navigationController?.navigationBar.backIndicatorImage = imgBack
            navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
                
                navigationItem.leftItemsSupplementBackButton = true
                self.navigationItem.leftBarButtonItems = nil
            navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
                
                
                
                self.navigationController?.isNavigationBarHidden = false
            self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
                
            self.navigationController?.navigationBar.tintColor = .white
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
            self.navigationController?.navigationBar.isTranslucent = false
                self.navigationItem.title = "Dashboard Details"
                
                assignType = "2"
                pageNo = "1"
                 page = false
            
                btnStackView.isHidden = true
                self.storeTaskList.removeAll()
                dashboardTicketList()
                filterStackView.isHidden = true
                
        
            
         }else if UserDefaults.standard.object(forKey: "UserType") as! Int == 2 || UserDefaults.standard.object(forKey: "UserType") as! Int == 4 || UserDefaults.standard.object(forKey: "UserType") as! Int == 6  {
            
            
            
                if DetailsStore.allTickets == true {
            
                    self.storeTaskList.removeAll()
                SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
            
                    allTicketBtn.setTitleColor(blackColour, for: [])
                    assignTicketBtn.setTitleColor(grayColour, for: [])
                    submitTicketBtn.setTitleColor(grayColour, for: [])
            
                    assignView.backgroundColor = whiteColour
                    submitTicketView.backgroundColor = whiteColour
                    allTicketView.backgroundColor = blueColour
         
            
                    assignTicket = "2"
                    pageNo = "1"
                    page = true
            
                if  DetailsStore.page == true {
                
                        taskListingService()
                
                }else{
                
                        ticketListingService()
                
                        }
                }else if DetailsStore.assignedTickets == true {
            
                        self.storeTaskList.removeAll()
                    SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
            
                        allTicketBtn.setTitleColor(grayColour, for: [])
                        allTicketView.backgroundColor = whiteColour
                        assignTicketBtn.setTitleColor(blackColour, for: [])
                        assignView.backgroundColor = blueColour
                        submitTicketBtn.setTitleColor(grayColour, for: [])
                        submitTicketView.backgroundColor = whiteColour
          
            
                        assignTicket = "1"
                        pageNo = "1"
                        page = true
            
                        if  DetailsStore.page == true {
                
                            taskListingService()
                        }else{
                
                            ticketListingService()
                        }
            
                }else if DetailsStore.submittedTickets == true {
            
            
                        self.storeTaskList.removeAll()
                        SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                      
                        allTicketBtn.setTitleColor(grayColour, for: [])
                        allTicketView.backgroundColor = whiteColour
                        assignTicketBtn.setTitleColor(grayColour, for: [])
                        assignView.backgroundColor = whiteColour
                        submitTicketBtn.setTitleColor(blackColour, for: [])
                        submitTicketView.backgroundColor = blueColour
            
                        pageNo = "1"
                        page = true
                        submitService()
            
                }else{
            
            
            
                        DetailsStore.allTickets = true
                        addTicketView.isHidden = false
                        assignTicketsView.isHidden = false
                        self.storeTaskList.removeAll()
                        allTicketStackview.isHidden = false
                        assignTicketStackview.isHidden = false
                        submitTicketStackview.isHidden = false
                        self.navigationItem.title = "Tickets"
            
                        allTicketBtn.setTitleColor(blackColour, for: [])
                        assignTicketBtn.setTitleColor(grayColour, for: [])
                        submitTicketBtn.setTitleColor(grayColour, for: [])
            
                        assignView.backgroundColor = whiteColour
                        submitTicketView.backgroundColor = whiteColour
                        allTicketView.backgroundColor = blueColour
                        assignTicket = "2"
                        pageNo = "1"
                        page = true
            
                        ticketListingService()
                }
                
         }else if UserDefaults.standard.object(forKey: "UserType") as! Int == 3 {
            
            
            
                if DetailsStore.assignedTickets == true {
                
                    self.storeTaskList.removeAll()
                    SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                
                    allTicketStackview.isHidden = true
                    assignTicketBtn.setTitleColor(blackColour, for: [])
                    assignView.backgroundColor = blueColour
                    submitTicketBtn.setTitleColor(grayColour, for: [])
                    submitTicketView.backgroundColor = whiteColour
                
                
                    assignTicket = "1"
                    pageNo = "1"
                    page = true
                
                    if  DetailsStore.page == true {
                    
                        taskListingService()
                    }else{
                    
                        ticketListingService()
                    }
                
                }else if DetailsStore.submittedTickets == true {
                
                
                    self.storeTaskList.removeAll()
                    SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                
                     allTicketStackview.isHidden = true
                    assignTicketBtn.setTitleColor(grayColour, for: [])
                    assignView.backgroundColor = whiteColour
                    submitTicketBtn.setTitleColor(blackColour, for: [])
                    submitTicketView.backgroundColor = blueColour
                    
                    pageNo = "1"
                    page = true
                    submitService()
                
                }else{
            
                    DetailsStore.assignedTickets = true
                    addTicketView.isHidden = false
                    assignTicketsView.isHidden = false
                    self.storeTaskList.removeAll()
                    assignTicketStackview.isHidden = false
                    submitTicketStackview.isHidden = false
                    allTicketStackview.isHidden = true
                    self.navigationItem.title = "Tickets"
            
                    assignTicketBtn.setTitleColor(blackColour, for: [])
                    submitTicketBtn.setTitleColor(grayColour, for: [])
            
                    assignView.backgroundColor = blueColour
                    submitTicketView.backgroundColor = whiteColour
                    assignTicket = "1"
                    pageNo = "1"
                    page = true
            
                    ticketListingService()
                }
                
         }else if UserDefaults.standard.object(forKey: "UserType") as! Int == 5 {
            
                if DetailsStore.submittedTickets == true {
                
                
                    self.storeTaskList.removeAll()
                    SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
                
                    assignTicketStackview.isHidden = true
                    allTicketStackview.isHidden = true
                    submitTicketBtn.setTitleColor(blackColour, for: [])
                    submitTicketView.backgroundColor = blueColour
                
                    pageNo = "1"
                    page = true
                    submitService()
              
                }else{
           
                    DetailsStore.submittedTickets = true
                    addTicketView.isHidden = false
                    assignTicketsView.isHidden = false
                    self.storeTaskList.removeAll()
                    submitTicketStackview.isHidden = false
                    assignTicketStackview.isHidden = true
                    allTicketStackview.isHidden = true
                    self.navigationItem.title = "Tickets"
                    submitTicketBtn.setTitleColor(blackColour, for: [])
                    submitTicketView.backgroundColor = blueColour
                    submitService()
            }

            }

        }
        
      
    }
    
    
    
    
    
    override func viewDidLoad() {
        
        
        super.viewDidLoad()
        

       
        
        let low = NotificationCenter.default
        low.addObserver(self, selector: #selector(userLow), name: Notification.Name("Low"), object: nil)
        print(priorityValue)
        
        let high = NotificationCenter.default
        high.addObserver(self, selector: #selector(userHigh), name: Notification.Name("High"), object: nil)
        
        
        let all = NotificationCenter.default
        all.addObserver(self, selector: #selector(userAll), name: NSNotification.Name("All"), object: nil)
        
        let medium = NotificationCenter.default
        medium.addObserver(self, selector: #selector(userMedium), name: NSNotification.Name("Medium"), object: nil)
        
        let details = NotificationCenter.default
        details.addObserver(self, selector: #selector(Details), name: NSNotification.Name("Details2"), object: nil)
        
        self.table.rowHeight = UITableView.automaticDimension
        self.table.estimatedRowHeight = 50
        
        
       
         searchBar.delegate = self
        
        
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
        // Do any additional setup after loading the view.
    }
 
  
    func navigation()  {
        self.navigationController?.isNavigationBarHidden = false
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.tabBarController?.tabBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white
        
    }
    
    
    

    
    
    @objc func userLow(){
      
        navigation()
        self.storeTaskList.removeAll()
        priorityValue = "1"
        pageNo = "1"
        page = true
        
        if  DetailsStore.page == true {
            taskListingService()
        }else{
            ticketListingService()
        }
       print("testnotification")
        
    }
    
    @objc func userHigh(){
       
        navigation()
        self.storeTaskList.removeAll()
        priorityValue = "2"
        pageNo = "1"
        page = true
        
        if  DetailsStore.page == true {
            taskListingService()
        }else{
            ticketListingService()
        }
        print("testnotification")
        
    }
    
    @objc func userMedium(){
       
        navigation()
        self.storeTaskList.removeAll()
        priorityValue = "3"
        pageNo = "1"
        page = true
        
        if  DetailsStore.page == true {
            taskListingService()
        }else{
            ticketListingService()
        }
        print("testnotification")
        
    }
    
    @objc func userAll(){
        navigation()
        self.storeTaskList.removeAll()
        priorityValue = ""
        
        if  DetailsStore.page == true {
            taskListingService()
        }else{
            ticketListingService()
        }
        print("testnotification")
        
    }
    
    
    @objc func Details(){
        
       self.viewWillAppear(true)
        
    }
    
    
    @IBAction func bellBtn(_ sender: Any) {
        
        let emp = storyboard?.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
        navigationController?.pushViewController(emp, animated: true)
    }
    
    
    @IBAction func searchBarBtn(_ sender: Any) {
        
        if search {
            searchBar.isHidden = true
            search = false
        }
        else {
            if searchBar.text == ""{
                searchBar.isHidden = false
                search = false
            }else{
                searchBar.isHidden = false
                search = true
            }
        }
        
        
    }
    
    @IBAction func allTicketBtn(_ sender: Any) {
        
        
        
        self.storeTaskList.removeAll()
        SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
        
        allTicketBtn.setTitleColor(blackColour, for: [])
        assignTicketBtn.setTitleColor(grayColour, for: [])
        submitTicketBtn.setTitleColor(grayColour, for: [])
      
        assignView.backgroundColor = whiteColour
        submitTicketView.backgroundColor = whiteColour
        allTicketView.backgroundColor = blueColour
        DetailsStore.allTickets = true
        DetailsStore.assignedTickets = false
        DetailsStore.submittedTickets = false
        
        
        assignTicket = "2"
        pageNo = "1"
        page = true
        
        if  DetailsStore.page == true {
            
            taskListingService()
            
        }else{
            
            ticketListingService()
            
        }
        
    }
  
    
    
    @IBAction func assignTicketBtn(_ sender: Any) {
       
        self.storeTaskList.removeAll()
       SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
        
        allTicketBtn.setTitleColor(grayColour, for: [])
        allTicketView.backgroundColor = whiteColour
        
        assignTicketBtn.setTitleColor(blackColour, for: [])
        assignView.backgroundColor = blueColour
        
        submitTicketBtn.setTitleColor(grayColour, for: [])
        submitTicketView.backgroundColor = whiteColour
        DetailsStore.assignedTickets = true
        DetailsStore.submittedTickets = false
        DetailsStore.allTickets = false
        assignTicket = "1"
        pageNo = "1"
        page = true
        
        if  DetailsStore.page == true {
            
            taskListingService()
        }else{

            ticketListingService()
        }
        
    }
    
    @IBAction func submitTicketBtn(_ sender: Any) {
        
       DetailsStore.submittedTickets = true
        DetailsStore.allTickets = false
        DetailsStore.assignedTickets = false
        self.storeTaskList.removeAll()
        SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
        allTicketBtn.setTitleColor(grayColour, for: [])
        // allTicketBtn.backgroundColor = UIColor.white
        allTicketView.backgroundColor = whiteColour
        
        assignTicketBtn.setTitleColor(grayColour, for: [])
        assignView.backgroundColor = whiteColour
        
        submitTicketBtn.setTitleColor(blackColour, for: [])
        submitTicketView.backgroundColor = blueColour
        
        pageNo = "1"
        page = true
        submitService()
        
    }
    
  
    
    
    @IBAction func filterBtn(_ sender: Any) {
        
        let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PriorityViewController") as! PriorityViewController
        self.addChild(POPUPVC)
        POPUPVC.view.frame = self.view.frame
        self.view.addSubview(POPUPVC.view)
        POPUPVC.didMove(toParent: self)
      
    }
    

    
    
    @IBAction func plusBtn(_ sender: Any) {
        
        let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let gotoOTP = storyBoard.instantiateViewController(withIdentifier: "NTViewController") as! NTViewController
        self.navigationController?.pushViewController(gotoOTP, animated: true)
        
    }
    
    

    
    func dashboardTicketList()  {
        
     
        
        let params = ["user_id":String(userid),"department_id":String(depid),"page_no":pageNo,"status":status,"priority":priorityValue,"assign_type":assignType,"type":String(type),"login_department_id":String(depid),"login_subdeppartment":String(subDepartmentId)] as [String : Any]
        
        print(params)
        Service.shared.POSTService(serviceType: API.dashboardticketsList, parameters: params as! [String : String] ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                print(message as Any)
                print(responseDetails as Any)
                print(responseDetails["status"] as Any)
                
                if responseDetails["status"] == 200 {
                    
                    self.imagePath = (responseDetails["image_path"]?.string)!
                    
                    
                    let getData = responseDetails["data"]?.array
                    print(getData as Any)
                    
                    for getTask in getData!{
                        
                        var task = TaskList()
                        
                        task.assign_date = getTask["assign_date"].string
                        task.c_status = getTask["c_status"].int
                        task.created_at = getTask["created_at"].string
                        task.first_assignid = getTask["first_assignid"].int
                        task.priority = getTask["priority"].int
                        task.re_assignid = getTask["re_assignid"].int
                        task.id = getTask["id"].int
                        task.searchId = "ADT\(String(describing: getTask["id"].int))"
                        print(task.searchId as Any)
                        task.description = getTask["description"].string
                        task.total_rating = getTask["total_rating"].int
                        task.creator_mobile = getTask["creator_mobile"].string
                        task.creator_email = getTask["creator_email"].string
                        
                        
                        let getFrom = getTask["assign_from"].dictionary
                        var from = AssignFrom()
                        from.id = getFrom!["id"]?.int
                        from.dName = getFrom!["d_name"]?.string
                        task.assingFrom.append(from)
                        
                        
                        if  let issueSub = getTask["sub_category"].dictionary {
                            var issue = IssueSubCategory()
                            issue.id = issueSub["id"]?.int
                            issue.Name = issueSub["name"]?.string
                            task.issueSubCategory.append(issue)
                        }
                        
                        
                        let getTo = getTask["assign_to"].dictionary
                        var To = AssignTo()
                        To.id = getTo!["id"]?.int
                        To.dName = getTo!["d_name"]?.string
                        task.assignTo.append(To)
                        
                        
                        if let firstUser = getTask["firstuser"].dictionary{
                            print(firstUser)
                            var firstUserInfo = FirstUser()
                            firstUserInfo.id = firstUser["id"]?.int
                            firstUserInfo.name = firstUser["name"]?.string
                            task.firstuser.append(firstUserInfo)
                            
                        }
                        
                        if  let reAssignUser = getTask["reassignuser"].dictionary{
                            print(reAssignUser)
                            var reAssignUserInfo = ReAssignUser()
                            reAssignUserInfo.id = reAssignUser["id"]?.int
                            reAssignUserInfo.name = reAssignUser["name"]?.string
                            task.reassignuser.append(reAssignUserInfo)
                            
                        }
                        
                        if let subSubDepartment = getTask["sub_sub_department"].dictionary{
                            var subSubDepartmentUserInfo = SubSubDepartment()
                            subSubDepartmentUserInfo.id = subSubDepartment["id"]?.int
                            subSubDepartmentUserInfo.name = subSubDepartment["name"]?.string
                            task.subsubdepartment.append(subSubDepartmentUserInfo)
                        }
                        
                        
                        
                        
                        if let getAttach = getTask["attach_files"].array{
                            print(getAttach)
                            for get in getAttach{
                                
                                var storeImg = AttachFiles()
                                //let getFile = get.dictionary
                                storeImg.file_name = get["file_name"].string
                                storeImg.ticket_id = get["ticket_id"].int
                                storeImg.id = get["id"].int
                                
                                task.attachfiles.append(storeImg)
                                print(task.attachfiles)
                                
                                
                                
                            }
                            
                        }
                        
                        self.storeTaskList.append(task)
                        
                    }
                    
                    print(self.storeTaskList)
                    self.table.reloadData()
                    
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    
                    if self.pageNo == "1" {
                        self.noDataImage.isHidden = false
                        self.table.reloadData()
                        // self.filterStackView.isHidden = true
                        SingleToneClass.shared.dismissProgressLoading()
                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        }
                        
                    }else{
                        self.noDataImage.isHidden = true
                        self.filterStackView.isHidden = false
                        SingleToneClass.shared.dismissProgressLoading()
                       // self.view.makeToast("No more records found")
                        //                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "No more records found") {
                        //
                        //                        }
                        
                    }
                    print(self.storeTaskList)
                    
                    
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
            
        }
        
        
    }
    
    
    
    func taskListingService()  {
       
        let userid = UserDefaults.standard.object(forKey:"UserId") as! Int
        let depid = UserDefaults.standard.object(forKey: "DepartmentId") as! Int
        
        
        let params = ["user_id":String(userid),"department_id":String(depid),"page_no":"0","assign_task":assignTicket,"priority":priorityValue] as [String : Any]
        
        print(params)
        Service.shared.POSTService(serviceType: API.listingTask, parameters: params as! [String : String] ) { (response) -> (Void) in
            
            print(response)
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                print(message as Any)
                print(responseDetails as Any)
                print(responseDetails["status"] as Any)
                
                if responseDetails["status"] == 200 {
                   // self.table.isHidden = false
                    
                    self.imagePath = (responseDetails["image_path"]?.string)!
                    
                  let getData = responseDetails["data"]?.array
                  
                    for getTask in getData!{
                        
                        var task = TaskList()
                        
                        task.assign_date = getTask["date"].string
                        task.c_status = getTask["c_status"].int
                        print(task.c_status as Any)
                        task.created_at = getTask["created_at"].string
                        task.first_assignid = getTask["first_assignid"].int
                        task.priority = getTask["priority"].int
                        task.re_assignid = getTask["re_assignid"].int
                        task.id = getTask["id"].int
                        task.searchId = "ADT\(String(describing: getTask["id"].int))"
                        print(task.searchId as Any)
                        task.description = getTask["description"].string
                        task.total_rating = getTask["total_rating"].int
                        
                        let getFrom = getTask["assign_from"].dictionary
                        
                        var from = AssignFrom()
                        from.id = getFrom!["id"]?.int
                        from.dName = getFrom!["d_name"]?.string
                        
                        task.assingFrom.append(from)
                        
                        
                        
                        let getTo = getTask["assign_to"].dictionary
                        
                        var To = AssignTo()
                        To.id = getTo!["id"]?.int
                        To.dName = getTo!["d_name"]?.string
                        task.assignTo.append(To)
                       
                        
                        
                        if let firstUser = getTask["firstuser"].dictionary{
                            print(firstUser)
                            var firstUserInfo = FirstUser()
                            firstUserInfo.id = firstUser["id"]?.int
                            firstUserInfo.name = firstUser["name"]?.string
                            task.firstuser.append(firstUserInfo)
                            
                        }
                        
                        if  let reAssignUser = getTask["reassignuser"].dictionary{
                            print(reAssignUser)
                            var reAssignUserInfo = ReAssignUser()
                            reAssignUserInfo.id = reAssignUser["id"]?.int
                            reAssignUserInfo.name = reAssignUser["name"]?.string
                            
                            task.reassignuser.append(reAssignUserInfo)
                            
                        }
                        
                        
                        if let getAttach = getTask["attach_files"].array{
                            print(getAttach)
                            for get in getAttach{
                                
                                var storeImg = AttachFiles()
                                //let getFile = get.dictionary
                                storeImg.file_name = get["file_name"].string
                                storeImg.ticket_id = get["ticket_id"].int
                                storeImg.id = get["id"].int
                                
                                task.attachfiles.append(storeImg)
                                print(task.attachfiles)
                                
                                
                                
                            }
                            
                        }
                        
                        self.storeTaskList.append(task)
                        
                    }
                    
                    print(self.storeTaskList)
                    self.table.reloadData()
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                      
                        self.table.reloadData()
                    }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
        
        }
        
        
    }
    
    
    func ticketListingService()  {
        
    

        let params = ["user_id":String(userid),"department_id":String(depid),"page_no":"1","assign_ticket":assignTicket,"status":status,"priority":priorityValue,"assign_type":assignType,"type":String(type),"login_department_id":String(depid),"login_subdeppartment":"\(subDepartmentId)"] as [String : Any]
        
        print(params)
        Service.shared.POSTService(serviceType: API.listingTicket, parameters: params as! [String : String] ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
               
                if responseDetails["status"] == 200 {
                  
                     self.imagePath = (responseDetails["image_path"]?.string)!
                 
                    
                    let getData = responseDetails["data"]?.array
                   
                   self.noDataImage.isHidden = true
                    for getTask in getData!{
                        
                        var task = TaskList()
                        
                        task.assign_date = getTask["assign_date"].string
                        task.c_status = getTask["c_status"].int
                        task.created_at = getTask["created_at"].string
                        task.first_assignid = getTask["first_assignid"].int
                        task.priority = getTask["priority"].int
                        task.re_assignid = getTask["re_assignid"].int
                        task.id = getTask["id"].int
                        task.searchId = "ADT\(String(describing: getTask["id"].int!))"
                        print(task.searchId as Any)
                        task.description = getTask["description"].string
                        task.total_rating = getTask["total_rating"].int
                        task.creator_mobile = getTask["creator_mobile"].string
                        task.creator_email = getTask["creator_email"].string
                        
                        
                        let getFrom = getTask["assign_from"].dictionary
                        var from = AssignFrom()
                        from.id = getFrom!["id"]?.int
                        from.dName = getFrom!["d_name"]?.string
                        task.assingFrom.append(from)
                        
                        
                        if  let issueSub = getTask["sub_category"].dictionary {
                        var issue = IssueSubCategory()
                            issue.id = issueSub["id"]?.int
                            issue.Name = issueSub["name"]?.string
                        task.issueSubCategory.append(issue)
                        }
                       
                        
                        let getTo = getTask["assign_to"].dictionary
                        var To = AssignTo()
                        To.id = getTo!["id"]?.int
                        To.dName = getTo!["d_name"]?.string
                        task.assignTo.append(To)
                        
                    
                        if let firstUser = getTask["firstuser"].dictionary{
                          
                            var firstUserInfo = FirstUser()
                            firstUserInfo.id = firstUser["id"]?.int
                            firstUserInfo.name = firstUser["name"]?.string
                            task.firstuser.append(firstUserInfo)

                        }
                        
                        if  let reAssignUser = getTask["reassignuser"].dictionary{
                            
                            var reAssignUserInfo = ReAssignUser()
                            reAssignUserInfo.id = reAssignUser["id"]?.int
                            reAssignUserInfo.name = reAssignUser["name"]?.string
                            task.reassignuser.append(reAssignUserInfo)
                 
                    }
                        
                        if let subSubDepartment = getTask["sub_sub_department"].dictionary{
                            var subSubDepartmentUserInfo = SubSubDepartment()
                            subSubDepartmentUserInfo.id = subSubDepartment["id"]?.int
                            subSubDepartmentUserInfo.name = subSubDepartment["name"]?.string
                            task.subsubdepartment.append(subSubDepartmentUserInfo)
                        }
                        
                        
                        
                        
                        if let getAttach = getTask["attach_files"].array{
                      
                            for get in getAttach{
                            
                            var storeImg = AttachFiles()
                           
                                storeImg.file_name = get["file_name"].string
                                storeImg.ticket_id = get["ticket_id"].int
                                storeImg.id = get["id"].int
                            
                            task.attachfiles.append(storeImg)
                           
                            
                            
                        }
                            
                        }
                       
                        
                        if let fileAttach = getTask["knowledge"].array{
                            print(fileAttach)
                            for get in fileAttach{
                                
                                var storeImg = KnowledgeBaseFiles()
                                
                               
                                storeImg.note_file = get["note_file"].string
                                storeImg.ticket_id = get["ticket_id"].int
                                storeImg.id = get["id"].int
                                
                                task.knowledgeBaseFiles.append(storeImg)
                               
                                
                                
                                
                            }
                            
                        }
                        
                        
                        
                     self.storeTaskList.append(task)
                        print(self.storeTaskList)
                        
                    }
                    
                  
                    self.table.reloadData()
                    
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    
                    if self.pageNo == "1" {
                        self.noDataImage.isHidden = false
                         self.table.reloadData()
                       // self.filterStackView.isHidden = true
                        SingleToneClass.shared.dismissProgressLoading()
                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        }
                        
                    }else{
                        self.noDataImage.isHidden = true
                        
                        self.filterStackView.isHidden = false
                        SingleToneClass.shared.dismissProgressLoading()
                        // self.view.makeToast("No more records found")
//                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "No more records found") {
//                           
//                        }
                        
                    }
                    print(self.storeTaskList)
                    
                    
                }
                
                
            }else{
                
                self.noDataImage.isHidden = true
                                       
                self.filterStackView.isHidden = false
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
            
        }
        
        
    }
    
    
    func submitService()  {
        
     
        
        let params = ["user_id":String(userid),"page_no":"1","login_department_id":String(depid)] as [String : Any]
        
        print(params)
        Service.shared.POSTService(serviceType: API.submitTicket, parameters: params as! [String : String] ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
             
                
                if responseDetails["status"] == 200 {
                    
                    self.imagePath = (responseDetails["image_path"]?.string)!
                    
                    let getData = responseDetails["data"]?.array
                  
                    self.noDataImage.isHidden = true
                    
                    
                    for getTask in getData!{
                        
                        var task = TaskList()
                        
                        task.assign_date = getTask["assign_date"].string
                        task.c_status = getTask["c_status"].int
                        task.created_at = getTask["created_at"].string
                        task.first_assignid = getTask["first_assignid"].int
                        task.priority = getTask["priority"].int
                        task.re_assignid = getTask["re_assignid"].int
                        task.id = getTask["id"].int
                        task.searchId = "ADT\(String(describing: getTask["id"].int!))"
                        print(task.searchId as Any)
                        task.description = getTask["description"].string
                        task.total_rating = getTask["total_rating"].int
                        task.creator_mobile = getTask["creator_mobile"].string
                        task.creator_email = getTask["creator_email"].string
                        
                        
                        let getFrom = getTask["assign_from"].dictionary
                        var from = AssignFrom()
                        from.id = getFrom!["id"]?.int
                        from.dName = getFrom!["d_name"]?.string
                        task.assingFrom.append(from)
                        
                        
                        if let issueSub = getTask["sub_category"].dictionary {
                        var issue = IssueSubCategory()
                            issue.id = issueSub["id"]?.int
                            issue.Name = issueSub["name"]?.string
                        task.issueSubCategory.append(issue)
                        }
                        
                        
                        let getTo = getTask["assign_to"].dictionary
                        var To = AssignTo()
                        To.id = getTo!["id"]?.int
                        To.dName = getTo!["d_name"]?.string
                        task.assignTo.append(To)
                        
                        
                        if let firstUser = getTask["firstuser"].dictionary{
                            print(firstUser)
                            var firstUserInfo = FirstUser()
                            firstUserInfo.id = firstUser["id"]?.int
                            firstUserInfo.name = firstUser["name"]?.string
                            task.firstuser.append(firstUserInfo)
                            
                        }
                        
                        if  let reAssignUser = getTask["reassignuser"].dictionary{
                            print(reAssignUser)
                            var reAssignUserInfo = ReAssignUser()
                            reAssignUserInfo.id = reAssignUser["id"]?.int
                            reAssignUserInfo.name = reAssignUser["name"]?.string
                            task.reassignuser.append(reAssignUserInfo)
                            
                        }
                        
                        if let subSubDepartment = getTask["sub_sub_department"].dictionary{
                            var subSubDepartmentUserInfo = SubSubDepartment()
                            subSubDepartmentUserInfo.id = subSubDepartment["id"]?.int
                            subSubDepartmentUserInfo.name = subSubDepartment["name"]?.string
                            task.subsubdepartment.append(subSubDepartmentUserInfo)
                        }
                        
                        
                        if let getAttach = getTask["attach_files"].array{
                            print(getAttach)
                            for get in getAttach{
                                
                                var storeImg = AttachFiles()
                                //let getFile = get.dictionary
                                storeImg.file_name = get["file_name"].string
                                storeImg.ticket_id = get["ticket_id"].int
                                storeImg.id = get["id"].int
                                
                                task.attachfiles.append(storeImg)
                                print(task.attachfiles)
                                
                                
                                
                            }
                            
                        }
                        
                        
                        if let fileAttach = getTask["knowledge"].array{
                            print(fileAttach)
                            for get in fileAttach{
                                
                                var storeImg = KnowledgeBaseFiles()
                              
                                storeImg.path = get["path"].string
                                storeImg.note_file = get["note_file"].string
                                storeImg.ticket_id = get["ticket_id"].int
                                storeImg.id = get["id"].int
                                
                                task.knowledgeBaseFiles.append(storeImg)
                                print(task.knowledgeBaseFiles)
                                
                                
                                
                            }
                            
                        }
                        
                        
                        self.storeTaskList.append(task)
                        
                    }
                    
                    print(self.storeTaskList)
                    self.table.reloadData()
                    
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    
                    if self.pageNo == "1" {
                        self.noDataImage.isHidden = false
                        self.table.reloadData()
                        // self.filterStackView.isHidden = true
                        SingleToneClass.shared.dismissProgressLoading()
                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        }
                        
                    }else{
                        self.noDataImage.isHidden = true
                        self.filterStackView.isHidden = false
                        SingleToneClass.shared.dismissProgressLoading()
                     //   [self.view makeToast:@"No more records found"]
                     //   self.view.makeToast("No more records found")
//                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "No more records found") {
//                            
//                        }
                        
                    }
                    print(self.storeTaskList)
                    
                    
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
            
        }
        
        
    }

    
    

    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        
        
        searchResult = storeTaskList.filter({ $0.id == Int(searchText) ||  $0.searchId?.lowercased() == searchText.lowercased() || $0.assingFrom[0].dName?.lowercased() == searchText.lowercased() || $0.c_status == Int(searchText)
            
        })
        
        
        if searchResult.isEmpty == false{
            
            search = true
            table.reloadData()
            
        }else{

            if searchBar.text == ""{
               
                search = false
            }else{
              
                search = true
                       }
            
          //  search = false
            table.reloadData()
            
        }
        
        
        
        
    }
    
    
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = true
        
        
    }
    func searchBarCancelButtonClicked(_ searchBaar: UISearchBar) {
        searchActive = false
        search = false
        searchBaar.showsCancelButton = false
        searchBaar.text = ""
        searchBaar.resignFirstResponder()
        searchBaar.endEditing(true)
        table.reloadData()
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
      //  searchActive = false
      //  search = false
        self.searchBar.endEditing(true)
           table.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      
        if search {
            return searchResult.count
        }else{
            return storeTaskList.count
            
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MPITableViewCell
        
       cell.cellView.backgroundColor = UIColor(red: 235/255, green: 231/255, blue: 230/255, alpha: 1.0)
   
        
        let g = UIColor(red: 28/255, green: 180/255, blue: 80/255, alpha: 1.0)
        let b = UIColor(red: 0/255, green: 27/255, blue: 96/255, alpha: 1.0)
        
        
        if search{
            
            
            
            
          // cell.taskId.text = "ADT\(searchResult[indexPath.row].id!)"
           // print("ADT\(searchResult[indexPath.row].id!)")
            
            print(searchResult[indexPath.row].searchId)
            cell.taskId.text = "\(searchResult[indexPath.row].id!)"
            
            let a = searchResult[indexPath.row].assign_date
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            
            let showDate = dateFormatter.date(from: a!)
            dateFormatter.dateFormat = "dd-MM-yyyy"
            let resultString = dateFormatter.string(from: showDate!)
            print(resultString)
            cell.intiatedDateLbl.text = resultString
            
            
            
            
            if searchResult[indexPath.row].reassignuser.isEmpty == true {
                
                
                if searchResult[indexPath.row].firstuser.isEmpty == true{
                    cell.firstAssignNameLbl.text = "-"
                    
                }else{
                    
                    cell.firstAssignNameLbl.text = searchResult[indexPath.row].firstuser[0].name!
                }
                
            }else{
                
                cell.firstAssignNameLbl.text = searchResult[indexPath.row].reassignuser[0].name!
                
            }
            
            
            if searchResult[indexPath.row].issueSubCategory.isEmpty == true{
                
                cell.issueSCLbl.text = "-"
                
            }else{
                
                cell.issueSCLbl.text = searchResult[indexPath.row].issueSubCategory[0].Name
                
                
            }
            
            
            
            let CStatus = searchResult[indexPath.row].c_status
            
            if CStatus == 0 {
                cell.currentStatusLbl.text = "Pending"
                cell.statusLbl.text = "Pending"
                cell.currentStatusLbl.textColor = UIColor(red: 190/255, green: 144/255, blue: 4/255, alpha: 1.0)
                cell.statusLbl.textColor = UIColor(red: 190/255, green: 144/255, blue: 4/255, alpha: 1.0)
                
            }else if CStatus == 1 {
                cell.currentStatusLbl.text = "Overdue"
                cell.statusLbl.text = "Overdue"
                cell.currentStatusLbl.textColor = UIColor(red: 190/255, green: 0/255, blue: 3/255, alpha: 1.0)
                cell.statusLbl.textColor = UIColor(red: 190/255, green: 0/255, blue: 3/255, alpha: 1.0)
                
            }else if CStatus == 2 {
                cell.currentStatusLbl.text = "Resolved"
                cell.statusLbl.text = "Resolved"
                cell.currentStatusLbl.textColor = UIColor(red: 28/255, green: 180/255, blue: 80/255, alpha: 1.0)
                cell.statusLbl.textColor = UIColor(red: 28/255, green: 180/255, blue: 80/255, alpha: 1.0)
                
            }else{
                cell.currentStatusLbl.text = "Reopen"
                cell.statusLbl.text = "Reopen"
                cell.currentStatusLbl.textColor = UIColor(red: 0/255, green: 27/255, blue: 96/255, alpha: 1.0)
                cell.statusLbl.textColor = UIColor(red: 0/255, green: 27/255, blue: 96/255, alpha: 1.0)
            }
            
            
            
            
            
            
            
            if searchResult[indexPath.row].subsubdepartment.isEmpty == true{
                cell.categoryLbl.text = "-"
                
            }else{
                
                cell.categoryLbl.text = searchResult[indexPath.row].subsubdepartment[0].name
            }
            
            
            
            
            
            
            let pri = searchResult[indexPath.row].priority!
            
            if pri == 1{
                
                cell.priorityStatusLbl.text = "Low"
                cell.priorityStatusLbl.backgroundColor = UIColor(red: 237/255, green: 138/255, blue: 25/255, alpha: 1.0)
                
            }else if pri == 3{
                cell.priorityStatusLbl.text = "Medium"
                cell.priorityStatusLbl.backgroundColor = UIColor(red: 0/255, green: 151/255, blue: 248/255, alpha: 1.0)
                
                
            }else{
                cell.priorityStatusLbl.text = "High"
                cell.priorityStatusLbl.backgroundColor = UIColor(red: 188/255, green: 0/255, blue: 3/255, alpha: 1.0)
                
            }
            
             cell.descriptionLbl.text = searchResult[indexPath.row].description
            
            
            cell.plusBtn.tag = indexPath.row
            cell.assignToBtn.tag = indexPath.row
            
            
            
            if self.selectedIndex == indexPath.row {
                print(UserDefaults.standard.object(forKey: "Role") as? String as Any )
                
                if UserDefaults.standard.object(forKey: "Role") as? String == "Department Manager" || UserDefaults.standard.object(forKey: "Role") as? String == "-"{
                    
                   
                    
                    
                    if DetailsStore.assignedTickets == true {
                        
                        if cell.statusLbl.text == "Overdue" {
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Resolved", for: .normal)
                            cell.assignToBtn.setTitleColor(g, for: [])
                            cell.view2Height.constant = 215
                            cell.view3Height.constant = 215
                        }else{
                            cell.actionLbl.isHidden = true
                            cell.assignToBtn.isHidden = true
                            cell.view2Height.constant = 190
                            cell.view3Height.constant = 190
                        }
                        
                        
                    }else if DetailsStore.submittedTickets == true{
                        
                        if cell.statusLbl.text == "Resolved" {
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Reopen", for: .normal)
                             cell.assignToBtn.setTitleColor(g, for: [])
                            cell.view2Height.constant = 215
                            cell.view3Height.constant = 215
                        } else if cell.statusLbl.text == "Overdue" {
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Resolved", for: .normal)
                            cell.assignToBtn.setTitleColor(b, for: [])
                            cell.view2Height.constant = 215
                            cell.view3Height.constant = 215
                        }else{
                            cell.actionLbl.isHidden = true
                            cell.assignToBtn.isHidden = true
                            cell.view2Height.constant = 190
                            cell.view3Height.constant = 190
                        }
                        
                    }else if DetailsStore.allTickets == true {
                        
                        if cell.statusLbl.text == "Overdue" || cell.statusLbl.text == "Pending" {
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Assign To", for: .normal)
                             cell.assignToBtn.setTitleColor(b, for: [])
                            
                        }else if cell.statusLbl.text == "Resolved"{
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Reopen", for: .normal)
                             cell.assignToBtn.setTitleColor(b, for: [])
                            
                        }else if cell.statusLbl.text == "Reopen"{
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Resolved", for: .normal)
                              cell.assignToBtn.setTitleColor(g, for: [])
                        }
                        cell.view2Height.constant = 215
                        cell.view3Height.constant = 215
                        
                    }
                    
                    
                    
                }else{
                    
                    if DetailsStore.assignedTickets == true {
                        
                        if cell.statusLbl.text == "Overdue" {
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Resolved", for: .normal)
                              cell.assignToBtn.setTitleColor(g, for: [])
                            cell.view2Height.constant = 215
                            cell.view3Height.constant = 215
                        }else{
                            cell.actionLbl.isHidden = true
                            cell.assignToBtn.isHidden = true
                            cell.view2Height.constant = 190
                            cell.view3Height.constant = 190
                        }
                        
                        
                    }else if DetailsStore.submittedTickets == true{
                        
                        if cell.statusLbl.text == "Resolved" {
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Reopen", for: .normal)
                             cell.assignToBtn.setTitleColor(b, for: [])
                            cell.view2Height.constant = 215
                            cell.view3Height.constant = 215
                        }else if cell.statusLbl.text == "Overdue" {
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Resolved", for: .normal)
                              cell.assignToBtn.setTitleColor(g, for: [])
                            cell.view2Height.constant = 215
                            cell.view3Height.constant = 215
                        }else{
                            cell.actionLbl.isHidden = true
                            cell.assignToBtn.isHidden = true
                            cell.view2Height.constant = 190
                            cell.view3Height.constant = 190
                        }
                        
                    }else if DetailsStore.allTickets == true {
                        
                        if cell.statusLbl.text == "Resolved" {
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Reopen", for: .normal)
                             cell.assignToBtn.setTitleColor(b, for: [])
                            cell.view2Height.constant = 215
                            cell.view3Height.constant = 215
                        }else if cell.statusLbl.text == "Overdue" {
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Resolved", for: .normal)
                              cell.assignToBtn.setTitleColor(g, for: [])
                            cell.view2Height.constant = 215
                            cell.view3Height.constant = 215
                        }else if cell.statusLbl.text == "Reopen"{
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Resolved", for: .normal)
                              cell.assignToBtn.setTitleColor(g, for: [])
                            cell.view2Height.constant = 215
                            cell.view3Height.constant = 215
                        }else{
                            
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Assign To Me", for: .normal)
                             cell.assignToBtn.setTitleColor(b, for: [])
                            cell.view2Height.constant = 215
                            cell.view3Height.constant = 215
                        }
                        
                        
                    }
                    
                }
                
                
                
                
                
                cell.assignToBtn.titleLabel?.adjustsFontSizeToFitWidth = true
                cell.assignToBtn.titleLabel?.numberOfLines = 1
                cell.assignToBtn.titleLabel?.minimumScaleFactor = 0.1
                cell.assignToBtn.clipsToBounds = true
                
                cell.cellView.backgroundColor = UIColor(red: 235/255, green: 231/255, blue: 230/255, alpha: 1.0)
                
                cell.plusBtn.setImage(UIImage(named: "mins"), for: .normal)
                
                
                
            }else {
                
                
                self.Action =  cell.assignToBtn.titleLabel!.text!
                
                cell.view2Height.constant = 0
                cell.view3Height.constant = 0
                cell.assignToBtn.isHidden = true
                
                
                cell.plusBtn.setImage(UIImage(named: "Plus-1"), for: .normal)
            }
            
            
            
            print(indexPath.row)
            print(storeTaskList.count - 1)
            
//            if page == true {
//
//                if indexPath.row == searchResult.count - 1{
//                    pageNo = "\(Int(pageNo)! + 1 )"
//
//                    if  DetailsStore.submittedTickets == true {
//                        submitService()
//
//                    }else{
//                        ticketListingService()
//                    }
//
//                }
//            }
//
            
            
            cell.assignToBtn.addTarget(self, action: #selector(MPIViewController.AssignToAction(_:)), for: .touchUpInside)
            
            cell.plusBtn.addTarget(self, action: #selector(MPIViewController.downArrowTapped(_:)), for: .touchUpInside)
            
            
            return cell
        }else{
            

            
            
            print("ADT\(storeTaskList[indexPath.row].id!)")
            
            cell.taskId.text = "ADT\(storeTaskList[indexPath.row].id!)"
            
            let a = storeTaskList[indexPath.row].assign_date
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            
            let showDate = dateFormatter.date(from: a!)
            dateFormatter.dateFormat = "dd-MM-yyyy"
            let resultString = dateFormatter.string(from: showDate!)
            print(resultString)
            cell.intiatedDateLbl.text = resultString
            
            
            
            
            if storeTaskList[indexPath.row].reassignuser.isEmpty == true {
            
            
                if storeTaskList[indexPath.row].firstuser.isEmpty == true{
                    cell.firstAssignNameLbl.text = "-"
                
                }else{
           
                    cell.firstAssignNameLbl.text = storeTaskList[indexPath.row].firstuser[0].name!
                }
            
            }else{
               
                cell.firstAssignNameLbl.text = storeTaskList[indexPath.row].reassignuser[0].name!
              
            }
            complaintAssign = cell.firstAssignNameLbl.text ?? "-"
            
                if storeTaskList[indexPath.row].issueSubCategory.isEmpty == true{
                
                    cell.issueSCLbl.text = "-"

                }else{
          
                    cell.issueSCLbl.text = storeTaskList[indexPath.row].issueSubCategory[0].Name


                }
            
     
            
                let CStatus = storeTaskList[indexPath.row].c_status
            
                if CStatus == 0 {
                    cell.currentStatusLbl.text = "Pending"
                    cell.statusLbl.text = "Pending"
                    cell.currentStatusLbl.textColor = UIColor(red: 190/255, green: 144/255, blue: 4/255, alpha: 1.0)
                    cell.statusLbl.textColor = UIColor(red: 190/255, green: 144/255, blue: 4/255, alpha: 1.0)
                
                }else if CStatus == 1 {
                    cell.currentStatusLbl.text = "Overdue"
                    cell.statusLbl.text = "Overdue"
                    cell.currentStatusLbl.textColor = UIColor(red: 190/255, green: 0/255, blue: 3/255, alpha: 1.0)
                    cell.statusLbl.textColor = UIColor(red: 190/255, green: 0/255, blue: 3/255, alpha: 1.0)
          
                }else if CStatus == 2 {
                    cell.currentStatusLbl.text = "Resolved"
                    cell.statusLbl.text = "Resolved"
                    cell.currentStatusLbl.textColor = UIColor(red: 28/255, green: 180/255, blue: 80/255, alpha: 1.0)
                    cell.statusLbl.textColor = UIColor(red: 28/255, green: 180/255, blue: 80/255, alpha: 1.0)
      
                }else{
                    cell.currentStatusLbl.text = "Reopen"
                    cell.statusLbl.text = "Reopen"
                    cell.currentStatusLbl.textColor = UIColor(red: 0/255, green: 27/255, blue: 96/255, alpha: 1.0)
                    cell.statusLbl.textColor = UIColor(red: 0/255, green: 27/255, blue: 96/255, alpha: 1.0)
                }
            
            
            
            
            
            
            
                if storeTaskList[indexPath.row].subsubdepartment.isEmpty == true{
                    cell.categoryLbl.text = "-"
                
                }else{
                
                    cell.categoryLbl.text = storeTaskList[indexPath.row].subsubdepartment[0].name
                }
            
            
            
            
            
            
                let pri = storeTaskList[indexPath.row].priority!
            
                if pri == 1{
                
                    cell.priorityStatusLbl.text = "Low"
                    cell.priorityStatusLbl.backgroundColor = UIColor(red: 237/255, green: 138/255, blue: 25/255, alpha: 1.0)
                
                }else if pri == 3{
                    cell.priorityStatusLbl.text = "Medium"
                    cell.priorityStatusLbl.backgroundColor = UIColor(red: 0/255, green: 151/255, blue: 248/255, alpha: 1.0)
                
           
                }else{
                    cell.priorityStatusLbl.text = "High"
                    cell.priorityStatusLbl.backgroundColor = UIColor(red: 188/255, green: 0/255, blue: 3/255, alpha: 1.0)
           
                }
            
         
            cell.descriptionLbl.text = storeTaskList[indexPath.row].description
           
 
            
                cell.plusBtn.tag = indexPath.row
                cell.assignToBtn.tag = indexPath.row
            
                 
            if self.selectedIndex == indexPath.row {
             
                print(UserDefaults.standard.object(forKey: "Role") as? String as Any )
                        
                      
                if UserDefaults.standard.object(forKey: "Role") as? String == "Department Manager" || UserDefaults.standard.object(forKey: "Role") as? String == "SubDepartmentManager"{
                            
                            
                          
                    if DetailsStore.assignedTickets == true {
                                
                              
                        if cell.statusLbl.text == "Overdue" || cell.statusLbl.text == "Pending" || cell.statusLbl.text == "Reopen" {
                                  
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Resolved", for: .normal)
                            cell.assignToBtn.setTitleColor(g, for: [])
                            cell.view2Height.constant = 215
                            cell.view3Height.constant = 215
                            
                        }else{
                        
                            cell.actionLbl.isHidden = true
                            cell.assignToBtn.isHidden = true
                            cell.view2Height.constant = 190
                            cell.view3Height.constant = 190
                            
                        }
                
                    }else if DetailsStore.submittedTickets == true{
                                
                              
                        if cell.statusLbl.text == "Resolved" {
                                
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Reopen", for: .normal)
                            cell.assignToBtn.setTitleColor(b, for: [])
                            cell.view2Height.constant = 215
                            cell.view3Height.constant = 215

                            
                        }else{
                        
                            cell.actionLbl.isHidden = true
                            cell.assignToBtn.isHidden = true
                            cell.view2Height.constant = 190
                            cell.view3Height.constant = 190
                            
                        }
                                
                        
                    }else if DetailsStore.allTickets == true {
                                
                    
                        if cell.statusLbl.text == "Pending" {
                        
                            if  cell.firstAssignNameLbl.text == "-" {
                                cell.actionLbl.isHidden = false
                                cell.assignToBtn.isHidden = false
                                cell.assignToBtn.setTitle("Assign To", for: .normal)
                                cell.assignToBtn.setTitleColor(b, for: [])
                                
                            }else{
                                cell.actionLbl.isHidden = false
                                cell.assignToBtn.isHidden = false
                                cell.assignToBtn.setTitle("Re Assign To", for: .normal)
                                cell.assignToBtn.setTitleColor(b, for: [])
                            }
                            
                        }else if cell.statusLbl.text == "Resolved"{
                        
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Reopen", for: .normal)
                            cell.assignToBtn.setTitleColor(b, for: [])
                               
                            
                        }else if cell.statusLbl.text == "Reopen"{
                        
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Resolved", for: .normal)
                            cell.assignToBtn.setTitleColor(g, for: [])
                            
                        }else if cell.statusLbl.text == "Overdue" {
                        
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Re Assign To", for: .normal)
                            cell.assignToBtn.setTitleColor(b, for: [])
                               
                        }
                        
                        cell.view2Height.constant = 215
                        cell.view3Height.constant = 215
                                
                    }
                            
        }else{
                            
            if DetailsStore.assignedTickets == true {
                                
                    
                if cell.statusLbl.text == "Overdue" || cell.statusLbl.text == "Pending" || cell.statusLbl.text == "Reopen"
                                {
                        
                            cell.actionLbl.isHidden = false
                            cell.assignToBtn.isHidden = false
                            cell.assignToBtn.setTitle("Resolved", for: .normal)
                            cell.assignToBtn.setTitleColor(g, for: [])
                            cell.view2Height.constant = 215
                            cell.view3Height.constant = 215
                            
                    }else{
                                  
                        cell.actionLbl.isHidden = true
                        cell.assignToBtn.isHidden = true
                        cell.view2Height.constant = 190
                        cell.view3Height.constant = 190
                        
                    }
                                
            }else if DetailsStore.submittedTickets == true{
                                
                              
                if cell.statusLbl.text == "Resolved" {
                
                    cell.actionLbl.isHidden = false
                    cell.assignToBtn.isHidden = false
                    cell.assignToBtn.setTitle("Reopen", for: .normal)
                    cell.assignToBtn.setTitleColor(b, for: [])
                    cell.view2Height.constant = 215
                    cell.view3Height.constant = 215

                    
//                }else if cell.statusLbl.text == "Overdue" {

//                    cell.actionLbl.isHidden = false
//                  cell.assignToBtn.isHidden = false
//                    cell.assignToBtn.setTitle("Resolved", for: .normal)
//                  cell.view2Height.constant = 175
//                  cell.view3Height.constant = 175
                              
                }else{
                
                    cell.actionLbl.isHidden = true
                    cell.assignToBtn.isHidden = true
                    cell.view2Height.constant = 175
                    cell.view3Height.constant = 175
                    
                }
                                            
            }else if DetailsStore.allTickets == true {
                                
                if cell.statusLbl.text == "Resolved" {
                                    
                    cell.actionLbl.isHidden = false
                    cell.assignToBtn.isHidden = false
                    cell.assignToBtn.setTitle("Reopen", for: .normal)
                    cell.assignToBtn.setTitleColor(b, for: [])
                    cell.view2Height.constant = 215
                    cell.view3Height.constant = 215
                               
                }else if cell.statusLbl.text == "Overdue" ||  cell.statusLbl.text == "Reopen"  {
                
                    cell.actionLbl.isHidden = false
                    cell.assignToBtn.isHidden = false
                    cell.assignToBtn.setTitle("Resolved", for: .normal)
                    cell.assignToBtn.setTitleColor(g, for: [])
                    cell.view2Height.constant = 215
                    cell.view3Height.constant = 215

                    
//                }else if cell.statusLbl.text == "Reopen"{

//                    cell.actionLbl.isHidden = false
//                    cell.assignToBtn.isHidden = false
//                    cell.assignToBtn.setTitle("Resolved", for: .normal)
//                    cell.assignToBtn.setTitleColor(g, for: [])
//                    cell.view2Height.constant = 175
//                    cell.view3Height.constant = 175
                  
                }else{
                                
                    cell.assignToBtn.isHidden = false
                    cell.assignToBtn.setTitle("Assign To Me", for: .normal)
                    cell.assignToBtn.setTitleColor(b, for: [])
                    cell.view2Height.constant = 215
                    cell.view3Height.constant = 215
                    
                }
                            
            }
                            
        }

            cell.assignToBtn.titleLabel?.adjustsFontSizeToFitWidth = true
                cell.assignToBtn.titleLabel?.numberOfLines = 1
                cell.assignToBtn.titleLabel?.minimumScaleFactor = 0.1
                cell.assignToBtn.clipsToBounds = true
                
                cell.cellView.backgroundColor = UIColor(red: 235/255, green: 231/255, blue: 230/255, alpha: 1.0)
        
                cell.plusBtn.setImage(UIImage(named: "mins"), for: .normal)
                

                
                
            }else {
            
                self.Action =  cell.assignToBtn.titleLabel!.text!
              
                        cell.view2Height.constant = 0
                        cell.view3Height.constant = 0
                        cell.assignToBtn.isHidden = true

                
                cell.plusBtn.setImage(UIImage(named: "Plus-1"), for: .normal)
                }
            
            
 
                print(indexPath.row)
                print(storeTaskList.count - 1)
            
//                    if page == true {
//
//                    if indexPath.row == storeTaskList.count - 1{
//                        pageNo = "\(Int(pageNo)! + 1 )"
//
//                        if  DetailsStore.submittedTickets == true {
//                            submitService()
//
//                        }else{
//                            ticketListingService()
//                        }
//
//                    }
//                }
//

            
                cell.assignToBtn.addTarget(self, action: #selector(MPIViewController.AssignToAction(_:)), for: .touchUpInside)
            
                cell.plusBtn.addTarget(self, action: #selector(MPIViewController.downArrowTapped(_:)), for: .touchUpInside)
            
            
                return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        DetailsStore.resolution = false
        DetailsStore.assignedComplaint = false
        DetailsStore.submittedComplaint = false
        DetailsStore.customerComplaint = false

        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MPITableViewCell
        
        
        let emp = storyboard?.instantiateViewController(withIdentifier: "TDViewController") as! TDViewController
        
        
        
        if search{
            emp.get = searchResult[indexPath.row]
            print(emp.get as Any)
            
            AttachFiles.getattachments = searchResult[indexPath.row].attachfiles
            AttachFiles.baseImagePath = self.imagePath
            emp.imagePath = self.imagePath
            emp.action = cell.assignToBtn.titleLabel!.text!
            
            
            if searchResult[indexPath.row].firstuser.isEmpty == true{
                emp.assign = "-"
                
            }else{
                
                emp.assign = searchResult[indexPath.row].firstuser[0].name!
            }
            
        }else{
        
            emp.get = storeTaskList[indexPath.row]
            print(emp.get as Any)
        
            AttachFiles.getattachments = storeTaskList[indexPath.row].attachfiles
            print(AttachFiles.getattachments)
            AttachFiles.baseImagePath = self.imagePath
            print(AttachFiles.baseImagePath! as Any)
            emp.imagePath = self.imagePath
            print(emp.imagePath)
            emp.action = cell.assignToBtn.titleLabel!.text!
        
        
        if storeTaskList[indexPath.row].firstuser.isEmpty == true{
            emp.assign = "-"
            
        }else{
            
            emp.assign = storeTaskList[indexPath.row].firstuser[0].name!
        }
        }
        navigationController?.pushViewController(emp, animated: true)
        
    }

    
    
    
    @objc func downArrowTapped(_ sender: UIButton) {
        page = false

        if self.selectedIndex != sender.tag {
            self.selectedIndex = sender.tag
        }else{
            self.selectedIndex = -1
        }
        self.table.reloadData()
    }
    
    @objc func AssignToAction(_ sender: UIButton){
        
        if self.selectedIndex == sender.tag {
            
            print(UserDefaults.standard.object(forKey: "Role") as! String)
            SingleToneClass.shared.showProgressLoading(title: "Please wait...")
            
        if (UserDefaults.standard.object(forKey: "Role") as! String == "Department Manager") || (UserDefaults.standard.object(forKey: "Role") as? String == "SubDepartmentManager") {
                
                
            if DetailsStore.submittedTickets == true {
                    
                   
            if storeTaskList[sender.tag].c_status == 2 {
                        
                SingleToneClass.shared.showProgressLoading(title: "Please wait...")
                let ticketId = storeTaskList[sender.tag].id
                        
                let params = ["ticket_id":"\(String(describing: ticketId!))","status":"3","user_id":"\(userid)","login_department_id":"\(depid)"]
                        
                        
                print(params)
                        
                Service.shared.POSTService(serviceType: API.updateTicketStatus, parameters: params ) { (response) -> (Void) in
                            
                print(response)
                            
                guard let responseDetails = response .dictionary else{return}
                            
                            
                         
                if let message = responseDetails["message"]?.string {
                                
                                
                if responseDetails["status"] == 200 {
                                    
                
                    SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                    
                        self.viewWillAppear(true)
                        
                    }
                                    
                                    
                            
                }else if responseDetails["status"] == 419 {
                                    
                                    
                    SingleToneClass.shared.dismissProgressLoading()
                                    
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                     
                        exit(0)
                        
                    }
                                    
                              
                }else{
                                    
                
                    SingleToneClass.shared.dismissProgressLoading()
                                    
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                        
                        
                        }
                                    
                          
                    }
                        
                }else{
                                
                                
                    SingleToneClass.shared.dismissProgressLoading()
                                
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                                    
                            
                        }
                        
                    }
                      
                }
                
            }
                
            
        }else{
                   
                    
            if storeTaskList[sender.tag].c_status == 3 || storeTaskList[sender.tag].c_status == 0 {
                        
                        
                SingleToneClass.shared.showProgressLoading(title: "Please wait...")
                
                let ticketId = storeTaskList[sender.tag].id
                        
                
                let params = ["ticket_id":"\(String(describing: ticketId!))","status":"2","user_id":"\(userid)","login_department_id":"\(depid)"]
                        
                        
                
                print(params)
                        
                Service.shared.POSTService(serviceType: API.updateTicketStatus, parameters: params ) { (response) -> (Void) in
                            
                
                    print(response)
                            
                guard let responseDetails = response .dictionary else{return}
                            
                            
                        
                if let message = responseDetails["message"]?.string {
                                
                                
                
                if responseDetails["status"] == 200 {
                                    
                                    
                SingleToneClass.shared.dismissProgressLoading()
                                    
                    
            
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        
                        self.viewWillAppear(true)
                        
                    }
                                    
                                    
                             
                }else if responseDetails["status"] == 419 {
                                    
                                    
                    SingleToneClass.shared.dismissProgressLoading()
                                    
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                   
                        exit(0)
                                   
                    }
                                    
                            
                }else{
                                    
                                 
                    SingleToneClass.shared.dismissProgressLoading()
                                    
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                        
                                  
                        }
                                    
                              
                    }
                    
                }else{
                                
                    SingleToneClass.shared.dismissProgressLoading()
                                
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                                    
                   
                        }
                        
                    }
                    
                }
                   
            }else{
                        
                        
                let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EmployeeDetailsViewController") as! EmployeeDetailsViewController
                     
                self.addChild(POPUPVC)
                
                POPUPVC.ticketId = storeTaskList[sender.tag].id ?? 0
                POPUPVC.assignToId =  storeTaskList[sender.tag].assignTo[0].id ?? 0
                POPUPVC.assignFromId = storeTaskList[sender.tag].assingFrom[0].id ?? 0
                POPUPVC.status = storeTaskList[sender.tag].c_status ?? 0
                POPUPVC.complaint = complaintAssign
                POPUPVC.view.frame = self.view1.frame
                self.view.addSubview(POPUPVC.view)
                POPUPVC.didMove(toParent: self)
                        
                  
                }
                    
            }
                
                
        }else{
                
    
             let ticketId = storeTaskList[sender.tag].id
                
        
                print(storeTaskList[sender.tag].c_status as Any)
                
                if storeTaskList[sender.tag].c_status == 2 {
                        
                    self.changeStatus = "3"
                    
                }else if storeTaskList[sender.tag].c_status == 3 || storeTaskList[sender.tag].c_status == 0 || storeTaskList[sender.tag].c_status == 1{
                    
                    self.changeStatus = "2"
                }
                
                
                
                
                if DetailsStore.allTickets == true {
                    
                    
                if storeTaskList[sender.tag].c_status == 0 {
                        
                    let assign = storeTaskList[sender.tag].assingFrom[0].id
                    
                    print(assign as Any)
                        
                    let params = ["ticket_id":"\(String(describing: ticketId!))","assign_from":"\(String(describing: assign!))","assign_to":"\(String(describing: assign!))","emp_id":"\(userid)","login_department_id":"\(depid)","user_id":"\(userid)","is_reopen":"0"]
                        
                    print(params)
                        
                    
                    Service.shared.POSTService(serviceType: API.assignTicket, parameters: params ) { (response) -> (Void) in
                            
                    print(response)
            
                            
                    guard let responseDetails = response .dictionary else{return}
                            
                if let message = responseDetails["success"]?.string {
                                
                
                    if responseDetails["status"] == "200" {
                                    
                        SingleToneClass.shared.dismissProgressLoading()
                                    
                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                      
                                self.viewWillAppear(true)
                                    
                            }
                                    
                             
                    }else if responseDetails["status"] == 419 {
                                    
                                    
                        SingleToneClass.shared.dismissProgressLoading()
                                    
                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                     
                                exit(0)
                                  
                            }
                                    
                               
                    }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                        
                            self.view.removeFromSuperview()
                        }
                    }
                          
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                                    
                            
                        }
                            
                    }
                            
                }
                        
            }else{
                        
                        
                        
                let params = ["ticket_id":"\(String(describing: ticketId!))","status":changeStatus,"user_id":"\(userid)","login_department_id":"\(depid)"]
                        
                        
                print(params)
                        
                Service.shared.POSTService(serviceType: API.updateTicketStatus, parameters: params ) { (response) -> (Void) in
                            
                print(response)
                            
                guard let responseDetails = response .dictionary else{return}
                            
                            
                if let message = responseDetails["message"]?.string {
                                
                                
                if responseDetails["status"] == 200 {
                                    
                                    
                    SingleToneClass.shared.dismissProgressLoading()
                                    
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                       
                            self.viewWillAppear(true)
                                      
                                    
                        }
                                    
                                    
                              
                }else if responseDetails["status"] == 419 {
                                    
                                    
                    SingleToneClass.shared.dismissProgressLoading()
                                    
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                       
                            exit(0)
                                  
                        }
                                    
                              
                }else{
                                    
                                   
                    SingleToneClass.shared.dismissProgressLoading()
                                    
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                        
                        
                        }
                                    
                                
                    }
                           
                }else{
                                
                                
                    SingleToneClass.shared.dismissProgressLoading()
                                
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                                    
                               
                        }
                           
                    }
                      
                }
                    
            }
                    
        }else{
                    
                    
            let params = ["ticket_id":"\(String(describing: ticketId!))","status":changeStatus,"user_id":"\(userid)","login_department_id":"\(depid)"]
                    
                    
                print(params)
                    
                  
            Service.shared.POSTService(serviceType: API.updateTicketStatus, parameters: params ) { (response) -> (Void) in
                        
            print(response)
                        
            guard let responseDetails = response .dictionary else{return}
                        
                        
            if let message = responseDetails["message"]?.string {
                            
                            
                if responseDetails["status"] == 200 {
                                
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                 
                            self.viewWillAppear(true)
                                 
                               
                        }
                                
                                
                         
                }else if responseDetails["status"] == 419 {
                                
                                
                    SingleToneClass.shared.dismissProgressLoading()
                                
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                  
                            exit(0)
                              
                        }
                                
                          
                }else{
                                
                                
                    SingleToneClass.shared.dismissProgressLoading()
                                
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                    
                                
                        }
                                
                    }
                
                }else{
                            
                    SingleToneClass.shared.dismissProgressLoading()
                            
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                                
                           
                   
                }
            }
                   
            }
                
         }
             
        }
      }
    }
        
        
    func heightForView(text:String, font:UIFont, width:CGFloat) -> CGFloat {
        let label:UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: CGFloat.greatestFiniteMagnitude))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        return label.frame.height
        
    }


    

}

















//
//  TDViewController.swift
//  Adama
//
//  Created by MAD-MAC on 18/11/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import Kingfisher
import Photos
import AssetsLibrary
import MessageUI
import MobileCoreServices
import Alamofire

class TDViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate,MFMailComposeViewControllerDelegate,UIDocumentPickerDelegate,URLSessionDownloadDelegate,UIDocumentInteractionControllerDelegate {
    
    
    var urlLink: URL!
    var defaultSession: URLSession!
    var downloadTask: URLSessionDownloadTask!
    var getcollection:UICollectionView?

    

    
    func showFileWithPath(path: String){
        let isFileFound:Bool? = FileManager.default.fileExists(atPath: path)
        if isFileFound == true{
            let viewer = UIDocumentInteractionController(url: URL(fileURLWithPath: path))
            viewer.delegate = self
            viewer.presentPreview(animated: true)
        }
        
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        
        print(downloadTask)
        print("File download succesfully")
        
        let path = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
        let documentDirectoryPath:String = path[0]
        let fileManager = FileManager()
        let destinationURLForFile = URL(fileURLWithPath: documentDirectoryPath.appendingFormat("/file.pdf"))
        
        if fileManager.fileExists(atPath: destinationURLForFile.path){
            showFileWithPath(path: destinationURLForFile.path)
            print(destinationURLForFile.path)
        }
        else{
            do {
                try fileManager.moveItem(at: location, to: destinationURLForFile)
                // show file
                showFileWithPath(path: destinationURLForFile.path)
            }catch{
                print("An error occurred while moving file to destination url")
            }
        }
        
        
        
    }

    
    
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        //progress.setProgress(Float(totalBytesWritten)/Float(totalBytesExpectedToWrite), animated: true)
    }
    
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        downloadTask = nil
       // progress.setProgress(0.0, animated: true)
        if (error != nil) {
            print("didCompleteWithError \(error?.localizedDescription ?? "no value")")
            SingleToneClass.shared.dismissProgressLoadingWithError(message: error?.localizedDescription ?? "no value")
        }
        else {
            print("The task finished successfully")
            SingleToneClass.shared.dismissProgressLoading()
        }
    }
    
    func documentInteractionControllerViewControllerForPreview(_ controller: UIDocumentInteractionController) -> UIViewController
    {
        return self
    }
    
    
    
    
    
   
    @IBOutlet weak var chatHistoryBtn: UIButton!
    
    @IBOutlet weak var view6: UIView!
    @IBOutlet var superView: UIView!
    
    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var view5: UIView!
    
   
    @IBOutlet weak var ticketIdLbl: UILabel!
    
    @IBOutlet weak var descriptionLbl: UILabel!
    @IBOutlet weak var mainViewHeight: NSLayoutConstraint!
    @IBOutlet weak var attachfileLbl: UILabel!
    @IBOutlet weak var view4: UIView!
    @IBOutlet weak var view2: UIView!

    @IBOutlet weak var collection: UICollectionView!
    
    @IBOutlet weak var view6Height: NSLayoutConstraint!
    @IBOutlet weak var collectionView2: UICollectionView!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var assignTo: UILabel!
    @IBOutlet weak var mobileNoBtn: UIButton!
    @IBOutlet weak var emailIdBtn: UIButton!
    @IBOutlet weak var issueSubCategoryLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var priorityLbl: UILabel!
    @IBOutlet weak var actionBtn: UIButton!
   
    @IBOutlet weak var fileNumberLbl: UILabel!
    
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view3: UIView!
    
    @IBOutlet weak var resolutionStactView: UIStackView!
    @IBOutlet weak var uploadBtn: UIButton!
    @IBOutlet weak var collectionViewHeight: NSLayoutConstraint!
    @IBOutlet weak var actionLbl: UILabel!
    
    @IBOutlet weak var attachmentCollectionView: UICollectionView!
    
  
    
    
    @IBOutlet weak var productNameLbl: UILabel!
    @IBOutlet weak var packSizeLbl: UILabel!
    @IBOutlet weak var wareHouseLbl: UILabel!
    @IBOutlet weak var batchNoLbl: UILabel!
    @IBOutlet weak var natureOfComplaintLbl: UILabel!
    @IBOutlet weak var quantityAffectedLbl: UILabel!
    @IBOutlet weak var dealerNameLbl: UILabel!
    @IBOutlet weak var dealerCodeLbl: UILabel!
    @IBOutlet weak var mobileNoLbl: UILabel!
    @IBOutlet weak var submittedDateLbl: UILabel!
    @IBOutlet weak var currentStatusLbl: UILabel!
    
    
    @IBOutlet weak var closeComplaintBtn: UIButton!
    
    @IBOutlet weak var view7: UIView!
    
    @IBOutlet weak var closeComplaintBtnHeight: NSLayoutConstraint!
    
    
    
    
    var get:TaskList?
    var imagePath = String()
    var action = String()
    var assign = String()
    var cellImage = String()
    var issue = String()
    var date = String()
    var imageArray = [String]()
    var complaintId = Int()
    var status = String()
    
    var images = UIImage ()
    var imageFormatDisplay=[String]()
    var profileIMageData: Data?
    var selectedAssets=[UIImage]()
    var selectedAssetsName=[String]()
    var photoArray = [Data]()
    var mediaFileArray = [AGImageUpdate]()
    var selectedIndex: Int = 0
    
    
    
    
     var productNameData = String()
     var packSizeData = String()
     var wareHouseData = String()
     var batchNoData = String()
     var natureComplaintData = String()
     var quantityAffectedData = String()
     var dealerNameData = String()
     var dealerCodeData = String()
     var mobileNoData = String()
     var DataDetailsData = String()
     var CurrentStatusData = String()
    
    
    var chatList:[chat] = []
    var chatDetails : chat!
   
    let departmentId = UserDefaults.standard.object(forKey: "DepartmentId") as! Int
    let userId = UserDefaults.standard.object(forKey: "UserId") as! Int
    let empId = UserDefaults.standard.object(forKey: "EmployeeId") as! String
    
    
    let g = UIColor(red: 28/255, green: 180/255, blue: 80/255, alpha: 1.0)
         
    let b = UIColor(red: 0/255, green: 27/255, blue: 96/255, alpha: 1.0)
    
    override func viewWillAppear(_ animated: Bool) {
        
        let imgBack = UIImage(named:"Arrow")
      
        navigationController?.navigationBar.backIndicatorImage = imgBack
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
        
        navigationItem.leftItemsSupplementBackButton = true
        navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        
        
        
        self.navigationController?.isNavigationBarHidden = false
        self.navigationItem.title = "Details"
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        
        
       
        
        
        if action.isEmpty == false {
            
            
            self.view5.isHidden = true
            self.view1.isHidden = false
            
            
            let a = get?.assign_date
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let showDate = dateFormatter.date(from: a!)
            dateFormatter.dateFormat = "dd-MM-yyyy"
            let resultString = dateFormatter.string(from: showDate!)
            
            
            
            self.ticketIdLbl.text = "ADT\(get?.id! ?? 0)"
            self.dateLbl.text = resultString
            self.assignTo.text = assign
            self.mobileNoBtn.setTitle(get?.creator_mobile, for: [])
            self.emailIdBtn.setTitle(get?.creator_email, for: [])
            self.issueSubCategoryLbl.text = get?.issueSubCategory[0].Name ?? "-"
            
            self.mobileNoBtn.titleLabel?.numberOfLines = 1
            self.mobileNoBtn.titleLabel?.adjustsFontSizeToFitWidth = true
            
            
            self.emailIdBtn.titleLabel?.numberOfLines = 2
            self.emailIdBtn.titleLabel?.adjustsFontSizeToFitWidth = true
            
            let pStatus = get?.priority
            
            if pStatus == 1{
                self.priorityLbl.text = "Low"
                 self.priorityLbl.backgroundColor = UIColor(red: 237/255, green: 138/255, blue: 25/255, alpha: 1.0)
            }else if pStatus == 3{
                self.priorityLbl.text = "Medium"
               self.priorityLbl.backgroundColor = UIColor(red: 0/255, green: 151/255, blue: 248/255, alpha: 1.0)
            }else{
                self.priorityLbl.text = "High"
                  self.priorityLbl.backgroundColor = UIColor(red: 188/255, green:   0/255, blue: 3/255, alpha: 1.0)
            }
            
                let cStatus = get?.c_status
            
            
            if cStatus == 0 {
                self.statusLbl.text = "Pending"
                   self.statusLbl.textColor = UIColor(red: 190/255, green: 144/255, blue: 4/255, alpha: 1.0)
            }else if cStatus == 1 {
                self.statusLbl.text = "Overdue"
                self.statusLbl.textColor = UIColor(red: 190/255, green: 0/255, blue: 3/255, alpha: 1.0)
            }else if cStatus == 2 {
                self.statusLbl.text = "Resolved"
                self.statusLbl.textColor = UIColor(red: 28/255, green: 180/255, blue: 80/255, alpha: 1.0)
            }else{
                self.statusLbl.text = "Reopen"
                self.statusLbl.textColor = UIColor(red: 0/255, green: 27/255, blue: 96/255, alpha: 1.0)
            }
            
            self.descriptionLbl.text = get?.description
            
            
            

            if UserDefaults.standard.object(forKey: "Role") as? String == "Department Manager" || UserDefaults.standard.object(forKey: "Role") as! String == "SubDepartmentManager" {

                if DetailsStore.allTickets == true {


                    actionLbl.isHidden = false
                    actionBtn.isHidden = false

                    if statusLbl.text == "Overdue" {
                        self.actionBtn.setTitle("Re Assign To", for: .normal)
                        self.actionBtn.setTitleColor(b, for: [])

                    }else if statusLbl.text == "Resolved"{
                        self.actionBtn.setTitle("Reopen", for: .normal)
                        self.actionBtn.setTitleColor(b, for: [])

                    }else if statusLbl.text == "Reopen"{
                        self.actionBtn.setTitle("Resolved", for: .normal)
                        self.actionBtn.setTitleColor(g, for: [])

                    }else if statusLbl.text == "Pending"{
                        self.actionBtn.setTitle("Assign To", for: .normal)
                        self.actionBtn.setTitleColor(b, for: [])
                    }



                }else if DetailsStore.assignedTickets == true {
                    if  statusLbl.text == "Resolved"{
                        actionLbl.isHidden = true
                        actionBtn.isHidden = true
                    }else {
                        actionLbl.isHidden = false
                        actionBtn.isHidden = false
                        self.actionBtn.setTitle("Resolved", for: .normal)
                        self.actionBtn.setTitleColor(g, for: [])
                    }


                }else if DetailsStore.submittedTickets == true {
                    if  statusLbl.text == "Resolved"{
                        actionLbl.isHidden = false
                        actionBtn.isHidden = false
                        self.actionBtn.setTitle("Reopen", for: .normal)
                        self.actionBtn.setTitleColor(b, for: [])
//                    }else if statusLbl.text == "Pending"{
//                        actionLbl.isHidden = false
//                        actionBtn.isHidden = false
//                        self.actionBtn.setTitle("Assign To", for: .normal)
//                        self.actionBtn.setTitleColor(b, for: [])
                    }else if statusLbl.text == "Overdue"{
                        actionLbl.isHidden = false
                        actionBtn.isHidden = false
                        self.actionBtn.setTitle("Re Assign To", for: .normal)
                        self.actionBtn.setTitleColor(b, for: [])
                    }else{
                        actionLbl.isHidden = true
                        actionBtn.isHidden = true
                    }
                }

            }else{

                if DetailsStore.allTickets == true {
                    actionLbl.isHidden = false
                    actionBtn.isHidden = false

                    if statusLbl.text == "Pending" {
                        self.actionBtn.setTitle("Assign To Me", for: .normal)
                        self.actionBtn.setTitleColor(b, for: [])

                    }else if statusLbl.text == "Resolved"{
                        self.actionBtn.setTitle("Reopen", for: .normal)
                        self.actionBtn.setTitleColor(b, for: [])

                    }else if statusLbl.text == "Overdue" || statusLbl.text == "Reopen"{
                        self.actionBtn.setTitle("Resolved", for: .normal)
                        self.actionBtn.setTitleColor(g, for: [])
                    }
                }else if DetailsStore.assignedTickets == true {

                    if  statusLbl.text == "Resolved"{
                        actionLbl.isHidden = true
                        actionBtn.isHidden = true
                    }else {
                        actionLbl.isHidden = false
                        actionBtn.isHidden = false
                        self.actionBtn.setTitle("Resolved", for: .normal)
                        self.actionBtn.setTitleColor(g, for: [])
                    }

                }else if DetailsStore.submittedTickets == true {

                    if  statusLbl.text == "Resolved"{
                        actionLbl.isHidden = false
                        actionBtn.isHidden = false
                        self.actionBtn.setTitle("Reopen", for: .normal)
                        self.actionBtn.setTitleColor(b, for: [])
                    }else{
                        actionLbl.isHidden = true
                        actionBtn.isHidden = true
                    }

                }


            }

   
        }else{
            
            
            self.view5.isHidden = false
            self.view1.isHidden = true
            
            self.mainView.backgroundColor = UIColor.white
            self.superView.backgroundColor = UIColor.white
            
            
            self.productNameLbl.text = productNameData
            self.packSizeLbl.text = packSizeData
            self.wareHouseLbl.text = wareHouseData
            self.batchNoLbl.text = batchNoData
            self.natureOfComplaintLbl.text = natureComplaintData
            self.quantityAffectedLbl.text = quantityAffectedData
            self.dealerNameLbl.text = dealerNameData
            self.dealerCodeLbl.text = dealerCodeData
            self.mobileNoLbl.text = mobileNoData
            self.submittedDateLbl.text = DataDetailsData
            self.currentStatusLbl.text = CurrentStatusData
            
            
            if CurrentStatusData == "0" {
                self.currentStatusLbl.text = "Pending"
                self.closeComplaintBtn.isHidden = false
                closeComplaintBtnHeight.constant = 40
            }else if CurrentStatusData == "1" {
                self.currentStatusLbl.text = "OverDue"
                self.closeComplaintBtn.isHidden = false
                closeComplaintBtnHeight.constant = 40
            }else if CurrentStatusData == "2" {
                self.currentStatusLbl.text = "Resolved"
                self.closeComplaintBtn.isHidden = false
                closeComplaintBtnHeight.constant = 40
            }else if CurrentStatusData == "3" {
                self.currentStatusLbl.text = "Complaint Close"
                closeComplaintBtn.isHidden = true
                closeComplaintBtnHeight.constant = 0
            }
  
        }
        

        
        if get?.attachfiles.isEmpty == false   {
          
            view2.isHidden = false

        }else{
            print(get?.attachfiles as Any)
            if imageArray.isEmpty == true || imageArray == ["-"] {
                view2.isHidden = true
      
            }else{
                
                view2.isHidden = false

            }
        }
        
        
        if get?.knowledgeBaseFiles.isEmpty == true {
          
            view6.isHidden = true
      
        }else{
            
            view6.isHidden = false
            
        }
        
        
        
        if  DetailsStore.resolution! == true {
            view4.isHidden = true
            view6.isHidden = true

            
        }else{
            view4.isHidden = false
            self.view4.backgroundColor = UIColor(red: 235/255, green: 231/255, blue: 230/255, alpha: 1.0)

        }
        

        
        if view1.isHidden == false && view2.isHidden == false && view6.isHidden == false && view3.isHidden == false && view4.isHidden == false {
            mainViewHeight.constant = 950
        }else if view2.isHidden == false && view2.isHidden == false && view6.isHidden == false && view3.isHidden == false && view4.isHidden == false {
            mainViewHeight.constant = 1035
        }else if view1.isHidden == false &&   view6.isHidden == false && view3.isHidden == false && view4.isHidden == false {
            mainViewHeight.constant = 783
        }else if view1.isHidden == false && view2.isHidden == false &&  view3.isHidden == false && view4.isHidden == false {
            mainViewHeight.constant = 783
        }else if view1.isHidden == false && view3.isHidden == false && view4.isHidden == false {
            mainViewHeight.constant = 640
        }else if view5.isHidden == false && view2.isHidden == false &&  view6.isHidden == false && view3.isHidden == false {
            mainViewHeight.constant = 737
        }else if view5.isHidden == false && view6.isHidden == false && view3.isHidden == false {
            mainViewHeight.constant = 542
        }else if view5.isHidden == false && view2.isHidden == false && view3.isHidden == false {
            mainViewHeight.constant = 542
        }else if view5.isHidden == false && view3.isHidden == false {
            mainViewHeight.constant = 417
        }
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
     
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
        
        
        let backgroundSessionConfiguration = URLSessionConfiguration.background(withIdentifier: "backgroundSession")
        defaultSession = Foundation.URLSession(configuration: backgroundSessionConfiguration, delegate: self, delegateQueue: OperationQueue.main)
     
 
        
        self.view1.layer.cornerRadius = 20
        self.view2.layer.cornerRadius = 20
        self.view3.layer.cornerRadius = 10
        self.view4.layer.cornerRadius = 20
        self.view5.layer.cornerRadius = 20
        self.view6.layer.cornerRadius = 20
        self.view7.layer.cornerRadius = 10
        self.uploadBtn.layer.cornerRadius = 10
        self.chatHistoryBtn.layer.cornerRadius = 10
        self.closeComplaintBtn.layer.cornerRadius = 10
        self.attachfileLbl.layer.cornerRadius = 10
        self.resolutionStactView.layer.cornerRadius = 10
        
        
        self.view1.layer.masksToBounds = false
        self.view1.layer.shadowColor = UIColor.black.cgColor
        self.view1.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        self.view1.layer.shadowOpacity = 0.5
        
        self.view2.layer.masksToBounds = false
        self.view2.layer.shadowColor = UIColor.black.cgColor
        self.view2.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        self.view2.layer.shadowOpacity = 0.5
      
        
        self.view3.layer.masksToBounds = false
        self.view3.layer.shadowColor = UIColor.black.cgColor
        self.view3.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        self.view3.layer.shadowOpacity = 0.5
        

        
     
        self.view5.layer.masksToBounds = false
        self.view5.layer.shadowColor = UIColor.black.cgColor
        self.view5.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        self.view5.layer.shadowOpacity = 0.5
        
        
        self.view6.layer.masksToBounds = false
        self.view6.layer.shadowColor = UIColor.black.cgColor
        self.view6.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        self.view6.layer.shadowOpacity = 0.5
        
        
        let all = NotificationCenter.default
        all.addObserver(self, selector: #selector(userAll), name: NSNotification.Name("Details"), object: nil)

        // Do any additional setup after loading the view.
    }
    
    
    
    @objc func userAll(){
        
       get?.c_status = 3
       self.viewWillAppear(true)

    }
    
    
    
    @IBAction func chatHistory(_ sender: Any) {
        
        chatHistoryService()
        
    }
    
    @IBAction func closeComplaintBtn(_ sender: Any) {
      
        closeBtnService()
    
    }
    

    
    @IBAction func mobileBtn(_ sender: Any) {
        let callPhone = get?.creator_mobile
        print(callPhone!)
        
        
        if let url = URL(string: "telprompt://\(String(describing: callPhone!))") {
            
            if #available(iOS 10, *) {
                
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                
            } else {
                
                UIApplication.shared.openURL(url as URL)
                
            }
            
        }
        
        
    }
    
    @IBAction func emailBtn(_ sender: Any) {
        
        
        
        let email = get?.creator_email
        print(email!)
        
        
        guard MFMailComposeViewController.canSendMail() else{
            return
        }
        
        let composer = MFMailComposeViewController()
        composer.mailComposeDelegate = self
        composer.setToRecipients([email!])
        composer.setSubject("Help!")
        composer.setMessageBody("", isHTML: false)
        
        present(composer, animated: true)
        
        
        
    }
    
    
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        
        
        if error != nil {
            controller.dismiss(animated: true)
        }
        
        switch result {
        case.cancelled :
            print("Cancelled")
        case .saved:
             print("saved")
        case .sent:
             print("sent")
        case .failed:
           print("failed")
        @unknown default:
             print("default")
        }
        controller.dismiss(animated: true)
        
    }
    
    
    @IBAction func actionBtn(_ sender: Any) {
        

        if (UserDefaults.standard.object(forKey: "Role") as! String == "Department Manager") || (UserDefaults.standard.object(forKey: "Role") as? String == "SubDepartmentManager") {
            
            if DetailsStore.allTickets == true {
               
                 if  actionBtn.titleLabel!.text! == "Assign To" || actionBtn.titleLabel!.text! == "Re Assign To" {
                         
                    assignToBtn()
                     
                 }else if actionBtn.titleLabel!.text! == "Resolved" {
                        
                    print(get?.c_status as Any)
                    status = "2"
                    assignToMe()
                     
                 }else if actionBtn.titleLabel!.text! == "Reopen" {
                           
                    assignToBtn()
                          
                }
                
            }else if DetailsStore.assignedTickets == true {
              
                if actionBtn.titleLabel!.text! == "Resolved" {
                        
                    print(get?.c_status as Any)
                    status = "2"
                    assignToMe()
                    
                }
                
            }else if DetailsStore.submittedTickets == true {
                
                if actionBtn.titleLabel!.text! == "Resolved" {
                
                    print(get?.c_status as Any)
                    status = "2"
                    assignToMe()
                    
                }else if actionBtn.titleLabel!.text! == "Reopen" {
                           
                    assignToBtn()
                          
                      
                }
            }
            
        }else{
            
            if DetailsStore.allTickets == true {
                
                if actionBtn.titleLabel!.text! == "Assign To Me"{
                    
                    Assigntome()
                }
                           
            }else if DetailsStore.assignedTickets == true {
                
                if actionBtn.titleLabel!.text! == "Resolved" {
                print(get?.c_status as Any)
                status = "2"
                assignToMe()
               
                }
                
            }else if DetailsStore.submittedTickets == true {
                  
                if actionBtn.titleLabel!.text! == "Resolved" {
               
                    print(get?.c_status as Any)
                    status = "2"
                    assignToMe()
                    
                }else if actionBtn.titleLabel!.text! == "Reopen" {
               
                    print(get?.c_status as Any)
                    status = "3"
                    assignToMe()
                }
            }
                       
        }
        
    }
    
    
    func Assigntome () {
        
        
        let params = ["ticket_id":"\(String(describing: (get?.id)!))","assign_from":"\(get?.assingFrom[0].id ?? 0)","assign_to":"\(get?.assignTo[0].id ?? 0)","emp_id":"\(userId)","login_department_id":"\(departmentId)","user_id":"\(userId)","is_reopen":"0"]
                              
        print(params)
                              
                          
        Service.shared.POSTService(serviceType: API.assignTicket, parameters: params ) { (response) -> (Void) in
                                  
        print(response)
                  
                                  
        guard let responseDetails = response .dictionary else{return}
                                  
        if let message = responseDetails["success"]?.string {
                                      
                      
            if responseDetails["status"] == "200" {
               
                self.actionBtn.setTitle("Resolved", for: .normal)
                self.actionBtn.setTitleColor(self.g, for: [])
            
                SingleToneClass.shared.dismissProgressLoading()
                                          
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                            
                  
                                          
                }
                                          
                                   
        }else if responseDetails["status"] == 419 {
                                          
                SingleToneClass.shared.dismissProgressLoading()
                                          
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                           
                    exit(0)
                                        
                }
                                          
                                     
        }else{
            
                SingleToneClass.shared.dismissProgressLoading()
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                                              
                   
                    
                }
                
            }
                                
            
        }else{
                          
            SingleToneClass.shared.dismissProgressLoading()
                          
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                                          
                                  
            
            }
                                  
            
            }
            
            
        }
    }
    
    
    func assignToBtn () {
        
        SingleToneClass.shared.showProgressLoading(title: "Please wait...")
        let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EmployeeDetailsViewController") as! EmployeeDetailsViewController
        self.addChild(POPUPVC)
        DetailsStore.ticketdetails = true
        POPUPVC.ticketId = get?.id! ?? 0
       
        POPUPVC.assignToId = get?.assignTo[0].id ?? 0
        POPUPVC.assignFromId = get?.assingFrom[0].id ?? 0
        POPUPVC.status = get?.c_status ?? 0
        POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
        self.view.addSubview(POPUPVC.view)
        POPUPVC.didMove(toParent: self)
        
    }
    
    func assignToMe () {
        

        let params = ["ticket_id":"\(String(describing: (get?.id)!))","status":status,"user_id":"\(userId)","login_department_id":"\(departmentId)"]
        
        
        print(params)
        
        Service.shared.POSTService(serviceType: API.updateTicketStatus, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
            guard let responseDetails = response .dictionary else{return}
            
            
            if let message = responseDetails["message"]?.string {
                
                
                if responseDetails["status"] == 200 {
                    
                    
                    let data = responseDetails["data"]?.dictionary
                    
                    let sts = data?["c_status"]?.string
                    print(sts as Any)
                    self.get?.c_status = Int(sts ?? "0")
                    print(self.get?.c_status as Any)
                    
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {

                        self.viewWillAppear(true)
                        
                    }
                    
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        
                    }
                    
                }
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
            }
        }

        
    }
    
    
    
    
    @IBAction func commentsBtn(_ sender: Any) {
  
        let emp = storyboard?.instantiateViewController(withIdentifier: "ChattingViewController") as! ChattingViewController
        if let id = get?.id{
            emp.ticketId = "\(id)"
            print(emp.ticketId)
        }else{
        
            emp.complaintId = "\(complaintId)"
        
        }
        navigationController?.pushViewController(emp, animated: true)
        
        
    }

    @IBAction func uploadBtn(_ sender: Any) {
        
  
        
        var params:[String:Any] = ["ticket_id":get?.id! ?? 0 ,"uploaded_by":departmentId,"department_id":get?.assingFrom[0].id ?? 0,"user_id":userId,"login_department_id":departmentId]
        
        print(params)
        
        
        params["note_file[]"] = mediaFileArray
        
        print(params)
        
        Service.shared.makeUploadRequest1(serviceType: API.addResolutionNote, parameters: params) { response in
            
          
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                
                if responseDetails["status"] == 200 {
                    
                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
                    SingleToneClass.shared.dismissProgressLoading(WithDelay: 0.50)
                    
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
        }
        
    }
    
    
    func chatHistoryService ()  {
        
        let params = ["ticket_id": "\(String(describing: get?.id! ?? 0))","login_department_id":"\(departmentId)","user_id":"\(userId)"]
        
        print(params)
        
        Service.shared.POSTService(serviceType: API.chatHistory, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
                if responseDetails["status"] == 200 {
                    
                 
                    let data = responseDetails["data"]?.array
                    
                    self.chatDetails = chat()
                    
                    for i in data! {
                        
                     self.chatDetails.ticketId = i["ticket_id"].string
                     self.chatDetails.name = i["name"].string
                     self.chatDetails.comments = i["comment"].string
                        
                        self.chatList.append(self.chatDetails)
                         self.creatCSV()
                    }
                    
                    
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
            
        }
    }
    
    
    func creatCSV() -> Void {
        
        let fileName = getDocumentsDirectory().appendingPathComponent("ADT\(get?.id! ?? 0).csv")
        
        var csvText = "TicketId,Name,Comment\n"
        
        for chatDetails in chatList {
            let newLine = "\(String(describing: chatDetails.ticketId!)),\(String(describing: chatDetails.name!)),\(String(describing: chatDetails.comments!))\n"
            csvText.append(newLine)
        }
        
        do {
            try csvText.write(to: fileName, atomically: true, encoding: String.Encoding.utf8)
        } catch {
            print("Failed to create file")
            print("\(error)")
        }
        print(fileName)
        SingleToneClass.shared.dismissProgressLoading()
        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "File Saved In \(fileName)") { }
    }
    
    
    
    private func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    
    
    func closeBtnService () {

        let params = ["complaint_id":"\(String(describing: complaintId))","status":"\(String(describing: 3))","login_department_id":"\(departmentId)","user_id":"\(userId)","emp_id":empId]

        print(params)

        Service.shared.POSTService(serviceType: API.assignComplaint, parameters: params ) { (response) -> (Void) in

            print(response)

            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}

            if let message = responseDetails["success"]?.string {



                if responseDetails["status"] == "200" {

                    
                    self.closeComplaintBtn.isHidden = true
                    self.currentStatusLbl.text = "Complaint Close"
                    self.closeComplaintBtnHeight.constant = 0
                    
                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
                    SingleToneClass.shared.dismissProgressLoading(WithDelay: 0.50)



                }else if responseDetails["status"] == 419 {

                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }

                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }


            }else{

                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {

                }

            }


        }
    }
    
    
    
    
    @IBAction func attachFileBtn(_ sender: Any) {
        
        
        
        
        let alertController = UIAlertController(title: "Choose Attach File", message: "", preferredStyle: .actionSheet)
        
        
        let cameraButton = UIAlertAction(title: "Camera", style: .default, handler: { (action) -> Void in
            
            let picker = UIImagePickerController()
            picker.delegate = self
            
            picker.sourceType = .camera
            self.present(picker, animated: true, completion: nil)
            
        })
        
        let imageButton = UIAlertAction(title: "Gallery", style: .default, handler: { (action) -> Void in
            
            let picker = UIImagePickerController()
            picker.delegate = self
            
            picker.sourceType = UIImagePickerController.SourceType.photoLibrary
            self.present(picker, animated: true, completion: nil)
            
            
            
        })
        
        let videoButton = UIAlertAction(title: "Video Library", style: .default, handler: { (action) -> Void in
            
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.mediaTypes = [kUTTypeMovie as String, kUTTypeVideo as String]
            
            self.present(picker, animated: true, completion: nil)
            
            
            
        })
        
        
        let  documentButton = UIAlertAction(title: "Document", style: .default, handler: { (action) -> Void in
            
            let documentPicker = UIDocumentPickerViewController(documentTypes: ["public.text", "com.apple.iwork.pages.pages", "public.data"], in: .import)
            
            documentPicker.delegate = self
            self.present(documentPicker, animated: true, completion: nil)
            
        })
        
        
        let cancelButton = UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) -> Void in
            
        })
        
        alertController.addAction(cameraButton)
        alertController.addAction(imageButton)
        alertController.addAction(videoButton)
        alertController.addAction(documentButton)
        alertController.addAction(cancelButton)
        
        self.present(alertController, animated: true, completion: nil)
        
        

        
    }
    

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {

         
        
          self.attachmentCollectionView.isHidden = false
          self.attachfileLbl.isHidden = false
          self.attachmentCollectionView.reloadData()

           
           
           do{
               
               self.images = UIImage(named:"50")!
               self.imageFormatDisplay.append(url.pathExtension)
               self.selectedAssets.append(images)
               
               
               let filePath = url //URL of the PDF
               let fileExtension = filePath.pathExtension
               let name  = "file." + fileExtension
               let fileData = try Data.init(contentsOf: filePath)
               let media =  AGImageUpdate(fileName: name, type: fileExtension, data: fileData)
               mediaFileArray.append(media)
           
          
           }
           catch{

               print(error)
           }
           


       }
       
       
      
    //   fileprivate var currentVC: UIViewController?
       //MARK: - Internal Properties
       var imagePickedBlock: ((UIImage) -> Void)?
       var videoPickedBlock: ((NSURL) -> Void)?
       var filePickedBlock: ((URL) -> Void)?
       
       
       func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
           
           picker.dismiss(animated: true, completion: nil)
       
           if DetailsStore.camera == false {
           
           
           //  To handle image
           if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
              
            self.imagePickedBlock?(image)
            self.images = image
            self.imageFormatDisplay.append("")
              

            let imgUrl = info[UIImagePickerController.InfoKey.imageURL] as? URL
              
            if let imageData = images.jpegData(compressionQuality: 0.8) {
                        print(imageData)
            
                let fileExtension = imgUrl?.pathExtension
                      
                let name  = "file." + (fileExtension ?? "jpg")
                       print(name)
                let media =  AGImageUpdate(fileName: name, type: fileExtension ?? "jpg", data: imageData)
                print(media)
                mediaFileArray.append(media)
                   }
                   
           } else{
            
               print("Something went wrong in  image")

           }
               
            

               
           // To handle video
           if let videoUrl = info[UIImagePickerController.InfoKey.mediaURL] as? NSURL  {
               print("videourl: ", videoUrl)
               
             
                 let fileExtension = videoUrl.pathExtension
                 self.images = UIImage(named:"50")!
                 self.imageFormatDisplay.append(fileExtension!)
               
               
               //trying compression of video
                 let data = NSData(contentsOf: videoUrl as URL)!
                 let name  = "file." + (fileExtension ?? "MOV")
                 let media =  AGImageUpdate(fileName: name, type: fileExtension ?? "MOV", data: data as Data )
                         
                 mediaFileArray.append(media)
      
           }else{
             
               print("Something went wrong in  video")
               
           }
           
           
               self.selectedAssets.append(images)
              
           
            DispatchQueue.main.async {
               
                self.attachmentCollectionView.isHidden = false
                self.fileNumberLbl.isHidden = false
                self.attachmentCollectionView.reloadData()
               
            }
       
               
           }else{
               
               if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
                   
                self.imagePickedBlock?(image)
                self.images = image
                print(imagePath)
                self.imageFormatDisplay.append("")
                   

            let imgUrl = info[UIImagePickerController.InfoKey.imageURL] as? URL
                  
                if let imageData = images.jpegData(compressionQuality: 0.8) {
                           print(imageData)
                let fileExtension = imgUrl?.pathExtension
                let name  = "file." + (fileExtension ?? "jpg")
                print(name)
                let media =  AGImageUpdate(fileName: name, type: fileExtension ?? "jpg", data: imageData)
                print(media)
                                             
                mediaFileArray.append(media)
                      
                   }
                       
               } else{
                
                print("Something went wrong in  image")

               }
                   
               
               self.selectedAssets.append(images)
              
               
                DispatchQueue.main.async {
                    self.attachmentCollectionView.isHidden = false
                    self.fileNumberLbl.isHidden = false
                    self.attachmentCollectionView.reloadData()
           
                }
               
           }
           
       }
       
 
    
    @objc func deleteArrowTapped(_ sender: UIButton) {
        
        if self.selectedIndex == sender.tag {
            self.selectedIndex = sender.tag
            selectedAssets.remove(at: sender.tag)
            mediaFileArray.remove(at: sender.tag)
            imageFormatDisplay.remove(at: sender.tag)
            print(photoArray)
        }else{
            self.selectedIndex = 0
            //  let row=IndexPath.row
            selectedAssets.remove(at: sender.tag)
            mediaFileArray.remove(at: sender.tag)
              imageFormatDisplay.remove(at: sender.tag)
            
        }
     
    self.attachmentCollectionView.reloadData()
        
        
    }
        
    

    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        

        if collectionView == attachmentCollectionView{
         
            if mediaFileArray.count == 0 {
            self.attachmentCollectionView.isHidden = true
            self.fileNumberLbl.text = "0 Files Selected"
            }
            return mediaFileArray.count
            
        }else if collectionView == collection {
            if DetailsStore.submittedComplaint == true || DetailsStore.assignedComplaint == true ||   DetailsStore.customerComplaint == true {
                    return imageArray.count
            }else {
                print(get?.attachfiles as Any)
                    return (get?.attachfiles.count)!
            }
        }else{
            if let file = get?.knowledgeBaseFiles {
                print(file)
                return file.count
            }else{
                return 0
            }
        }

    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView == attachmentCollectionView {
         
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! TDAttachmentFilesCollectionViewCell
               
                   
            cell.imageDisplay.image = selectedAssets[indexPath.row]
            self.view4.backgroundColor = UIColor.white
            cell.imageDisplayView.layer.cornerRadius = 10
            cell.imageDisplayView.layer.borderWidth = 1
            cell.imageDisplayView.layer.borderColor = UIColor.black.cgColor
            
                DispatchQueue.main.async {
                    self.fileNumberLbl.text = "\(self.selectedAssets.count) Files Selected"
                }
            
            cell.cancelBtn.tag = indexPath.row
            cell.cancelBtn.addTarget(self, action: #selector(self.deleteArrowTapped(_:)), for: .touchUpInside)
 
            return cell
  
            
        }else if collectionView == collection {
        
            getcollection = collectionView
            getcollection?.tag = 1
          
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! TDCollectionViewCell
            
             cell.imageDisplayView.layer.cornerRadius = 10
             cell.imageDisplayView.layer.borderWidth = 1
             cell.imageDisplayView.layer.borderColor = UIColor.black.cgColor
            
            
            
                if DetailsStore.submittedComplaint == true || DetailsStore.assignedComplaint == true ||   DetailsStore.customerComplaint == true {
            
          
            
                    cell.nameLbl.text = imageArray[indexPath.row]
                    cell.countLbl.text = "\(indexPath.row + 1)"
                    self.cellImage = UserDefaults.standard.object(forKey: "BaseImagePath") as! String +  imageArray[indexPath.row]
            
                     let imageRes = ImageResource(downloadURL: URL(string: cellImage)!)
                    print(imageRes)
            
                    cell.DisplayImage.kf.setImage(with: imageRes)
            
                    
       
                }else{
            

                
                    cell.nameLbl.text = get?.attachfiles[indexPath.row].file_name
                    cell.countLbl.text = "\(indexPath.row + 1)"
                    print(imagePath)
                    print((get?.attachfiles[indexPath.row].file_name)!)
                    self.cellImage = String((imagePath) +  ((get?.attachfiles[indexPath.row].file_name)!))
                    print(self.cellImage)
                 //  let a = cellImage.lastIndex(of: <#T##Character#>)
                    //          print(a)
                     let imageRes = ImageResource(downloadURL: URL(string: self.cellImage)!)
                     print(imageRes)
                    
                
                    cell.DisplayImage.kf.setImage(with: ImageResource(downloadURL: URL(string: self.cellImage)!))
                    
                  
                }
            
            cell.downloadBtn.tag = indexPath.row
            cell.downloadBtn.addTarget(self, action: #selector(self.downArrowTapped(_:)), for: .touchUpInside)
            
             return cell
            
            
        }else{
               
            getcollection = collectionView
            getcollection?.tag = 2
               
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! TDKnowledgeBaseCollectionViewCell
                
            cell.imagedisplayView.layer.cornerRadius = 10
            cell.imagedisplayView.layer.borderWidth = 1
            cell.imagedisplayView.layer.borderColor = UIColor.black.cgColor
                
            cell.nameLbl.text = get?.knowledgeBaseFiles[indexPath.row].note_file
                cell.countLbl.text = "\(indexPath.row + 1)"
            
            if DetailsStore.submittedTickets == true {
               
                self.cellImage = (get?.knowledgeBaseFiles[indexPath.row].path)! +  (get?.knowledgeBaseFiles[indexPath.row].note_file)!
           
            }else{
               
                self.cellImage = String((imagePath)  +  (get?.knowledgeBaseFiles[indexPath.row].note_file)!)
           
            }
              
            let imageRes = ImageResource(downloadURL: URL(string: cellImage)!)
                print(imageRes)
//            let a = cellImage.last
//            print(a)
               
            cell.displayImage.kf.setImage(with: imageRes)
            
            cell.downloadBtn.tag = indexPath.row
            cell.downloadBtn.addTarget(self, action: #selector(self.downArrowTapped(_:)), for: .touchUpInside)
                
            return cell
            
        }
 
    }
    
    
    @objc func downArrowTapped(_ sender: UIButton) {
      
      
        SingleToneClass.shared.showProgressLoading(title: "File Downloading")

        if getcollection?.tag == 1{
            

              if DetailsStore.submittedComplaint == true || DetailsStore.assignedComplaint == true ||   DetailsStore.customerComplaint == true {
                
            
               cellImage =  UserDefaults.standard.object(forKey: "BaseImagePath") as! String +  imageArray[sender.tag]
                
                
                
              }else{
                
                cellImage =  String((imagePath) +  ((get?.attachfiles[sender.tag].file_name)!))
                
                  
            }
            
        }else if getcollection?.tag == 2{
            
              if DetailsStore.submittedTickets == true {
                self.cellImage = (get?.knowledgeBaseFiles[sender.tag].path)! +  (get?.knowledgeBaseFiles[sender.tag].note_file)!
                      }else{
                self.cellImage = String((imagePath)  +  (get?.knowledgeBaseFiles[sender.tag].note_file)!)
                      }
            
        }
        
    downloadZipFileFromServer(downloadFolderName: "AdamaFiles")
  
    }
    
    
    
    func downloadZipFileFromServer(downloadFolderName: String)
    {
        let destination: DownloadRequest.DownloadFileDestination = { _, _ in
            var fileURL = self.createFolder(folderName: downloadFolderName)
            let fileName = URL(string : self.cellImage)
            fileURL = fileURL.appendingPathComponent((fileName?.lastPathComponent)!)
            return (fileURL, [.removePreviousFile, .createIntermediateDirectories])
        }
        Alamofire.download(cellImage, to: destination).response(completionHandler: { (DefaultDownloadResponse) in
            print("res ",DefaultDownloadResponse.destinationURL!);
            SingleToneClass.shared.dismissProgressLoading()
             SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "File Saved In Iphone/Files/Adama Folder") {  }
        })
    }

    func createFolder(folderName:String)->URL
    {
        let paths: [Any] = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory: String = paths[0] as? String ?? ""
        let dataPath: String = URL(fileURLWithPath: documentsDirectory).appendingPathComponent(folderName).absoluteString
        if !FileManager.default.fileExists(atPath: dataPath) {
            try? FileManager.default.createDirectory(atPath: dataPath, withIntermediateDirectories: false, attributes: nil)
        }
        let fileURL = URL(string: dataPath)
       
        return fileURL!
    }
    
    
    
}






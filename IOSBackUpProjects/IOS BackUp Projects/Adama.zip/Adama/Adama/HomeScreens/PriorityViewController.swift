//
//  PriorityViewController.swift
//  Adama
//
//  Created by MatrixStream_01 on 29/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class PriorityViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.isNavigationBarHidden = true
         self.view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        // Do any additional setup after loading the view.
    }

    
    
    @IBAction func lowBtn(_ sender: Any) {
        

        let low = NotificationCenter.default
        low.post(name: Notification.Name("Low"), object: nil)
        
         self.view.removeFromSuperview()
        
        
        
        
    }
    
    @IBAction func closeBtn(_ sender: Any) {
        
        let low = NotificationCenter.default
        low.post(name: Notification.Name("All"), object: nil)
        
        self.view.removeFromSuperview()
        
    }
    
    @IBAction func allBtn(_ sender: Any) {
        
        let low = NotificationCenter.default
        low.post(name: Notification.Name("All"), object: nil)
        
        self.view.removeFromSuperview()
        
        
        
        
    }
    
    @IBAction func highBtn(_ sender: Any) {
        let high = NotificationCenter.default
        high.post(name: Notification.Name("High"), object: nil)

         self.view.removeFromSuperview()
    }
    
    
    @IBAction func mediumBtn(_ sender: Any) {
        
        let high = NotificationCenter.default
        high.post(name: Notification.Name("Medium"), object: nil)
        
        self.view.removeFromSuperview()
        
        
    }
    
    
    
    
}

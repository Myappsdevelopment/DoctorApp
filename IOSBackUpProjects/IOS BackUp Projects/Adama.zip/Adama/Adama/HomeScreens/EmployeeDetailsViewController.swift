//
//  EmployeeDetailsViewController.swift
//  Adama
//
//  Created by MAD-MAC on 11/09/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class EmployeeDetailsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
  
  
    @IBOutlet weak var table: UITableView!
   
    
    var namesArray:[String] = []
    var id:[Int] = []
    
    var selectedId = Int()
    
    var ticketId = Int()
    var assignToId = Int()
    var assignFromId = Int()
    var status = Int()
    var reOpen = String()
    var complaint = String()
    var complaintAssigned = Int()
    
    let departmentId = UserDefaults.standard.object(forKey: "DepartmentId") as! Int
    let userType = UserDefaults.standard.object(forKey: "UserType") as! Int
    let userId = UserDefaults.standard.object(forKey: "UserId") as! Int
    let subDepartmentId = UserDefaults.standard.object(forKey: "LoginSubDepartmentId") as! Int
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
       
        
        employeeListService()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        
        // Do any additional setup after loading the view.
    }
    
    
    
    func employeeListService()  {
        
        
        if DetailsStore.customerComplaint == true || DetailsStore.submittedComplaint == true || DetailsStore.assignedComplaint == true {
            complaintAssigned = 1
        }else{
   
            if complaint == "-" {
                complaintAssigned = 1
            }else{
                complaintAssigned = 0
            }
        }

        let params = ["department_id":"\(departmentId )","user_type":"\(String(describing: userType))","login_department_id":"\(departmentId)","user_id":"\(userId)","login_subdeppartment":"\(subDepartmentId)","is_complain":"\(String(describing: complaintAssigned))"]
        
        print(params)
        
        Service.shared.POSTService(serviceType: API.employeeList, parameters: params ) { (response) -> (Void) in
        
        print(response)
            
            
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                
              
                
                if responseDetails["status"] == 200 {
                SingleToneClass.shared.dismissProgressLoading()
                    
                    let getData = responseDetails["data"]?.array
                    
                    
                    if getData! == [] {
                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "No Employee List Found") {
                             self.view.removeFromSuperview()
                        }
                        
                    }else{
                        
                       self.table.isHidden = false
                    }
                    
                      for getTask in getData!{
                    
                        let name = getTask["name"].string
                        let Id = getTask["id"].int
                        
                        self.namesArray.append(name!)
                        self.id.append(Id!)
                        print(self.namesArray)
                        
                    }
                    
                    self.table.reloadData()
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
        
        }
    }
    
    
    
    @IBAction func closeBtn(_ sender: Any) {
        
          self.view.removeFromSuperview()
        
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return namesArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! EmployeeNamesTableViewCell
        
        cell.namesLbl.text = namesArray[indexPath.row]
        print(cell.namesLbl.text as Any)
       
        
        
        return cell
    }
    
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      
        self.selectedId = id[indexPath.row]
        print(selectedId as Any)
       
        if  DetailsStore.page == true {
            assigTask()
        }else{
            SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
            if DetailsStore.customerComplaint == true || DetailsStore.submittedComplaint == true || DetailsStore.assignedComplaint == true {
               assignComplaint()
            }else{
                assigTicket()
            }
        }
        
    }
    
    
    func assigTicket()  {
        
        print(status)
        print(assignToId)
        
        if status == 2   {
            reOpen = "1"
        }else{
            reOpen = "0"
        }
        
        
        
        let params = ["ticket_id":"\(String(describing: ticketId))","assign_from":"\(String(describing: assignFromId))","assign_to":"\(String(describing: assignToId))","emp_id":"\(String(describing: selectedId))","login_department_id":"\(departmentId)","user_id":"\(userId)","is_reopen":reOpen]
        
        print(params)
        
        Service.shared.POSTService(serviceType: API.assignTicket, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
            
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["success"]?.string {
                
               
                
                if responseDetails["status"] == "200" {
                    
                    
                    if DetailsStore.ticketdetails == true {
                        
                        let low = NotificationCenter.default
                        low.post(name: Notification.Name("Details"), object: nil)
                        self.view.removeFromSuperview()
                        DetailsStore.ticketdetails = false
                        
                        let data = responseDetails["data"]?.dictionary
                        let Csts = data?["c_status"]?.int
                        print(Csts as Any)
                        
                        
                    }else{
                
                        let low = NotificationCenter.default
                        low.post(name: Notification.Name("Details2"), object: nil)
                        self.view.removeFromSuperview()
                    }
                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
                    SingleToneClass.shared.dismissProgressLoading(WithDelay: 0.50)
                    
                    
//
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        self.view.removeFromSuperview()
                    }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
            
        }
        
        
        
    }
    
    
    func assigTask()  {
        
        let params = ["task_id":"\(String(describing: ticketId))","assign_from":"\(assignFromId)","assign_to":"\(assignToId)","emp_id":"\(selectedId)"]
        
        print(params)
        
        Service.shared.POSTService(serviceType: API.assignTask, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
            
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["success"]?.string {
                
                print(message as Any)
                print(responseDetails as Any)
                print(responseDetails["status"] as Any)
                
                if responseDetails["status"] == "200" {
                    
                   
                    self.view.removeFromSuperview()
                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
                    SingleToneClass.shared.dismissProgressLoading(WithDelay: 0.50)
                    
                    
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        self.view.removeFromSuperview()
                    }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
            
        }
        
        
        
    }
    
  
    
    func assignComplaint()  {
        
        let params = ["complaint_id":"\(String(describing: ticketId))","status":"\(String(describing: 1))","login_department_id":"\(departmentId)","user_id":"\(userId)","emp_id":"\(selectedId)"]
        
        print(params)
        
        Service.shared.POSTService(serviceType: API.assignComplaint, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["success"]?.string {
                
                
                
                if responseDetails["status"] == "200" {
                    
                    let low = NotificationCenter.default
                    low.post(name: Notification.Name("Complaint"), object: nil)
                    self.view.removeFromSuperview()
                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
                    SingleToneClass.shared.dismissProgressLoading(WithDelay: 0.50)

                    
                    
                }else if responseDetails["status"] == 419 {
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) {
                        exit(0)
                    }
                    
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    
                }
                
            }
            
            
        }
    }
    
    
    
    

}

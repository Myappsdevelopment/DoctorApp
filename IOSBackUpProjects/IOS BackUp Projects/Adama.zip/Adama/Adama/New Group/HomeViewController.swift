//
//  HomeViewController.swift
//  Adama
//
//  Created by MAD-MAC on 30/09/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import Charts
import MarqueeLabel


class HomeViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var departmentTF: TextField!
    @IBOutlet weak var sideMenuBarBtn: UIBarButtonItem!
    @IBOutlet weak var pieChart: PieChartView!
    @IBOutlet weak var pendingView: UIView!
    @IBOutlet weak var resolvedView: UIView!
    @IBOutlet weak var highPriorityView: UIView!
    @IBOutlet weak var overdueView: UIView!
    @IBOutlet weak var unAssignedView: UIView!
    @IBOutlet weak var reassignView: UIView!
    
    @IBOutlet weak var scroll: UIScrollView!
    @IBOutlet weak var scrollTextLbl: MarqueeLabel!
    
  
   
    @IBOutlet weak var pendingMyTicketLbl: UILabel!
    @IBOutlet weak var resolveMyTickets: UILabel!
    @IBOutlet weak var highPriorityMyTicketsLbl: UILabel!
    @IBOutlet weak var overdueMyTicktesLbl: UILabel!
    @IBOutlet weak var unassignLbl: UILabel!
    @IBOutlet weak var reAssignLbl: UILabel!
    
  
    @IBOutlet weak var submittedTicketView: UIView!
    
    @IBOutlet weak var submittedPendingLbl: UILabel!
    @IBOutlet weak var submittedResolvedLbl: UILabel!
    @IBOutlet weak var submittedHighPriorityLbl: UILabel!
    @IBOutlet weak var submittedOverdueLbl: UILabel!
    @IBOutlet weak var submittedNewTicketLbl: UILabel!
    @IBOutlet weak var submittedReassignedLbl: UILabel!
    
  
    @IBOutlet weak var pendingAndResolvedStack: UIStackView!
    
    @IBOutlet weak var highPriorityAndOverdueStack: UIStackView!
    
    @IBOutlet weak var newTicketAndReassignStack: UIStackView!
    var pieValues :[Int] = []
    
    var flashMessage = [String]()
   
    var pending = Int()
    var resolve = Int()
    var highPriority = Int()
    var overdue = Int()
    var reAssign = Int()
    var newTicket = Int()
    var unsolved = Int()
    var solved = Int()
    var unAssigned = Int()
    
   
    
    var selectedTF = UITextField()
    
    let blackColour = UIColor(red: 39/255, green: 39/255, blue: 39/255, alpha: 1.0)
    let grayColour = UIColor(red: 192/255, green: 195/255, blue: 203/255, alpha: 1.0)
    let blueColour = UIColor(red: 97/255, green: 132/255, blue: 165/255, alpha: 1.0)
    let whiteColour = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1.0)
    
    
    let departmentId = UserDefaults.standard.object(forKey: "DepartmentId") as! Int
    let userType = UserDefaults.standard.object(forKey: "UserType") as! Int
    let userId = UserDefaults.standard.object(forKey: "UserId") as! Int
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        
      
        
        self.navigationController?.isNavigationBarHidden = false
       
        self.navigationItem.title = "Dashboard"
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.tabBarController?.tabBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white
      
     //  SingleToneClass.shared.showProgressLoading(title: "Please Wait")

    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

  
        let low = NotificationCenter.default
        low.addObserver(self, selector: #selector(prodcutsInfo(_:)), name: Notification.Name("Low4"), object: nil)

        
        pendingView.layer.cornerRadius = 10
        resolvedView.layer.cornerRadius = 10
        highPriorityView.layer.cornerRadius = 10
        overdueView.layer.cornerRadius = 10
        unAssignedView.layer.cornerRadius = 10
        reassignView.layer.cornerRadius = 10
        
        submittedTicketView.layer.borderWidth = 2
        submittedTicketView.layer.borderColor = UIColor.black.cgColor
        
        departmentTF.delegate = self
        
        
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
    
        
        if UserDefaults.standard.object(forKey: "Role") as! String == "Management" {
            departmentTF.isHidden = false
            departmentTF.text = "IT"
            pendingAndResolvedStack.isHidden = true
            highPriorityAndOverdueStack.isHidden = true
            newTicketAndReassignStack.isHidden = true
            dashboardService1()
           // SingleToneClass.shared.showProgressLoading(title: "Please Wait")
            
        }else{
            departmentTF.isHidden = true
            pendingAndResolvedStack.isHidden = false
            highPriorityAndOverdueStack.isHidden = false
            newTicketAndReassignStack.isHidden = false
            
            dashboardService()
           
        }
        
        
        
        
    }
    
    
    
    
    
    @objc func prodcutsInfo(_ notification: NSNotification){
        
        if let dict = notification.userInfo as NSDictionary? {
            
            print(dict)
            if let name = dict["product"] as? String{
                let id = dict["id"] as! Int
                let a = dict["TextfieldTag"] as! Int
                //  var ids = Ids()
                if a == 14 {
                    self.departmentTF.text = name
                    Ids.departmentIds = id
                    print(Ids.departmentIds)
                    dashboardService1()
                }
                
            }
        }
        
    }
    
    @IBAction func bellBtn(_ sender: Any) {
        
        let emp = storyboard?.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
        navigationController?.pushViewController(emp, animated: true)
    }
    
  
    
    
    func setupPieChart() {
        
        
        pieChart.chartDescription?.enabled = false
        pieChart.drawHoleEnabled = false
        pieChart.rotationAngle = 0
        pieChart.rotationEnabled = true
        
      
   
        let pieChartLegend = pieChart.legend
        pieChartLegend.horizontalAlignment = Legend.HorizontalAlignment.right
        pieChartLegend.verticalAlignment = Legend.VerticalAlignment.top
        pieChartLegend.orientation = Legend.Orientation.vertical
//        pieChartLegend.xEntrySpace = 10
//        pieChartLegend.yEntrySpace = 0
//        pieChartLegend.yOffset = 0
   
       // pieChartLegend.drawInside = false
      //  pieChartLegend.yOffset = 10.0
        
        pieChart.legend.enabled = true
        pieChart.drawEntryLabelsEnabled = false
      //  pieChart.usePercentValuesEnabled = true
        self.pieChart.notifyDataSetChanged()
        
        pieChart.setExtraOffsets(left: 0, top: 0, right:20, bottom: 0)
        
        
        
       // pieChart.isUserInteractionEnabled = false
        
        //pieView.legend.enabled = false
    
        let total = pending + resolve + highPriority + overdue + reAssign + newTicket
        print(total)
        
  
        if total == 0 {
            var entries: [PieChartDataEntry] = Array()
            entries.append(PieChartDataEntry(value: 100, label: "100% NoChartAvailable"))
           
            
            let dataSet = PieChartDataSet(entries: entries, label: "TaskList")
            
            let c1 = NSUIColor(hex: 0x999999)
           
            
            dataSet.colors = [c1]
            dataSet.drawValuesEnabled = true
            
            pieChart.data = PieChartData(dataSet: dataSet)
        }else{
        
            
            let a = 100 * pending/total
            let b = 100 * resolve/total
            let c = 100 * highPriority/total
            let d = 100 * overdue/total
            let e = 100 * reAssign/total
            let f = 100 * newTicket/total
            
        var entries: [PieChartDataEntry] = Array()
        entries.append(PieChartDataEntry(value: Double(a), label: "Pending"))
        entries.append(PieChartDataEntry(value: Double(b), label: "Resolved"))
        entries.append(PieChartDataEntry(value: Double(c), label: "High Priority"))
        entries.append(PieChartDataEntry(value: Double(d), label: "Overdue"))
        entries.append(PieChartDataEntry(value: Double(f), label: "New Ticket"))
        entries.append(PieChartDataEntry(value: Double(e), label: "Reassigned"))
       
       // let dataSet = PieChartDataSet(entries: entries, label: "TaskList")
            let dataSet = PieChartDataSet(entries: entries, label: "TaskList")
            print(dataSet)

            let data = PieChartData(dataSets: [dataSet])
            
            let pFormatter = NumberFormatter()
            pFormatter.numberStyle = .percent
            pFormatter.maximumFractionDigits = 1
            pFormatter.multiplier = 1
            pFormatter.percentSymbol = " %"
            data.setValueFormatter(DefaultValueFormatter(formatter: pFormatter))
            
            self.pieChart.data = data

        
        let c1 = NSUIColor(hex: 0xffbf00)
        let c2 = NSUIColor(hex: 0x00ff00)
        let c3 = NSUIColor(hex: 0xff8c00)
        let c4 = NSUIColor(hex: 0xff0000)
        let c5 = NSUIColor(hex: 0x0000ff)
        let c6 = NSUIColor(hex: 0x9932cc)
        
        dataSet.colors = [c1, c2, c3, c4, c5, c6]
        dataSet.drawValuesEnabled = true
         
           // dataSet.valueLinePart1OffsetPercentage
            
       
        dataSet.sliceSpace = 2.5
        dataSet.selectionShift = 10
      
            
         
        
          
          
        
            
            pieChart.animate(xAxisDuration: 1.0, yAxisDuration: 1.0)
            pieChart.layer.borderWidth = 0.1
            
            //set pie chart data
       
        pieChart.data = PieChartData(dataSet: dataSet)
    }
    }
    
    
    
    func dashboardService ()  {
        
        
     
        
        let params = ["department_id":"\(departmentId)","type":"\(userType)","login_department_id":"\(departmentId)","user_id":"\(userId)"]
        print(params)
        
        Service.shared.POSTService(serviceType: API.dashBoard, parameters: params ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            
            if responseDetails["status"] == 200 {
                
                
              let data = responseDetails["data"]?.dictionary
                print(data as Any)
             
                
                
                
                self.pending = data?["pendingMyTicket"]?.int ?? 0
                self.pendingMyTicketLbl.text = "\(self.pending)"
               
               
                self.resolve = data?["resolvedMyTicket"]?.int ?? 0
                self.resolveMyTickets.text = "\(self.resolve)"
              
                
                self.highPriority = data?["highMyAssignPriority"]?.int ?? 0
                self.highPriorityMyTicketsLbl.text = "\(self.highPriority)"
        
                
                self.overdue = data?["overMyAssignPriority"]?.int ?? 0
                self.overdueMyTicktesLbl.text = "\(self.overdue)"
                
                self.reAssign = data?["reassignTicket"]?.int ?? 0
                self.reAssignLbl.text = "\(self.reAssign)"
                
                self.newTicket = data?["unassignedTicket"]?.int ?? 0
                self.unassignLbl.text = "\(self.newTicket)"
                
                let flash = data?["flash_message"]?.array
                
                for i in flash! {
                    let fMessage = i["message"].string
                    self.flashMessage.append(fMessage!)
                }
                
                self.scrollTextLbl.text = self.flashMessage.map { String($0) }
                    .joined(separator: "  ")
                

                
                
                _ = Timer.scheduledTimer(timeInterval: 0.3, target: self, selector: #selector(self.marquee), userInfo: nil, repeats: true)
                
           
                let submittedTickets = data?["submitted_ticket"]?.dictionary
                
                self.submittedPendingLbl.text = "\(submittedTickets?["submitted_pending"]?.int ?? 0)"
                self.submittedResolvedLbl.text = "\(submittedTickets?["submitted_resloved"]?.int ?? 0)"
                self.submittedHighPriorityLbl.text = "\(submittedTickets?["submitted_highp"]?.int ?? 0)"
                self.submittedOverdueLbl.text = "\(submittedTickets?["submitted_overdue"]?.int ?? 0)"
                self.submittedNewTicketLbl.text = "\(submittedTickets?["submitted_newticket"]?.int ?? 0)"
                self.submittedReassignedLbl.text = "\(submittedTickets?["submitted_reticket"]?.int ?? 0)"
                
                
                
                
                
                
                
                
                
                self.setupPieChart()
                
            

            }else if responseDetails["status"] == 419 {
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) {
                    exit(0)
                }

            }else{
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
                
                
            }
        }
        
        
        
        
    }
   

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    func setupPieChart1() {
        
        pieChart.chartDescription?.enabled = false
        pieChart.drawHoleEnabled = false
        pieChart.rotationAngle = 0
        pieChart.rotationEnabled = true
        
        
        
        let pieChartLegend = pieChart.legend
        pieChartLegend.horizontalAlignment = Legend.HorizontalAlignment.right
        pieChartLegend.verticalAlignment = Legend.VerticalAlignment.top
        pieChartLegend.orientation = Legend.Orientation.vertical
        pieChartLegend.xEntrySpace = 0
        pieChartLegend.yEntrySpace = 10
        pieChartLegend.yOffset = 0
        
        // pieChartLegend.drawInside = false
        //  pieChartLegend.yOffset = 10.0
        
        pieChart.legend.enabled = true
        pieChart.drawEntryLabelsEnabled = false
        //  pieChart.usePercentValuesEnabled = true
        self.pieChart.notifyDataSetChanged()
        
        
        let total = unsolved + solved + unAssigned
        print(total)
        
        
        if total == 0 {
            var entries: [PieChartDataEntry] = Array()
            entries.append(PieChartDataEntry(value: 100, label: "100% NoChartAvailable"))
            
            
            let dataSet = PieChartDataSet(entries: entries, label: "TaskList")
            
            let c1 = NSUIColor(hex: 0x999999)
            
            
            dataSet.colors = [c1]
            dataSet.drawValuesEnabled = true
            
            pieChart.data = PieChartData(dataSet: dataSet)
        }else{
            
            
            let a = 100 * unsolved/total
            let b = 100 * solved/total
            let c = 100 * unAssigned/total

            var entries: [PieChartDataEntry] = Array()
            entries.append(PieChartDataEntry(value: Double(a), label: "\(a)% unsolved"))
            entries.append(PieChartDataEntry(value: Double(b), label: "\(b)% solved"))
            entries.append(PieChartDataEntry(value: Double(c), label: "\(c)%  unassigned"))
            
            let dataSet = PieChartDataSet(entries: entries, label: "TaskList")
            print(dataSet)
            
            let data = PieChartData(dataSets: [dataSet])
            
            let pFormatter = NumberFormatter()
            pFormatter.numberStyle = .percent
            pFormatter.maximumFractionDigits = 1
            pFormatter.multiplier = 1
            pFormatter.percentSymbol = " %"
            data.setValueFormatter(DefaultValueFormatter(formatter: pFormatter))
            
            self.pieChart.data = data
            
            let c1 = NSUIColor(hex: 0xffbf00)
            let c2 = NSUIColor(hex: 0x00ff00)
            let c3 = NSUIColor(hex: 0xff8c00)

            
            dataSet.colors = [c1, c2, c3]
            dataSet.drawValuesEnabled = true
           
           
            dataSet.sliceSpace = 2.5
            dataSet.selectionShift = 10
            
            
            pieChart.animate(xAxisDuration: 1.0, yAxisDuration: 1.0)
            pieChart.layer.borderWidth = 0.1
            pieChart.data = PieChartData(dataSet: dataSet)
        }
    }
    
    
    
    func dashboardService1 ()  {
        
        
        
        if departmentTF.text == "IT" {
            Ids.departmentIds = 12
        }
       
        
        
        let params = ["department_id":"\( Ids.departmentIds)","type":"\(userType)","login_department_id":"\(departmentId)","user_id":"\(userId)"]
        print(params)
       
        Service.shared.POSTService(serviceType: API.dashBoard, parameters: params ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            
            if responseDetails["status"] == 200 {
                
                
                let data = responseDetails["data"]?.dictionary
                print(data as Any)
                
                
                
                
                self.unsolved = data?["unsolved"]?.int ?? 0
              //  self.pendingMyTicketLbl.text = "\(self.pending)"
                
                
                self.solved = data?["solved"]?.int ?? 0
             //   self.resolveMyTickets.text = "\(self.resolve)"
                
                
                self.unAssigned = data?["unassigned"]?.int ?? 0
              //  self.highPriorityMyTicketsLbl.text = "\(self.highPriority)"
                
                
//                self.overdue = data?["overMyAssignPriority"]?.int ?? 0
//                self.overdueMyTicktesLbl.text = "\(self.overdue)"
//
//                self.reAssign = data?["reassignTicket"]?.int ?? 0
//                self.reAssignLbl.text = "\(self.reAssign)"
//
//                self.unAssign = data?["unassignedTicket"]?.int ?? 0
//                self.unassignLbl.text = "\(self.unAssign)"
                
                let flash = data?["flash_message"]?.array
                
                for i in flash! {
                    let fMessage = i["message"].string
                    self.flashMessage.append(fMessage!)
                }
                
                self.scrollTextLbl.text = self.flashMessage.map { String($0) }
                    .joined(separator: ", ")
                
                
                
                
                _ = Timer.scheduledTimer(timeInterval: 0.3, target: self, selector: #selector(self.marquee), userInfo: nil, repeats: true)
                
                
                let submittedTickets = data?["submitted_ticket"]?.dictionary
                
                self.submittedPendingLbl.text = "\(submittedTickets?["submitted_pending"]?.int ?? 0)"
                self.submittedResolvedLbl.text = "\(submittedTickets?["submitted_resloved"]?.int ?? 0)"
                self.submittedHighPriorityLbl.text = "\(submittedTickets?["submitted_highp"]?.int ?? 0)"
                self.submittedOverdueLbl.text = "\(submittedTickets?["submitted_overdue"]?.int ?? 0)"
                self.submittedNewTicketLbl.text = "\(submittedTickets?["submitted_newticket"]?.int ?? 0)"
                self.submittedReassignedLbl.text = "\(submittedTickets?["submitted_reticket"]?.int ?? 0)"
                
                
                
                
                
                
                
                
                
                self.setupPieChart1()
                
                
                
            }else if responseDetails["status"] == 419 {
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) {
                    exit(0)
                }
                
            }else{
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
                
                
            }
        }
        
        
        
        
    }
    
 
    @IBAction func pendingView(_ sender: Any) {
        
        
        if pendingMyTicketLbl.text == "0" {
            SingleToneClass.shared.dismissProgressLoading()
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "There is no related tickets") {
            }
        }else{
        
        
        
        
        let emp = storyboard?.instantiateViewController(withIdentifier: "MPIViewController") as! MPIViewController
        navigationController?.pushViewController(emp, animated: true)
        DetailsStore.pending = true
        DetailsStore.resolved = false
        DetailsStore.highPriority = false
        DetailsStore.overdue = false
        DetailsStore.unassigned = false
        DetailsStore.reassigned = false
        }
    }
    
    
    @IBAction func resolvedView(_ sender: Any) {
        
        if resolveMyTickets.text == "0" {
            SingleToneClass.shared.dismissProgressLoading()
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "There is no related tickets") {
            }
        }else{
        let emp = storyboard?.instantiateViewController(withIdentifier: "MPIViewController") as! MPIViewController
        navigationController?.pushViewController(emp, animated: true)
        DetailsStore.resolved = true
        DetailsStore.highPriority = false
        DetailsStore.overdue = false
        DetailsStore.unassigned = false
        DetailsStore.reassigned = false
        DetailsStore.pending = false
    }
    }
 
    @IBAction func highPriorityView(_ sender: Any) {
        
        if highPriorityMyTicketsLbl.text == "0" {
            SingleToneClass.shared.dismissProgressLoading()
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "There is no related tickets") {
            }
        }else{
            
        let emp = storyboard?.instantiateViewController(withIdentifier: "MPIViewController") as! MPIViewController
        navigationController?.pushViewController(emp, animated: true)
        DetailsStore.highPriority = true
        DetailsStore.overdue = false
        DetailsStore.unassigned = false
        DetailsStore.reassigned = false
        DetailsStore.pending = false
        DetailsStore.resolved = false
    }
    }
    
    @IBAction func overdueView(_ sender: Any) {
        
        if overdueMyTicktesLbl.text == "0" {
            SingleToneClass.shared.dismissProgressLoading()
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "There is no related tickets") {
            }
        }else{
        let emp = storyboard?.instantiateViewController(withIdentifier: "MPIViewController") as! MPIViewController
        navigationController?.pushViewController(emp, animated: true)
        DetailsStore.overdue = true
        DetailsStore.unassigned = false
        DetailsStore.reassigned = false
        DetailsStore.pending = false
        DetailsStore.resolved = false
        DetailsStore.highPriority = false
    }
    }
    @IBAction func unassignedView(_ sender: Any) {
        
        
        if unassignLbl.text == "0" {
            SingleToneClass.shared.dismissProgressLoading()
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "There is no related tickets") {
            }
        }else{
        let emp = storyboard?.instantiateViewController(withIdentifier: "MPIViewController") as! MPIViewController
        navigationController?.pushViewController(emp, animated: true)
        DetailsStore.unassigned = true
        DetailsStore.reassigned = false
        DetailsStore.pending = false
        DetailsStore.resolved = false
        DetailsStore.highPriority = false
        DetailsStore.overdue = false
        
    }
    }
    
    @IBAction func reassignView(_ sender: Any) {
        
        if reAssignLbl.text == "0" {
            SingleToneClass.shared.dismissProgressLoading()
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "There is no related tickets") {
            }
        }else{
        let emp = storyboard?.instantiateViewController(withIdentifier: "MPIViewController") as! MPIViewController
        navigationController?.pushViewController(emp, animated: true)
        DetailsStore.reassigned = true
        DetailsStore.pending = false
        DetailsStore.resolved = false
        DetailsStore.highPriority = false
        DetailsStore.overdue = false
        DetailsStore.unassigned = false
    }
    }
    
    
    
    
    
    @objc func marquee(){

        let str = scrollTextLbl.text!
        print(str)
        let indexFirst = str.index(str.startIndex, offsetBy: 0)
        print(indexFirst)
        let indexSecond = str.index(str.startIndex, offsetBy: 1)
        print(indexSecond)
        print(str.startIndex)
        print(String(str.suffix(from: indexSecond)))
        print(String(str[indexFirst]))
        scrollTextLbl.text = String(str.suffix(from: indexSecond)) + String(str[indexFirst])
        print(scrollTextLbl.text as Any)
       // view.addSubview(scrollTextLbl)
    }

   
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == departmentTF {
            let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ComplaintPickerViewController") as! ComplaintPickerViewController
            POPUPVC.tagValue = textField.tag
            SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
            self.addChild(POPUPVC)
            POPUPVC.view.frame = CGRect.init(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
            self.view.addSubview(POPUPVC.view)
            POPUPVC.didMove(toParent: self)
            self.departmentTF.resignFirstResponder()
        }
    }
    
    
    
    
    
}


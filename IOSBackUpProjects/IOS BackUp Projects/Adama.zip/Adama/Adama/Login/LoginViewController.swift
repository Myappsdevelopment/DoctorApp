//
//  LoginViewController.swift
//  Adama
//
//  Created by MAD-MAC on 26/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import SideMenu

class LoginViewController: UIViewController {
    
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var loginBtn: UIButton!
    
    var imageViewObject :UIImageView!
    
    
    
    override func viewWillAppear(_ animated: Bool) {
         self.navigationController?.isNavigationBarHidden = true
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
        
        
        loginBtn.layer.cornerRadius = 10
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        // Do any additional setup after loading the view.
        emailTF.leftViewMode = UITextField.ViewMode.always
        let imageView1 = UIImageView(frame: CGRect(x: 0, y: 0, width: 30, height: 25))
        imageView1.contentMode = UIView.ContentMode.scaleAspectFit
        imageView1.image = imageView1.image?.withRenderingMode(.alwaysTemplate)
        let image1 = UIImage(named: "man-user")
        imageView1.image = image1
        emailTF.leftView = imageView1
         self.view.addSubview(imageView1)
        
        
        passwordTF.leftViewMode = UITextField.ViewMode.always
        let imageView2 = UIImageView(frame: CGRect(x: 0, y: 0, width: 30 , height: 25   ))
        imageView2.contentMode = UIView.ContentMode.scaleAspectFit
        imageView2.image = imageView2.image?.withRenderingMode(.alwaysTemplate)
        let image2 = UIImage(named: "ic_password_green")
        imageView2.image = image2
        passwordTF.leftView = imageView2
         self.view.addSubview(imageView2)
        
        
        passwordTF.rightViewMode = UITextField.ViewMode.always
        imageViewObject = UIImageView(frame: CGRect(x: 0, y: 0, width: 30 , height: 30))
        imageViewObject.isUserInteractionEnabled = true
        imageViewObject.contentMode = UIView.ContentMode.scaleAspectFit
        self.view.addSubview(imageViewObject)
        
        
        let hideImage = UIImage(named: "eye")
        imageViewObject.image = hideImage
        passwordTF.rightView = imageViewObject
        imageViewObject.image = imageViewObject.image?.withRenderingMode(.alwaysTemplate)
        imageViewObject.tintColor = UIColor.darkGray
        let imageViewForPass = imageViewObject
        imageViewForPass?.isMultipleTouchEnabled = true
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped(tapGestureRecognizer:)))
        imageViewForPass!.addGestureRecognizer(tapGestureRecognizer)
 
        
        
    }
    
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        
        if self.imageViewObject.isHighlighted == false {
            self.imageViewObject.isHighlighted = true
            self.imageViewObject.image = UIImage(named:"Untitled-1_0001_eye")
            self.passwordTF.isSecureTextEntry = false
            imageViewObject.image = imageViewObject.image?.withRenderingMode(.alwaysTemplate)
            imageViewObject.tintColor = UIColor.darkGray
            
        } else {
            
            self.imageViewObject.isHighlighted = false
            self.imageViewObject.image = UIImage(named:"eye")
            imageViewObject.image = imageViewObject.image?.withRenderingMode(.alwaysTemplate)
            imageViewObject.tintColor = UIColor.darkGray
            let existigPassword:String = self.passwordTF.text ?? ""
            self.passwordTF.isSecureTextEntry = true
            self.passwordTF.insertText(existigPassword)
        }
    }
    
    

    @IBAction func loginBtn(_ sender: Any) {
        
        
        if !emailTF.isValidMobileNumberTextField() && !emailTF.isValidEmailTextField() && !emailTF.isValidTextField() {
            
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter Valid mobile number /Valid EmailID / Valid Username") {
                self.emailTF.becomeFirstResponder()
            }
            
            
        } else if !passwordTF.isValidTextField() {
            
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter password") {
                self.passwordTF.becomeFirstResponder()
            }
            
        } else {
            
            SingleToneClass.shared.showProgressLoading(title: "Please wait...")
            loginServiceCall()

        
        }
        
        
        
    }
    @IBAction func forgotPasswordBtn(_ sender: Any) {
        
        let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let gotoLogin = storyBoard.instantiateViewController(withIdentifier: "ForgotPasswordViewController") as! ForgotPasswordViewController
        self.navigationController?.pushViewController(gotoLogin, animated: true)
        

    
        
    }
    
    
    func loginServiceCall () {
        
        let params = ["email_mobile":emailTF.text!,"password":passwordTF.text!,"device_type":"2","device_token":"APA91bEAGx-BbDU657vrF9SKHjfvyw4H7LauPUqsO9942wYWufiTd8UAHGmv6u04vTSBQqcAqE_PGJc0V0xh4oHv9fhOKmT-DssjY3vwe-DMtavlFndf3hpMpA_Xw_xhOlRzpGjN6CNV","app_version":"1"]
        print(params)
        
        Service.shared.POSTService(serviceType: API.login, parameters: params ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                print(message as Any)
          
             
                if responseDetails["status"] == 200 {
                    
                    let data = responseDetails["data"]?.dictionary
                    
                    let id = data!["id"]?.int
                    let employeeId = data!["em_id"]?.string
                    let name = data!["name"]?.string
                    let email = data!["email"]?.string
                    let mobileNo = data!["mobile_no"]?.string
                    let userType = data!["type"]?.int
                    let departmentId = data!["department_id"]?.int
                    let subDepartmentId = data!["sub_departmentid"]?.int
                    let role = data!["role"]?.string ?? "SubDepartmentManager"
                   
                    let departmentName = data!["department"]?.dictionary
                    let DepartName = departmentName!["d_name"]?.string
                   
                    let createdBy = data!["created_by"]?.int
                    let date = data!["joining_date"]?.string
                    
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd"
                    
                    
                    let showDate = dateFormatter.date(from: date!)
                    dateFormatter.dateFormat = "dd-MM-yyyy"
                    let dateOfJoining = dateFormatter.string(from: showDate!)
                   
                    
                    let workLocation = data!["location"]?.string
                    let wareHouse = data!["ware_house"]?.string
                    let zone = data!["zone"]?.string
                    let region = data!["region"]?.string
                    let headQuater = data!["head_quater"]?.string
                    let territory = data!["teritory"]?.string
                    let investigation = data!["is_investigate"]?.int
                    let hardware = data!["hardware"]?.string
                    let software = data!["software"]?.string
                    
                   
                    
                    let designationName = data!["designation_name"]?.dictionary
                    let dName = designationName!["name"]?.string
                    
                    if let reportingManager = data!["r_manager"]?.dictionary {
                        let rName = reportingManager["name"]?.string
                         UserDefaults.standard.set(rName, forKey: "ReportingManager")
                    }
                    
                    let subDepartment = data!["subdepartment"]?.dictionary
                    let subDepartmentName = subDepartment!["SubDepartment_name"]?.string
                    
                    
                    
                    let image = responseDetails["image_path"]?.string
                    if let logo = data?["logo"]?.string{
                       
                        let profileImage = image! + logo
                        UserDefaults.standard.set(profileImage, forKey: "ProfileImage")
                        
                    }
                    
       
                    UserDefaults.standard.set(id, forKey: "UserId")
                    UserDefaults.standard.set(employeeId, forKey: "EmployeeId")
                    UserDefaults.standard.set(name, forKey: "Name")
                    UserDefaults.standard.set(email, forKey: "Email")
                    UserDefaults.standard.set(mobileNo, forKey: "MobileNo")
                    UserDefaults.standard.set(userType, forKey: "UserType")
                    UserDefaults.standard.set(departmentId, forKey: "DepartmentId")
                //    UserDefaults.standard.set(subDepartmentId, forKey: "SubDepartmentId")
                    UserDefaults.standard.set(DepartName, forKey: "DepartmentName")
                    UserDefaults.standard.set(role, forKey: "Role")
                    UserDefaults.standard.set(createdBy, forKey: "CreatedBy")
                    UserDefaults.standard.set(dateOfJoining, forKey: "DateOfJoining")
                    UserDefaults.standard.set(dName, forKey: "Designation")
                   
                    UserDefaults.standard.set(workLocation, forKey: "Location")
                    UserDefaults.standard.set(wareHouse, forKey: "WareHouse")
                    UserDefaults.standard.set(zone, forKey: "Zone")
                    UserDefaults.standard.set(region, forKey: "Region")
                    UserDefaults.standard.set(headQuater, forKey: "HeadQuater")
                    UserDefaults.standard.set(territory, forKey: "Territory")
                    UserDefaults.standard.set(investigation, forKey: "IsInvestigation")
                    UserDefaults.standard.set(hardware, forKey: "Hardware")
                    UserDefaults.standard.set(software, forKey: "Software")
                    UserDefaults.standard.set(subDepartmentId, forKey: "LoginSubDepartmentId")
                    UserDefaults.standard.set(subDepartmentName, forKey: "SubDepartmentName")
                    
        

                    
                    
                    let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
                    let gotoOTP = storyBoard.instantiateViewController(withIdentifier: "MPIViewController") as! MPIViewController
                   
                    DetailsStore.assignedTickets = false
                    DetailsStore.allTickets = false
                    DetailsStore.submittedTickets = false
                    DetailsStore.ticket = false
                    DetailsStore.dashboard = false
                    DetailsStore.knowledgeBase = false
                    DetailsStore.profile = false
                    DetailsStore.changePassword = false
                    DetailsStore.customerComplaintSideMenu = false
                    DetailsStore.assignedComplaintSideMenu = false
                    DetailsStore.submittedComplaintSideMenu = false
                    DetailsStore.notification = false
                    DetailsStore.reports = false
                  
                    self.navigationController?.pushViewController(gotoOTP, animated: true)
                    
     
                }
                    
                else{
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") { }
            }
            
        }
        
        
        
    }
    
    

}

//
//  ConfirmPasswordViewController.swift
//  Adama
//
//  Created by MAD-MAC on 27/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class ConfirmPasswordViewController: UIViewController {

    
    @IBOutlet weak var passwordTF: TextField!
    
    @IBOutlet weak var confirmPwdTF: TextField!
    
    @IBOutlet weak var loginBtn: UIButton!
    
        var id : Int?
        var imageViewObject :UIImageView!
        var imageViewObject1 : UIImageView!
    
    override func viewWillAppear(_ animated: Bool) {
        let imgBack = UIImage(named:"Arrow")
        print(imgBack as Any)
        navigationController?.navigationBar.backIndicatorImage = imgBack
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
        
        navigationItem.leftItemsSupplementBackButton = true
        navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        
        self.navigationController?.isNavigationBarHidden = false
        self.title = "Confirm Password"
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.tabBarController?.tabBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        loginBtn.layer.borderWidth = 1
//        loginBtn.layer.borderColor = UIColor.black.cgColor
//        loginBtn.layer.cornerRadius = 25
        // Do any additional setup after loading the view.
        
        confirmPwdTF.leftViewMode = UITextField.ViewMode.always
        let imageView1 = UIImageView(frame: CGRect(x: 0, y: 0, width: 30 , height: 20))
        let image1 = UIImage(named: "key")
        imageView1.image = image1
        confirmPwdTF.leftView = imageView1
        
        passwordTF.leftViewMode = UITextField.ViewMode.always
        let imageView2 = UIImageView(frame: CGRect(x: 0, y: 0, width: 30 , height: 20))
        let image2 = UIImage(named: "key")
        imageView2.image = image2
        passwordTF.leftView = imageView2
        
        
        passwordTF.rightViewMode = UITextField.ViewMode.always
        imageViewObject = UIImageView(frame: CGRect(x: 0, y: 0, width: 20 , height: 20))
        imageViewObject.isUserInteractionEnabled = true
        imageViewObject.contentMode = UIView.ContentMode.scaleAspectFit
        self.view.addSubview(imageViewObject)
        
        confirmPwdTF.rightViewMode = UITextField.ViewMode.always
        imageViewObject1 = UIImageView(frame: CGRect(x: 0, y: 0, width: 20 , height: 20))
        imageViewObject1.isUserInteractionEnabled = true
        imageViewObject1.contentMode = UIView.ContentMode.scaleAspectFit
        self.view.addSubview(imageViewObject1)
        
        let hideImage = UIImage(named: "eye")
        imageViewObject.image = hideImage
        passwordTF.rightView = imageViewObject
        imageViewObject.image = imageViewObject.image?.withRenderingMode(.alwaysTemplate)
        imageViewObject.tintColor = UIColor.darkGray
        let imageViewForPass = imageViewObject
        imageViewForPass?.isMultipleTouchEnabled = true
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped(tapGestureRecognizer:)))
        imageViewForPass!.addGestureRecognizer(tapGestureRecognizer)
        
        let hideImage1 = UIImage(named: "eye")
        imageViewObject1.image = hideImage1
        confirmPwdTF.rightView = imageViewObject1
        imageViewObject1.image = imageViewObject1.image?.withRenderingMode(.alwaysTemplate)
        imageViewObject1.tintColor = UIColor.darkGray
        let imageViewForPass1 = imageViewObject1
        imageViewForPass1?.isMultipleTouchEnabled = true
        let tapGestureRecognizer1 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped1(tapGestureRecognizer:)))
        imageViewForPass1!.addGestureRecognizer(tapGestureRecognizer1)
        
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        
        if self.imageViewObject.isHighlighted == false {
            self.imageViewObject.isHighlighted = true
            self.imageViewObject.image = UIImage(named:"Untitled-1_0001_eye")
            self.passwordTF.isSecureTextEntry = false
            imageViewObject.image = imageViewObject.image?.withRenderingMode(.alwaysTemplate)
            imageViewObject.tintColor = UIColor.darkGray
        } else {
            
            
            self.imageViewObject.isHighlighted = false
            self.imageViewObject.image = UIImage(named:"eye")
            imageViewObject.image = imageViewObject.image?.withRenderingMode(.alwaysTemplate)
            imageViewObject.tintColor = UIColor.darkGray
            let existigPassword:String = self.passwordTF.text ?? ""
            self.passwordTF.isSecureTextEntry = true
            self.passwordTF.insertText(existigPassword)
        }
    }
    
    @objc func imageTapped1(tapGestureRecognizer: UITapGestureRecognizer)
    {
        
        if self.imageViewObject1.isHighlighted == false {
            self.imageViewObject1.isHighlighted = true
            self.imageViewObject1.image = UIImage(named:"Untitled-1_0001_eye")
            self.confirmPwdTF.isSecureTextEntry = false
            imageViewObject1.image = imageViewObject1.image?.withRenderingMode(.alwaysTemplate)
            imageViewObject1.tintColor = UIColor.darkGray
        } else {
            
            
            self.imageViewObject1.isHighlighted = false
            self.imageViewObject1.image = UIImage(named:"eye")
            imageViewObject1.image = imageViewObject1.image?.withRenderingMode(.alwaysTemplate)
            imageViewObject1.tintColor = UIColor.darkGray
            let existigPassword:String = self.confirmPwdTF.text ?? ""
            self.confirmPwdTF.isSecureTextEntry = true
            self.confirmPwdTF.insertText(existigPassword)
        }
    }
    
    @IBAction func goBtn(_ sender: Any) {
        
        if !passwordTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter password") {
                self.passwordTF.becomeFirstResponder()
            }
        } else if confirmPwdTF.text != passwordTF.text {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Password and confirm password must be same") {
                self.confirmPwdTF.becomeFirstResponder()
            }
            
        } else {
            SingleToneClass.shared.showProgressLoading(title: "Please wait...")
            
               confirmPasswordServiceCall()
            
            
            
        }
        
        
        
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let nextVc = storyboard.instantiateViewController(withIdentifier :"ChangedPasswordViewController") as! ChangedPasswordViewController
//        self.present(nextVc, animated: true, completion: nil)
        
    }
    
    func confirmPasswordServiceCall()  {
        
        
        let params = ["user_id":"\(id!)","password":confirmPwdTF.text!] 
        print(params)
        
        Service.shared.POSTService(serviceType: API.confirmPassword, parameters: params) { (response) -> (Void) in
            
            print(response)
             SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            
            if responseDetails["status"] == 200 {
                
               // let responseNumber = responseDetails["user_id"]?.string
                //
                //                DetailsStore.forgotDetails = responseNumber
                //                print(DetailsStore.forgotDetails as Any)
                
                let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
                let gotoLogin = storyBoard.instantiateViewController(withIdentifier: "ChangedPasswordViewController") as! ChangedPasswordViewController
                self.navigationController?.pushViewController(gotoLogin, animated: true)
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
            }else{
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
                
                
            }
            
        }
        
        
        
        
    }
}

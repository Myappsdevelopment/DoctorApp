//
//  ForgotPasswordViewController.swift
//  Adama
//
//  Created by MAD-MAC on 26/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class ForgotPasswordViewController: UIViewController {

    
    
    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var mobileNoTF: TextField!
    
    override func viewWillAppear(_ animated: Bool) {
        
        let imgBack = UIImage(named:"Arrow")
        print(imgBack as Any)
        navigationController?.navigationBar.backIndicatorImage = imgBack
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
        
        navigationItem.leftItemsSupplementBackButton = true
        navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        
        
        
        self.navigationController?.isNavigationBarHidden = false
        self.title = "Forgot Password"
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
    
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
      //  self.navigationController?.view.backgroundColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        
        loginBtn.layer.borderWidth = 1
        loginBtn.layer.borderColor = UIColor.black.cgColor
        loginBtn.layer.cornerRadius = 20
        
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func goBtn(_ sender: Any) {
        
        
        if !mobileNoTF.isValidMobileNumberTextField() && !mobileNoTF.isValidEmailTextField() && !mobileNoTF.isValidTextField() {
            
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter Valid mobile number /Valid EmailID") {
                self.mobileNoTF.becomeFirstResponder()
            }
        }else{
             SingleToneClass.shared.showProgressLoading(title: "Please wait...")
            forgotService()
        }
        

        
    }
    
    func forgotService () {
        
        let params = ["email_mobile":mobileNoTF.text!]
        print(params)
        
        Service.shared.POSTService(serviceType: API.forgot, parameters: params ) { (response) -> (Void) in
            
            print(response)
             SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            
            if responseDetails["status"] == 200 {
                
                let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
                let gotoLogin = storyBoard.instantiateViewController(withIdentifier: "OTPViewController") as! OTPViewController
                gotoLogin.verify = self.mobileNoTF.text
                
                self.navigationController?.pushViewController(gotoLogin, animated: true)
             
             SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
                SingleToneClass.shared.dismissProgressLoading(WithDelay: 0.50)
            }else{
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
                
                
            }
        }
        
        
    }

}

//
//  OTPViewController.swift
//  Adama
//
//  Created by MAD-MAC on 27/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class OTPViewController: UIViewController,UITextFieldDelegate {

 
    
    @IBOutlet weak var otp1: UITextField!
    
    @IBOutlet weak var otp2: UITextField!
    
    @IBOutlet weak var otp3: UITextField!
    
    @IBOutlet weak var otp4: UITextField!
    
    @IBOutlet weak var otp6: UITextField!
    @IBOutlet weak var otp5: UITextField!
    @IBOutlet weak var verifyLbl: UILabel!
    
    @IBOutlet weak var loginBtn: UIButton!
    
    // var userData: [String : String]?
    var otp: String?
    var verify: String?
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        
        let imgBack = UIImage(named:"Arrow")
        print(imgBack as Any)
        navigationController?.navigationBar.backIndicatorImage = imgBack
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
        
        navigationItem.leftItemsSupplementBackButton = true
        navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        
        self.navigationController?.isNavigationBarHidden = false
        self.title = "OTP Validation"
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.tabBarController?.tabBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white
        navigationItem.leftBarButtonItem?.tintColor = UIColor.white
        
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.verifyLbl.text = verify ?? ""

        self.otp1.layer.cornerRadius = 8
        self.otp2.layer.cornerRadius = 8
        self.otp3.layer.cornerRadius = 8
        self.otp4.layer.cornerRadius = 8
        self.otp5.layer.cornerRadius = 8
        self.otp6.layer.cornerRadius = 8
        
//        loginBtn.layer.borderWidth = 1.5
//        loginBtn.layer.borderColor = UIColor.black.cgColor
//        loginBtn.layer.cornerRadius = 20
        
        
        
        otp1.textFieldAsLine()
        otp2.textFieldAsLine()
        otp3.textFieldAsLine()
        otp4.textFieldAsLine()
        otp5.textFieldAsLine()
        otp6.textFieldAsLine()
    
        
        otp1.delegate = self
        otp2.delegate = self
        otp3.delegate = self
        otp4.delegate = self
        otp5.delegate = self
        otp6.delegate = self
        
        
        
        
        otp1.addTarget(self, action: #selector(generatePasswordTextFieldDidChanged(textField:)), for: .editingChanged)
        otp2.addTarget(self, action: #selector(generatePasswordTextFieldDidChanged(textField:)), for: .editingChanged)
        otp3.addTarget(self, action: #selector(generatePasswordTextFieldDidChanged(textField:)), for: .editingChanged)
        otp4.addTarget(self, action: #selector(generatePasswordTextFieldDidChanged(textField:)), for: .editingChanged)
         otp5.addTarget(self, action: #selector(generatePasswordTextFieldDidChanged(textField:)), for: .editingChanged)
         otp6.addTarget(self, action: #selector(generatePasswordTextFieldDidChanged(textField:)), for: .editingChanged)
        
        if let mobileNumber = verify {
            let newMobilleNumber = mobileNumber.dropFirst(7)
            let hiddenMobileNumber = "+91XXXXXXX\(newMobilleNumber)"
            self.verifyLbl.text = hiddenMobileNumber
            print(verifyLbl.text as Any)

        }
            if SingleToneClass.shared.isInternetAvailable()==false{
                SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                    
                }
            }
            
        
        
        // Do any additional setup after loading the view.
    }
    

    @objc func generatePasswordTextFieldDidChanged(textField : UITextField) -> Void {
        
        if (textField.text?.count)! > 0 {
            
            switch textField {
                
            case otp1:
                
                self.otp2.becomeFirstResponder()
                break
                
            case otp2:
                
                self.otp3.becomeFirstResponder()
                break
                
            case otp3:
                
                self.otp4.becomeFirstResponder()
                break
                
            case otp4:
                
                self.otp5.becomeFirstResponder()
                break
                
            case otp5:
                
                self.otp6.becomeFirstResponder()
                break
                
            case otp6:
                
                self.otp6.resignFirstResponder()
                break
                
            default:
                
                break
                
            }
            
        } else {
            
            switch textField {
                
            case otp6:
                
                self.otp5.becomeFirstResponder()
                break
                
            case otp5:
                
                self.otp4.becomeFirstResponder()
                break
                
            case otp4:
                
                self.otp3.becomeFirstResponder()
                break
                
            case otp3:
                
                self.otp2.becomeFirstResponder()
                break
                
            case otp2:
                
                self.otp1.becomeFirstResponder()
                break
                
            case otp1:
                
                self.otp1.resignFirstResponder()
                break
                
            default:
                
                break
                
            }
            
        }
        
    }
    
    


    @IBAction func goBtn(_ sender: Any) {
        
//    let otp9 = otp1.text!+otp2.text!+otp3.text!+otp4.text!+otp5.text!
//        print(otp9)
        otp = "\(otp1.text!)\(otp2.text!)\(otp3.text!)\(otp4.text!)\(otp5.text!)\(otp6.text!)"
        print(otp)
        guard let otpString = otp else { return }
        
        if otpString.count != 6 {
            
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter 4 digit OTP") {
                
                self.otp1.text = ""
                self.otp2.text = ""
                self.otp3.text = ""
                self.otp4.text = ""
                self.otp5.text = ""
                self.otp6.text = ""
                
            }
            
        } else {
            SingleToneClass.shared.showProgressLoading(title: "Please wait...")
             signUpWithOTPServiceCall()
            
        }
        
    }
    
    func signUpWithOTPServiceCall()  {
        
     //   verify = "5689525252"
        
        let params = ["email_mobile":verify!,"otp":otp!]
        print(params)
        
        Service.shared.POSTService(serviceType: API.OTP, parameters: params ) { (response) -> (Void) in
            
            print(response)
             SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            
            if responseDetails["status"] == 200 {
                
                let responseNumber = responseDetails["user_id"]?.int
                print(responseNumber)

//                DetailsStore.forgotDetails = responseNumber
//                print(DetailsStore.forgotDetails as Any)
                
                let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
                let gotoLogin = storyBoard.instantiateViewController(withIdentifier: "ConfirmPasswordViewController") as! ConfirmPasswordViewController
                
                gotoLogin.id = responseNumber
                self.navigationController?.pushViewController(gotoLogin, animated: true)
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
                SingleToneClass.shared.dismissProgressLoading(WithDelay: 0.50)
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
                
                
            }
        
        }
        
    }

    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField.text == otp1.text {
            
            let currentCharacterCount = otp1.text?.count ?? 0
            if range.length + range.location > currentCharacterCount {
                return false
            }
            let newLength = currentCharacterCount + string.count - range.length
            return newLength <= 1
            
        } else if textField.text == otp2.text {
            
            let currentCharacterCount = otp2.text?.count ?? 0
            if range.length + range.location > currentCharacterCount {
                return false
            }
            let newLength = currentCharacterCount + string.count - range.length
            return newLength <= 1
        }else if textField.text == otp3.text {
            
            let currentCharacterCount = otp3.text?.count ?? 0
            if range.length + range.location > currentCharacterCount {
                return false
            }
            let newLength = currentCharacterCount + string.count - range.length
            return newLength <= 1
        }else if textField.text == otp4.text {
            
            let currentCharacterCount = otp4.text?.count ?? 0
            if range.length + range.location > currentCharacterCount {
                return false
            }
            let newLength = currentCharacterCount + string.count - range.length
            return newLength <= 1
        }else if textField.text == otp5.text {
            
            let currentCharacterCount = otp5.text?.count ?? 0
            if range.length + range.location > currentCharacterCount {
                return false
            }
            let newLength = currentCharacterCount + string.count - range.length
            return newLength <= 1
        }else if textField.text == otp6.text {
            
            let currentCharacterCount = otp6.text?.count ?? 0
            if range.length + range.location > currentCharacterCount {
                return false
            }
            let newLength = currentCharacterCount + string.count - range.length
            return newLength <= 1
        }
        
        return true
    }
    
    
    
}

//
//  SplashViewController.swift
//  Adama
//
//  Created by MAD-MAC on 23/08/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class SplashViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.isNavigationBarHidden = true
        
        if UserDefaults.standard.object(forKey: "UserId") == nil {
            print(UserDefaults.standard.string(forKey: "UserId") as Any)
            let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
            let gotoLogin = storyBoard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
            self.navigationController?.pushViewController(gotoLogin, animated: true)
            

        }else{
            
            let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
            let gotoParcel = storyBoard.instantiateViewController(withIdentifier: "MPIViewController") as! MPIViewController
            self.navigationController?.pushViewController(gotoParcel, animated: true)
            
            
            
        }
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  TabBar2ViewController.swift
//  Grub X Vender
//
//  Created by Ashish dattu on 25/01/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import UIKit

class TabBar2ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var collection: UICollectionView!
    @IBOutlet weak var pageCount: UIPageControl!
    @IBOutlet weak var pendingBtn: UIButton!
    @IBOutlet weak var pendingView: UIView!
    @IBOutlet weak var receivedBtn: UIButton!
    @IBOutlet weak var receivedView: UIView!
   
    
    var limit = 0
    var x: Int = 0
    var strIndex:Int = 1
       
    var imageArray = [#imageLiteral(resourceName: "35"),#imageLiteral(resourceName: "35"),#imageLiteral(resourceName: "35")]
    
    
    let grayColour = UIColor(red: 143.0/255.0, green: 143.0/255.0, blue: 143.0/255.0, alpha: 1.0)
    let redColour = UIColor(red: 203.0/255.0, green: 8.0/255.0, blue: 22.0/255.0, alpha: 1.0)
       
       
    override func viewWillAppear(_ animated: Bool) {
             
        self.navigationController?.isNavigationBarHidden = false
        self.tabBarController?.tabBar.isHidden = false
        scrollViewDidEndDecelerating(collection)
    // self.navigationItem.title = "Dashboard"
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 203/255, green: 8/255, blue: 22/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white
           
    UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.gray], for:[])


       
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let floawLayout = UPCarouselFlowLayout()
        floawLayout.itemSize = CGSize(width: UIScreen.main.bounds.size.width, height: collection.frame.size.height)
        floawLayout.scrollDirection = .horizontal
        floawLayout.sideItemScale = 1.0
              collection.collectionViewLayout = floawLayout
        collection.isPagingEnabled = true
        // Do any additional setup after loading the view.
    }
    

    
    @IBAction func pendingBtn(_ sender: Any) {
        
        pendingBtn.setTitleColor(redColour, for: [])
        self.pendingView.backgroundColor = redColour
        receivedBtn.setTitleColor(grayColour, for: [])
        self.receivedView.backgroundColor = grayColour
    }
    
    @IBAction func receivedBtn(_ sender: Any) {
       
        pendingBtn.setTitleColor(grayColour, for: [])
        self.pendingView.backgroundColor = grayColour
        receivedBtn.setTitleColor(redColour, for: [])
        self.receivedView.backgroundColor = redColour
        
    }
    
    @IBAction func bellBtn(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "MessagesAndNotificationsViewController") as! MessagesAndNotificationsViewController
                            
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
         
        pageCount.numberOfPages = 3
        return 3
        
    }
         
       
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
             
    
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! tabBar2CollectionViewCell
            
        cell.cellImage.image = imageArray[indexPath.row]
           
        return cell
         
    }
       
       

         
       
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
          
        let offSet = scrollView.contentOffset.x
        print(offSet)
        let width = collection.frame.width
        let horizontalCenter = collection.frame.size.width / 2
        pageCount.currentPage = Int(offSet + horizontalCenter) / Int(width)
        print(pageCount.currentPage)
        
    }
         
        
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
             
         return CGSize(width:collection.frame.width, height: collection.frame.height)
       
    }
       
        
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
       
    {
        
        var visibleRect = CGRect()
         print(visibleRect)
        visibleRect.origin = collection.contentOffset
        visibleRect.size =  collection.bounds.size
        
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
        print(visiblePoint)
        guard let indexPath =  collection.indexPathForItem(at: visiblePoint) else { return }
        x = indexPath.row

        strIndex = indexPath.row
         
        let indexPathrow = IndexPath(item: x, section: 0)
        self.collection.scrollToItem(at: indexPathrow, at: .centeredHorizontally, animated: true)

        
    }
         
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

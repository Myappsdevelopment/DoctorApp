//
//  AddProductViewController.swift
//  Grub X Vender
//
//  Created by MAD-MAC on 31/01/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import UIKit

class AddProductViewController: UIViewController {

    
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view3: UIView!
    @IBOutlet weak var view4: UIView!
    @IBOutlet weak var view5: UIView!
    @IBOutlet weak var view6: UIView!
    
    
    override func viewWillAppear(_ animated: Bool) {
                
              
           self.navigationController?.isNavigationBarHidden = false
           self.tabBarController?.tabBar.isHidden = false
        //   scrollViewDidEndDecelerating(collection)
       // self.navigationItem.title = "Dashboard"
           self.navigationController?.navigationBar.barTintColor = UIColor(red: 203/255, green: 8/255, blue: 22/255, alpha: 1.0)
           self.navigationController?.navigationBar.tintColor = .white
           self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
           self.navigationController?.navigationBar.isTranslucent = false
           self.navigationController?.view.backgroundColor = .white
              
       UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.gray], for:[])


            
       }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view1.layer.masksToBounds = false
        view1.layer.shadowColor = UIColor.black.cgColor
        view1.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        view1.layer.shadowOpacity = 0.5
        
        
        view2.layer.masksToBounds = false
        view2.layer.shadowColor = UIColor.black.cgColor
        view2.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        view2.layer.shadowOpacity = 0.5
        
        view3.layer.masksToBounds = false
        view3.layer.shadowColor = UIColor.black.cgColor
        view3.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        view3.layer.shadowOpacity = 0.5
        
        view4.layer.masksToBounds = false
        view4.layer.shadowColor = UIColor.black.cgColor
        view4.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        view4.layer.shadowOpacity = 0.5
        
        view5.layer.masksToBounds = false
        view5.layer.shadowColor = UIColor.black.cgColor
        view5.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        view5.layer.shadowOpacity = 0.5
        
        view6.layer.masksToBounds = false
        view6.layer.shadowColor = UIColor.black.cgColor
        view6.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        view6.layer.shadowOpacity = 0.5
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

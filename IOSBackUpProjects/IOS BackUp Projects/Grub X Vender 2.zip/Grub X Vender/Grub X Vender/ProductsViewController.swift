//
//  ProductsViewController.swift
//  Grub X Vender
//
//  Created by MAD-MAC on 31/01/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import UIKit

class ProductsViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
   
    

    @IBOutlet weak var collection: UICollectionView!
    
    @IBOutlet weak var sideMenuBtn: UIBarButtonItem!
    
    var imageArray = [#imageLiteral(resourceName: "Buyer-details_0001_Layer-11"),#imageLiteral(resourceName: "Buyer-details_0000_Layer-10"),#imageLiteral(resourceName: "Buyer-details_0001_Layer-11"),#imageLiteral(resourceName: "Buyer-details_0000_Layer-10"),#imageLiteral(resourceName: "Buyer-details_0001_Layer-11"),#imageLiteral(resourceName: "Buyer-details_0000_Layer-10"),#imageLiteral(resourceName: "Buyer-details_0001_Layer-11"),#imageLiteral(resourceName: "Buyer-details_0000_Layer-10"),#imageLiteral(resourceName: "Buyer-details_0001_Layer-11"),#imageLiteral(resourceName: "Buyer-details_0000_Layer-10"),#imageLiteral(resourceName: "Buyer-details_0001_Layer-11"),#imageLiteral(resourceName: "Buyer-details_0000_Layer-10")]
    
    var namesArray = ["Iced Tea,Brisk","Cidre,Apple","Iced Tea,Brisk","Cidre,Apple","Iced Tea,Brisk","Cidre,Apple","Iced Tea,Brisk","Cidre,Apple","Iced Tea,Brisk","Cidre,Apple","Iced Tea,Brisk","Cidre,Apple"]
    var priceArray = ["₹ 300.00","₹150.00","₹ 300.00","₹150.00","₹ 300.00","₹150.00","₹ 300.00","₹150.00","₹ 300.00","₹150.00","₹ 300.00","₹150.00"]
    var ActualPriceArray = ["320","160","320","160","320","160","320","160","320","160","320","160"]
    
    var product = String()
    
    override func viewWillAppear(_ animated: Bool) {
              

        if product == "1" {
        
            self.sideMenuBtn.isEnabled = false
            self.sideMenuBtn.tintColor = UIColor.clear
            let imgBack = UIImage(named: "Grub-X_0054_left-arrow")
                       
            navigationController?.navigationBar.backIndicatorImage = imgBack
            navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
                       
            navigationItem.leftItemsSupplementBackButton = true
            navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
                       
          
        }
        
         self.navigationController?.isNavigationBarHidden = false
         self.tabBarController?.tabBar.isHidden = false
      //   scrollViewDidEndDecelerating(collection)
     // self.navigationItem.title = "Dashboard"
         self.navigationController?.navigationBar.barTintColor = UIColor(red: 203/255, green: 8/255, blue: 22/255, alpha: 1.0)
         self.navigationController?.navigationBar.tintColor = .white
         self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
         self.navigationController?.navigationBar.isTranslucent = false
         self.navigationController?.view.backgroundColor = .white
            
     UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.gray], for:[])


          
     }
        
     
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.

    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArray.count
    
    }
       
     
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ProductsCollectionViewCell
                   
                    
        cell.cellImage.image = imageArray[indexPath.row]
        cell.productName.text = namesArray[indexPath.row]
        cell.productCost.text = priceArray[indexPath.row]
        cell.productActualCost.text = ActualPriceArray[indexPath.row]
        cell.cellView.layer.cornerRadius = 10
                  
        return cell
      
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {

            let cellWidth: CGFloat = 130 // Your cell width

            let numberOfCells = floor(view.frame.size.width / cellWidth)
            let edgeInsets = (view.frame.size.width - (numberOfCells * cellWidth)) / (numberOfCells + 1)

         return UIEdgeInsets(top: 0, left: edgeInsets, bottom: 0, right: edgeInsets)
      
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

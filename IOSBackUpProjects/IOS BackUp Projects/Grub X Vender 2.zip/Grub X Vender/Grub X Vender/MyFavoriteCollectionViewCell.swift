//
//  MyFavoriteCollectionViewCell.swift
//  Grub X Vender
//
//  Created by Shreyash Shriyam on 02/02/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import UIKit

class MyFavoriteCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellView: UIView!
    
    
    @IBOutlet weak var nameLbl: UILabel!
    
    @IBOutlet weak var nameLbl2: UILabel!
    
 
    @IBOutlet weak var activeLbl: UILabel!
    
    @IBOutlet weak var contactBtn: UIButton!
}

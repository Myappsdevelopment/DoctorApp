//
//  HomePageViewController.swift
//  Grub X Vender
//
//  Created by Ashish dattu on 25/01/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import UIKit


class HomePageViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UITableViewDelegate,UITableViewDataSource {
 

  
    
    @IBOutlet weak var pageCount: UIPageControl!
    @IBOutlet weak var collection: UICollectionView!
    @IBOutlet weak var pendingBtn: UIButton!
    @IBOutlet weak var pendingView: UIView!
    @IBOutlet weak var upcomingBtn: UIButton!
    @IBOutlet weak var upcomingView: UIView!
    @IBOutlet weak var completedBtn: UIButton!
    @IBOutlet weak var completedView: UIView!
    @IBOutlet weak var poolOrderBtn: UIButton!
    @IBOutlet weak var poolOrderView: UIView!
    @IBOutlet weak var zipCodeStackView: UIStackView!
    @IBOutlet weak var table: UITableView!
    
    @IBOutlet weak var zipcodeHeight: NSLayoutConstraint!
    
      var limit = 0
      var x: Int = 0
      var strIndex:Int = 1
    
    var imageArray = [#imageLiteral(resourceName: "35"),#imageLiteral(resourceName: "35"),#imageLiteral(resourceName: "35")]
    
    var upComing:Bool?
    var pending:Bool?
    var completed:Bool?
    var poolOrder:Bool?
    
    let grayColour = UIColor(red: 143.0/255.0, green: 143.0/255.0, blue: 143.0/255.0, alpha: 1.0)
    let redColour = UIColor(red: 203.0/255.0, green: 8.0/255.0, blue: 22.0/255.0, alpha: 1.0)
    
    
    override func viewWillAppear(_ animated: Bool) {
          
        
          
          self.navigationController?.isNavigationBarHidden = false
          self.tabBarController?.tabBar.isHidden = false
          scrollViewDidEndDecelerating(collection)
         // self.navigationItem.title = "Dashboard"
          self.navigationController?.navigationBar.barTintColor = UIColor(red: 203/255, green: 8/255, blue: 22/255, alpha: 1.0)
          self.navigationController?.navigationBar.tintColor = .white
          self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
          self.navigationController?.navigationBar.isTranslucent = false
          self.navigationController?.view.backgroundColor = .white
        
          UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.gray], for:[])


      }
    
    override func viewDidLoad() {
        super.viewDidLoad()
      

        let floawLayout = UPCarouselFlowLayout()
        floawLayout.itemSize = CGSize(width: UIScreen.main.bounds.size.width, height: collection.frame.size.height)
        floawLayout.scrollDirection = .horizontal
     
        floawLayout.sideItemScale = 1.0
        collection.collectionViewLayout = floawLayout
      
        collection.isPagingEnabled = true
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func pendingBtn(_ sender: Any) {
       
        pending = true
        self.table.reloadData()
        pendingBtn.setTitleColor(redColour, for: [])
        self.pendingView.backgroundColor = redColour
        upcomingBtn.setTitleColor(grayColour, for: [])
        self.upcomingView.backgroundColor = grayColour
        completedBtn.setTitleColor(grayColour, for: [])
        self.completedView.backgroundColor = grayColour
        poolOrderBtn.setTitleColor(grayColour, for: [])
        self.poolOrderView.backgroundColor = grayColour
        
        
    }
    
    
    
    @IBAction func upcomingBtn(_ sender: Any) {
        
        upComing = true
        self.table.reloadData()
        
        pendingBtn.setTitleColor(grayColour, for: [])
        self.pendingView.backgroundColor = grayColour
        upcomingBtn.setTitleColor(redColour, for: [])
        self.upcomingView.backgroundColor = redColour
        completedBtn.setTitleColor(grayColour, for: [])
        self.completedView.backgroundColor = grayColour
        poolOrderBtn.setTitleColor(grayColour, for: [])
        self.poolOrderView.backgroundColor = grayColour
        
    }
    
    
    
    @IBAction func completedBtn(_ sender: Any) {
       
        completed = true
        self.table.reloadData()
        pendingBtn.setTitleColor(grayColour, for: [])
        self.pendingView.backgroundColor = grayColour
        upcomingBtn.setTitleColor(grayColour, for: [])
        self.upcomingView.backgroundColor = grayColour
        completedBtn.setTitleColor(redColour, for: [])
        self.completedView.backgroundColor = redColour
        poolOrderBtn.setTitleColor(grayColour, for: [])
        self.poolOrderView.backgroundColor = grayColour
    }
    
    
    @IBAction func poolOrderBtn(_ sender: Any) {
      
        poolOrder = true
        self.table.reloadData()
        pendingBtn.setTitleColor(grayColour, for: [])
        self.pendingView.backgroundColor = grayColour
        upcomingBtn.setTitleColor(grayColour, for: [])
        self.upcomingView.backgroundColor = grayColour
        completedBtn.setTitleColor(grayColour, for: [])
        self.completedView.backgroundColor = grayColour
        poolOrderBtn.setTitleColor(redColour, for: [])
        self.poolOrderView.backgroundColor = redColour
    }
    
    
    
    @IBAction func bellBtn(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "MessagesAndNotificationsViewController") as! MessagesAndNotificationsViewController
                            
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
    
    
    
      func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
      
          pageCount.numberOfPages = 3
          return 3
      }
      
      func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
          
     
          let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! HomePageCollectionViewCell
         
            cell.cellImage.image = imageArray[indexPath.row]
        
     
    
          return cell
      }
    
    

      
      func scrollViewDidScroll(_ scrollView: UIScrollView) {
          let offSet = scrollView.contentOffset.x
          print(offSet)
          let width = collection.frame.width
        let horizontalCenter = collection.frame.size.width / 2
          
          
         pageCount.currentPage = Int(offSet + horizontalCenter) / Int(width)
          print(pageCount.currentPage)
          
         
        
      }
      
      func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
          
          return CGSize(width:collection.frame.width, height: collection.frame.height)
          
          
      }
    
      func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
      {
          var visibleRect = CGRect()
        print(visibleRect)

          visibleRect.origin = collection.contentOffset
          visibleRect.size =  collection.bounds.size
          let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
          print(visiblePoint)
          guard let indexPath =  collection.indexPathForItem(at: visiblePoint) else { return }

          x = indexPath.row

         
          strIndex = indexPath.row
      

          let indexPathrow = IndexPath(item: x, section: 0)
          self.collection.scrollToItem(at: indexPathrow, at: .centeredHorizontally, animated: true)

      }
      
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return 3
     }
     
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! HomePageTableViewCell
        
        if pending == true || completed == true{
           
            cell.rejectStackView.isHidden = true
            cell.messageStackView.isHidden = false
            cell.acceptStackView.isHidden = true
            cell.trackStackView.isHidden = false
            cell.DeliveryLocationStackView.isHidden = false
            cell.itemNameLbl.text = "ITEM NAME"
            cell.itemNameValueLbl.text = "Iced Tea,Brisk"
       
        }else if upComing == true {
          
            cell.rejectStackView.isHidden = false
            cell.messageStackView.isHidden = false
            cell.acceptStackView.isHidden = false
            cell.trackStackView.isHidden = true
            cell.DeliveryLocationStackView.isHidden = false
            cell.itemNameLbl.text = "ITEM NAME"
            cell.itemNameValueLbl.text = "Iced Tea,Brisk"
       
        }else if poolOrder == true {
          
            cell.itemNameLbl.text = "ORDER DATE"
            cell.itemNameValueLbl.text = "November 25"
            cell.DeliveryLocationStackView.isHidden = true
            cell.rejectStackView.isHidden = false
            cell.messageStackView.isHidden = true
            cell.acceptStackView.isHidden = true
            cell.trackStackView.isHidden = true
       
        }else{
          
            cell.rejectStackView.isHidden = true
            cell.messageStackView.isHidden = false
            cell.acceptStackView.isHidden = true
            cell.trackStackView.isHidden = false
            cell.DeliveryLocationStackView.isHidden = false
            cell.itemNameLbl.text = "ITEM NAME"
            cell.itemNameValueLbl.text = "Iced Tea,Brisk"
       
        }
        
        return cell
     }
     

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

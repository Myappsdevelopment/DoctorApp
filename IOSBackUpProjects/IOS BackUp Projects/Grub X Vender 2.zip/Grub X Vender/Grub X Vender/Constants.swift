//
//  Constants.swift
//  Grub X Vender
//
//  Created by vamsikrishna on 24/01/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import Foundation

struct Bools {
  static  var business:Bool?
}


//
//  TabBar4CollectionViewCell.swift
//  Grub X Vender
//
//  Created by MAD-MAC on 31/01/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import UIKit

class TabBar4CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImage: UIImageView!
}

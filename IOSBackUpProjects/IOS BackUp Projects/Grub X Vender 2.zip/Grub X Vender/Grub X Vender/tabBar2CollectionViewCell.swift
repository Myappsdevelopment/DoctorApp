//
//  tabBar2CollectionViewCell.swift
//  Grub X Vender
//
//  Created by MAD-MAC on 29/01/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import UIKit

class tabBar2CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImage: UIImageView!
    
}

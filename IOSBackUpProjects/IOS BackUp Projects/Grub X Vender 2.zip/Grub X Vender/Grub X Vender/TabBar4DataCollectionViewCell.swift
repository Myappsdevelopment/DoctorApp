//
//  TabBar4DataCollectionViewCell.swift
//  Grub X Vender
//
//  Created by MAD-MAC on 31/01/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import UIKit

class TabBar4DataCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var cellView: UIView!
    
    @IBOutlet weak var ActiveLabel: UILabel!
    
    
    @IBOutlet weak var cellImage: UIImageView!
    
    @IBOutlet weak var nameLbl: UILabel!
    
    @IBOutlet weak var NameLbl2: UILabel!


    @IBOutlet weak var contactBtn: UIButton!
}

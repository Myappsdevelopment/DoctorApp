//
//  SideMenuTableViewCell.swift
//  Grub X Vender
//
//  Created by vamsikrishna on 25/01/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import UIKit

class SideMenuTableViewCell: UITableViewCell {

    @IBOutlet weak var namesLbl: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

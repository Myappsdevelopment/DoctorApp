//
//  AddBusinessViewController.swift
//  Grub X
//
//  Created by MAD-MAC on 10/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit

class AddBusinessViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
  
    

    @IBOutlet weak var tableData: UITableView!
    
    @IBOutlet weak var sidemenuBtn: UIBarButtonItem!
    var name1Array = ["Business Name","Business Owner Name","Business Address","Served Business Goods"]
    var name2Array = ["SR Stocking","Albert Dex","Alberta Street 08","Meat,Beverage,Food"]
    
    var business = String()
    
    var name3Array = ["Minimum Rupees Required For Pooling","Pooling Available only"]
    var name4Array = ["15000","Canada,Alberts State"]
    
    var name5Array = ["Primary DashBoard","Scondary DashBoard","Activity Shown"]
    var name6Array = ["Sales","Orders,Buyers,Products","One Week"]
    
    override func viewWillAppear(_ animated: Bool) {
     
       
        if business == "2" || business == "3" {
            self.sidemenuBtn.isEnabled = false
            self.sidemenuBtn.tintColor = UIColor.clear
            let imgBack = UIImage(named: "Grub-X_0054_left-arrow")
                   
            navigationController?.navigationBar.backIndicatorImage = imgBack
            navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
                   
            navigationItem.leftItemsSupplementBackButton = true
            navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
                   
        }
        
        
        
        self.navigationController?.isNavigationBarHidden = false
        
        
        // self.navigationItem.title = "Dashboard"
         self.navigationController?.navigationBar.barTintColor = UIColor(red: 203/255, green: 8/255, blue: 22/255, alpha: 1.0)
       
         self.navigationController?.navigationBar.tintColor = .white
         self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
         self.navigationController?.navigationBar.isTranslucent = false
         self.navigationController?.view.backgroundColor = .white
       
    UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.gray], for:[])


     }
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        if business == "1" {
            return name1Array.count
        }else if business == "2"{
            return name3Array.count
        }else{
            return name5Array.count
        }
      }
      
      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! AddBusinessTableViewCell
        
        if business == "1" {
        
            cell.name1.text = name1Array[indexPath.row]
            cell.name2.text = name2Array[indexPath.row]
        
        }else if business == "2" {
            cell.name1.text = name3Array[indexPath.row]
            cell.name2.text = name4Array[indexPath.row]
        }else{
            cell.name1.text = name5Array[indexPath.row]
            cell.name2.text = name6Array[indexPath.row]
        }
        return cell
      }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

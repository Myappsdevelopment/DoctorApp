//
//  TabBar4ViewController.swift
//  Grub X Vender
//
//  Created by Ashish dattu on 25/01/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import UIKit

class TabBar4ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var collection: UICollectionView!
    @IBOutlet weak var pageCount: UIPageControl!
    @IBOutlet weak var collection2: UICollectionView!
    @IBOutlet weak var buyerBtn: UIButton!
    @IBOutlet weak var buyerView: UIView!
    @IBOutlet weak var topBuyerBtn: UIButton!
    @IBOutlet weak var topBuyerView: UIView!
    
    
    
    var limit = 0
    var x: Int = 0
    var strIndex:Int = 1
    
     var imageArray = [#imageLiteral(resourceName: "35"),#imageLiteral(resourceName: "35"),#imageLiteral(resourceName: "35")]
    
     let grayColour = UIColor(red: 143.0/255.0, green: 143.0/255.0, blue: 143.0/255.0, alpha: 1.0)
     let redColour = UIColor(red: 203.0/255.0, green: 8.0/255.0, blue: 22.0/255.0, alpha: 1.0)
     
    
    override func viewWillAppear(_ animated: Bool) {
             
           
             
           
        self.navigationController?.isNavigationBarHidden = false
        self.tabBarController?.tabBar.isHidden = false
        scrollViewDidEndDecelerating(collection)
    // self.navigationItem.title = "Dashboard"
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 203/255, green: 8/255, blue: 22/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white
           
    UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.gray], for:[])


         
    }
       
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let floawLayout = UPCarouselFlowLayout()
        floawLayout.itemSize = CGSize(width: UIScreen.main.bounds.size.width, height: collection.frame.size.height)
        floawLayout.scrollDirection = .horizontal
           
        floawLayout.sideItemScale = 1.0
        collection.collectionViewLayout = floawLayout
            
        collection.isPagingEnabled = true
        
        // Do any additional setup after loading the view.
    }
    

    @IBAction func buyerBtn(_ sender: Any) {
        
        buyerBtn.setTitleColor(redColour, for: [])
        self.buyerView.backgroundColor = redColour
        topBuyerBtn.setTitleColor(grayColour, for: [])
        self.topBuyerView.backgroundColor = grayColour
        self.collection2.reloadData()
    }
    
    
    @IBAction func topBuyerBtn(_ sender: Any) {
        
        buyerBtn.setTitleColor(grayColour, for: [])
        self.buyerView.backgroundColor = grayColour
        topBuyerBtn.setTitleColor(redColour, for: [])
        self.topBuyerView.backgroundColor = redColour
        self.collection2.reloadData()
        
        
    }
    
    @IBAction func bellBtn(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "MessagesAndNotificationsViewController") as! MessagesAndNotificationsViewController
                            
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == collection {
            pageCount.numberOfPages = 3
            return 3
        }else{
            return 12
        }
          
      }
      
      func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
          
     
        if collectionView == collection {
          let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! TabBar4CollectionViewCell
         
            cell.cellImage.image = imageArray[indexPath.row]
        
    
          return cell
      
        }else{
          
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! TabBar4DataCollectionViewCell
                 
             cell.ActiveLabel.transform = CGAffineTransform(rotationAngle: CGFloat(Double(-45) * .pi/180))
            cell.cellView.layer.cornerRadius = 10
            cell.contactBtn.layer.cornerRadius = 10
            
            return cell
        }
      }
    
    

      
      func scrollViewDidScroll(_ scrollView: UIScrollView) {
          let offSet = scrollView.contentOffset.x
          print(offSet)
          let width = collection.frame.width
        let horizontalCenter = collection.frame.size.width / 2
          
          
         pageCount.currentPage = Int(offSet + horizontalCenter) / Int(width)
          print(pageCount.currentPage)
          
         
        
      }
      
      func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
          
          return CGSize(width:collection.frame.width, height: collection.frame.height)
          
          
      }
    
      func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
      {
          var visibleRect = CGRect()
        print(visibleRect)

          visibleRect.origin = collection.contentOffset
          visibleRect.size =  collection.bounds.size
          let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
          print(visiblePoint)
          guard let indexPath =  collection.indexPathForItem(at: visiblePoint) else { return }

          x = indexPath.row

         
          strIndex = indexPath.row
      

          let indexPathrow = IndexPath(item: x, section: 0)
          self.collection.scrollToItem(at: indexPathrow, at: .centeredHorizontally, animated: true)

      }
      
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {

         let cellWidth: CGFloat = 130 // Your cell width

         let numberOfCells = floor(view.frame.size.width / cellWidth)
         let edgeInsets = (view.frame.size.width - (numberOfCells * cellWidth)) / (numberOfCells + 1)

      return UIEdgeInsets(top: 0, left: edgeInsets, bottom: 0, right: edgeInsets)
     }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "BuyerDetailsViewController") as! BuyerDetailsViewController
                            
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

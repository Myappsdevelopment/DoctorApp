//
//  LoginViewController.swift
//  Grub X Vender
//
//  Created by vamsikrishna on 22/01/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var requestOtpBtn: UIButton!
  
    @IBOutlet weak var verticalConstraint: NSLayoutConstraint!
    
     let grayColour = UIColor(red: 143.0/255.0, green: 143.0/255.0, blue: 143.0/255.0, alpha: 1.0)

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }
        
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        loginBtn.layer.cornerRadius = 10
        loginBtn.layer.borderWidth = 1
        loginBtn.layer.borderColor = UIColor.gray.cgColor
        
        requestOtpBtn.layer.cornerRadius = 10
        requestOtpBtn.layer.borderWidth = 1
        requestOtpBtn.layer.borderColor = UIColor.gray.cgColor
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func forgotBtn(_ sender: Any) {
        
       let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
       let gotoOTP = storyBoard.instantiateViewController(withIdentifier: "ForgotPasswordViewController") as! ForgotPasswordViewController
        self.navigationController?.pushViewController(gotoOTP, animated: true)
        
        
    }
    
    @IBAction func loginBtn(_ sender: Any) {
    }
    
    
    @IBAction func requestOtpBtn(_ sender: Any) {
        
        let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let gotoOTP = storyBoard.instantiateViewController(withIdentifier: "RequestOTPViewController") as! RequestOTPViewController
        self.navigationController?.pushViewController(gotoOTP, animated: true)
    }
    
    
    @IBAction func faceBookBtn(_ sender: Any) {
    }
    
    @IBAction func gmailBtn(_ sender: Any) {
    }
    @IBAction func createAnAccountBtn(_ sender: Any) {
        
        let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let gotoOTP = storyBoard.instantiateViewController(withIdentifier: "RegisterViewController") as! RegisterViewController
        self.navigationController?.pushViewController(gotoOTP, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

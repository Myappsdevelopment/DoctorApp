//
//  SideMenuViewController.swift
//  Grub X Vender
//
//  Created by Ashish dattu on 25/01/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import UIKit

class SideMenuViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    

    @IBOutlet weak var namesLbl: UILabel!
    
    
    var namesArray = ["Products","Add Products","Business","Add Business","My Favourite","My Account","Special Catalogue","Place Order","Rate Us","About Us","Sign Out"]
    
    override func viewWillAppear(_ animated: Bool) {
    
        self.navigationController?.isNavigationBarHidden = true
      
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return namesArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! SideMenuTableViewCell
        
        cell.namesLbl.text = namesArray[indexPath.row]
        return cell
    }

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            let vc = storyboard?.instantiateViewController(withIdentifier: "ProductsViewController") as! ProductsViewController
                 
            navigationController?.pushViewController(vc, animated: true)
        }else if indexPath.row == 1 {
            let vc = storyboard?.instantiateViewController(withIdentifier: "AddProductViewController") as! AddProductViewController
                            
            navigationController?.pushViewController(vc, animated: true)
        }else if indexPath.row == 2 {
            let vc = storyboard?.instantiateViewController(withIdentifier: "SwitchViewController") as! SwitchViewController
                            
            navigationController?.pushViewController(vc, animated: true)
        }else if indexPath.row == 3 {
            let vc = storyboard?.instantiateViewController(withIdentifier: "AddBusinessViewController") as! AddBusinessViewController
            vc.business = "1"
            navigationController?.pushViewController(vc, animated: true)
        }else if indexPath.row == 4 {
            let vc = storyboard?.instantiateViewController(withIdentifier: "MyFavoriteViewController") as! MyFavoriteViewController
                            
            navigationController?.pushViewController(vc, animated: true)
        }else if indexPath.row == 5 {
            let vc = storyboard?.instantiateViewController(withIdentifier: "ProfileViewController") as! ProfileViewController
                            
            navigationController?.pushViewController(vc, animated: true)
        }else if indexPath.row == 6 {
            let vc = storyboard?.instantiateViewController(withIdentifier: "CatalogueViewController") as! CatalogueViewController
                            
            navigationController?.pushViewController(vc, animated: true)
        }else if indexPath.row == 10 {
            
            let alert = UIAlertController(title: "LOGOUT", message: "Are you sure,you want to exit?", preferredStyle: .alert)
                   
                   
            alert.addAction(UIAlertAction(title: "Yes", style: .cancel, handler: { (confirmAction) in
                   
            UserDefaults.standard.removePersistentDomain(forName:Bundle.main.bundleIdentifier!)
                           UserDefaults.standard.synchronize()
                   
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController")
                   
            self.navigationController?.pushViewController(vc!, animated: true)
                   
                       //SingleToneClass.shared.dismissProgressLoadingWithSucess(message: "LogOut Successful")
                   
                           //SingleToneClass.shared.dismissProgressLoading(WithDelay: 5)
                   
            }))
                   
            alert.addAction(UIAlertAction(title: "No", style: .default, handler: { (cancelAction) in }))
                   
            present(alert, animated: true, completion: nil)
        }
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  HomePageCollectionViewCell.swift
//  Grub X Vender
//
//  Created by vamsikrishna on 26/01/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import UIKit

class HomePageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImage: UIImageView!
}

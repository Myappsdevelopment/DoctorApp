//
//  ProfileViewController.swift
//  Grub X
//
//  Created by MAD-MAC on 03/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

    
    override func viewWillAppear(_ animated: Bool) {
        
         self.navigationController?.isNavigationBarHidden = false
         self.navigationItem.title = "Dashboard"
         self.navigationController?.navigationBar.barTintColor = UIColor(red: 203/255, green: 8/255, blue: 22/255, alpha: 1.0)
        // self.tabBarController?.tabBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
         self.navigationController?.navigationBar.tintColor = .white
         self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
         self.navigationController?.navigationBar.isTranslucent = false
         self.navigationController?.view.backgroundColor = .white
       
      //  SingleToneClass.shared.showProgressLoading(title: "Please Wait")

     }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

   

    
    
    @IBAction func profileBtn(_ sender: Any) {
            
        let vc = storyboard?.instantiateViewController(withIdentifier: "AccountInformationViewController") as! AccountInformationViewController
        
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    
    @IBAction func notificationsBtn(_ sender: Any) {
       
        let vc = storyboard?.instantiateViewController(withIdentifier: "MessagesAndNotificationsViewController") as! MessagesAndNotificationsViewController
                            
        navigationController?.pushViewController(vc, animated: true)
      
    }
    
    
    @IBAction func changePasswordBtn(_ sender: Any) {
     
        let vc = storyboard?.instantiateViewController(withIdentifier: "ChangePasswordViewController") as! ChangePasswordViewController
                     
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    
    @IBAction func poolSettingsBtn(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "AddBusinessViewController") as! AddBusinessViewController
        vc.business = "2"
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func dashBoardSettingsBtn(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "AddBusinessViewController") as! AddBusinessViewController
        vc.business = "3"
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func settingsBtn(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController") as! NotificationsViewController
                     
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    
    @IBAction func signOutBtn(_ sender: Any) {
        
              
        let alert = UIAlertController(title: "LOGOUT", message: "Are you sure,you want to exit?", preferredStyle: .alert)
        
        
        alert.addAction(UIAlertAction(title: "Yes", style: .cancel, handler: { (confirmAction) in
        
        UserDefaults.standard.removePersistentDomain(forName:Bundle.main.bundleIdentifier!)
                UserDefaults.standard.synchronize()
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController")
        
        self.navigationController?.pushViewController(vc!, animated: true)
        
            //SingleToneClass.shared.dismissProgressLoadingWithSucess(message: "LogOut Successful")
        
                //SingleToneClass.shared.dismissProgressLoading(WithDelay: 5)
        
        }))
        
        alert.addAction(UIAlertAction(title: "No", style: .default, handler: { (cancelAction) in }))
        
        present(alert, animated: true, completion: nil)
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

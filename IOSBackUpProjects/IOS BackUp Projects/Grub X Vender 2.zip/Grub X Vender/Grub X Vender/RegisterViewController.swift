//
//  RegisterViewController.swift
//  Grub X Vender
//
//  Created by vamsikrishna on 23/01/20.
//  Copyright © 2020 Mahesh. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {

    
    override func viewWillAppear(_ animated: Bool) {
       
         
        self.navigationController?.isNavigationBarHidden = true
        self.tabBarController?.tabBar.isHidden = false
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 203/255, green: 8/255, blue: 22/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white
    
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func registerBtn(_ sender: Any) {
        
//        let vc = self.storyboard?.instantiateViewController(identifier: "HomePageViewController") as! HomePageViewController
//        self.present(vc, animated:true, completion:nil)
//
        
    }
    

}

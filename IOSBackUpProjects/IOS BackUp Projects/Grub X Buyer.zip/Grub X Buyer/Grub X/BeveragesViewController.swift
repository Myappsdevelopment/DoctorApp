//
//  BeveragesViewController.swift
//  Grub X
//
//  Created by MAD-MAC on 08/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit

class BeveragesViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
   
    

    
    @IBOutlet weak var collectionData: UICollectionView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
           return 30
       
    }
       
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! BeveragesProductsCollectionViewCell
        cell.percentageLbl.transform = CGAffineTransform(rotationAngle: CGFloat(Double(-45) * .pi/180))
       //  ourView.transform = CGAffineTransform(rotationAngle: CGFloat(Double(-45) * .pi/180))
        return cell
       
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {

          let cellWidth: CGFloat = 150 // Your cell width

          let numberOfCells = floor(view.frame.size.width / cellWidth)
          let edgeInsets = (view.frame.size.width - (numberOfCells * cellWidth)) / (numberOfCells + 2)

       return UIEdgeInsets(top: 0, left: edgeInsets, bottom: 0, right: edgeInsets)
      }
    
      
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
        navigationController?.pushViewController(vc, animated: true)
        
    }
        
       
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

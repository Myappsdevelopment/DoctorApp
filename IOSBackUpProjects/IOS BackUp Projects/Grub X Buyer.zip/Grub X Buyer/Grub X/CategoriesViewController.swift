//
//  CategoriesViewController.swift
//  Grub X
//
//  Created by MAD-MAC on 03/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit

class CategoriesViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
   
    
    var imageArray = [#imageLiteral(resourceName: "Categories_0000_Layer-1"),#imageLiteral(resourceName: "Categories_0001_Layer-2"),#imageLiteral(resourceName: "Categories_0002_Layer-3"),#imageLiteral(resourceName: "Categories_0003_Layer-4"),#imageLiteral(resourceName: "Categories_0004_Layer-5"),#imageLiteral(resourceName: "Categories_0005_Layer-6"),#imageLiteral(resourceName: "Categories_0006_Layer-7"),#imageLiteral(resourceName: "Screenshot 2020-01-08 at 11.46.26 AM")]
    var imageNamesArray = ["Baked Goods,Swets","Meat & poultry","Beverages & Drinks","Food","Restaurant Supplies","Sea Food","Cleaning Supplies","OTHERS"]
    var productNamesArray = ["1245 products","11 Products","245 products","859 products","45 products","259 products","15 products","859 products"]
   
    
    @IBOutlet weak var collections: UICollectionView!
    
    
    override func viewWillAppear(_ animated: Bool) {
         
        self.navigationController?.isNavigationBarHidden = false
        
         self.navigationItem.title = "Beverages"
         self.navigationController?.navigationBar.barTintColor = UIColor(red: 203/255, green: 8/255, blue: 22/255, alpha: 1.0)
         
         self.navigationController?.navigationBar.tintColor = .white
         self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
         self.navigationController?.navigationBar.isTranslucent = false
         self.navigationController?.view.backgroundColor = .white
       
    

     }
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
          tabBarController?.selectedIndex = 2
        // Do any additional setup after loading the view.
    }
    

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArray.count
       }
       
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CategoriesCollectionViewCell
        
        cell.displayImage.image = imageArray[indexPath.row]
        cell.imageName.text = imageNamesArray[indexPath.row]
        cell.productName.text = productNamesArray[indexPath.row]
        cell.layer.borderColor = UIColor.black.cgColor
        cell.layer.borderWidth = 1
        cell.layer.cornerRadius = 10
   
        return cell
        
       }
    
    
   func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {

       let cellWidth: CGFloat = 150 // Your cell width

       let numberOfCells = floor(view.frame.size.width / cellWidth)
       let edgeInsets = (view.frame.size.width - (numberOfCells * cellWidth)) / (numberOfCells + 1)

    return UIEdgeInsets(top: 0, left: edgeInsets, bottom: 0, right: edgeInsets)
   }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
           
           let vc = storyboard?.instantiateViewController(withIdentifier: "BeveragesViewController") as! BeveragesViewController
           navigationController?.pushViewController(vc, animated: true)
           
       }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

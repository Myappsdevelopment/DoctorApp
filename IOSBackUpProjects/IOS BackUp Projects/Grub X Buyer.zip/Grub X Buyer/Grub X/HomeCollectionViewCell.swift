//
//  HomeCollectionViewCell.swift
//  Grub X
//
//  Created by MAD-MAC on 07/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {
  
    
    @IBOutlet weak var cellImage: UIImageView!
    @IBOutlet weak var itemName: UILabel!
    @IBOutlet weak var ItemCost: UILabel!
    @IBOutlet weak var minusBtn: UIButton!
    @IBOutlet weak var plusBtn2: UIButton!
   
    @IBOutlet weak var itemCountLbl: UILabel!
    
    @IBOutlet weak var addBtn: UIButton!
    @IBOutlet weak var plusMinusStack: UIStackView!
    
}

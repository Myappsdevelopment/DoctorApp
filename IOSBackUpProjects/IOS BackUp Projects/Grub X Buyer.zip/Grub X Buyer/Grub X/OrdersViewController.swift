//
//  OrdersViewController.swift
//  Grub X
//
//  Created by MAD-MAC on 09/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit

class OrdersViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    

    
    
    
    @IBOutlet weak var onGoingBtn: UIButton!
    @IBOutlet weak var onGngView: UIView!
    
    @IBOutlet weak var poolOrdersBtn: UIButton!
    @IBOutlet weak var poolOrdersView: UIView!
    
    @IBOutlet weak var pastOrdersBtn: UIButton!
    @IBOutlet weak var pastOrdersView: UIView!
    
    @IBOutlet weak var tableData: UITableView!
    
    
    var imageArray = [UIImage]()
    
    
    let grayColour = UIColor(red: 143.0/255.0, green: 143.0/255.0, blue: 143.0/255.0, alpha: 1.0)
    let redColour = UIColor(red: 203.0/255.0, green: 8.0/255.0, blue: 22.0/255.0, alpha: 1.0)
    
    
    override func viewWillAppear(_ animated: Bool) {
      
          self.navigationController?.isNavigationBarHidden = false
          self.tabBarController?.tabBar.isHidden = false
         
         // self.navigationItem.title = "Dashboard"
          self.navigationController?.navigationBar.barTintColor = UIColor(red: 203/255, green: 8/255, blue: 22/255, alpha: 1.0)
        
          self.navigationController?.navigationBar.tintColor = .white
          self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
          self.navigationController?.navigationBar.isTranslucent = false
          self.navigationController?.view.backgroundColor = .white
        
     UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.gray], for:[])


      }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        imageArray = [#imageLiteral(resourceName: "Buyer-details_0001_Layer-11"),#imageLiteral(resourceName: "Buyer-details_0000_Layer-10")]
        
        // Do any additional setup after loading the view.
    }
    

    
    @IBAction func onGngBtn(_ sender: Any) {
        
        onGoingBtn.setTitleColor(redColour, for: [])
        poolOrdersBtn.setTitleColor(grayColour, for: [])
        pastOrdersBtn.setTitleColor(grayColour, for: [])
        onGngView.backgroundColor = redColour
        poolOrdersView.backgroundColor = grayColour
        pastOrdersView.backgroundColor = grayColour
         imageArray = [#imageLiteral(resourceName: "Buyer-details_0001_Layer-11"),#imageLiteral(resourceName: "Buyer-details_0000_Layer-10")]
        self.tableData.reloadData()
        
        
    }
    
    
    
    @IBAction func poolOrdersBtn(_ sender: Any) {
        
        onGoingBtn.setTitleColor(grayColour, for: [])
        poolOrdersBtn.setTitleColor(redColour, for: [])
        pastOrdersBtn.setTitleColor(grayColour, for: [])
        onGngView.backgroundColor = grayColour
        poolOrdersView.backgroundColor = redColour
        pastOrdersView.backgroundColor = grayColour
        imageArray = [#imageLiteral(resourceName: "Buyer-details_0001_Layer-11")]
        self.tableData.reloadData()
        
    }
    
    
    @IBAction func pastOrdersBtn(_ sender: Any) {
        
        onGoingBtn.setTitleColor(grayColour, for: [])
        poolOrdersBtn.setTitleColor(grayColour, for: [])
        pastOrdersBtn.setTitleColor(redColour, for: [])
        onGngView.backgroundColor = grayColour
        poolOrdersView.backgroundColor = grayColour
        pastOrdersView.backgroundColor = redColour
        imageArray = [#imageLiteral(resourceName: "Buyer-details_0001_Layer-11"),#imageLiteral(resourceName: "Buyer-details_0000_Layer-10")]
        self.tableData.reloadData()
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return imageArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! OrdersTableViewCell
              
        cell.ImageDisplay.image = imageArray[indexPath.row]
        cell.cellMainView.layer.cornerRadius = 10
        cell.cellSubView.layer.cornerRadius = 10
        
              return cell
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

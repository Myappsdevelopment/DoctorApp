//
//  Home2CollectionViewCell.swift
//  Grub X
//
//  Created by MAD-MAC on 09/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit

class Home2CollectionViewCell: UICollectionViewCell {
    
}

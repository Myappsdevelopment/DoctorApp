//
//  HomeViewController.swift
//  Grub X
//
//  Created by MAD-MAC on 03/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource{
   
    

  
    
    @IBOutlet weak var pendingView: UIView!
    @IBOutlet weak var completedView: UIView!
    @IBOutlet weak var orderLbl: UILabel!
    @IBOutlet weak var orderLbl2: UILabel!
    @IBOutlet weak var orderLbl3: UILabel!
    @IBOutlet weak var deliveryImage: UIImageView!
    @IBOutlet weak var pendingBtn: UIButton!
    @IBOutlet weak var completdBtn: UIButton!
    
    @IBOutlet weak var collectionData: UICollectionView!
    
    var selectedIndex: Int = -1
    var selectedIndex1: Int = -1
    
    let unselectedColor = UIColor(red: 255.0/255.0, green: 225.0/255.0, blue: 225.0/255.0, alpha: 1.0)
    let grayColour = UIColor(red: 143.0/255.0, green: 143.0/255.0, blue: 143.0/255.0, alpha: 1.0)
    let redColour = UIColor(red: 203.0/255.0, green: 8.0/255.0, blue: 22.0/255.0, alpha: 1.0)
    
    
    var imageArray = [#imageLiteral(resourceName: "Screenshot 2020-01-06 at 6.05.33 PM"),#imageLiteral(resourceName: "Screenshot 2020-01-06 at 6.05.52 PM"),#imageLiteral(resourceName: "Screenshot 2020-01-06 at 6.05.52 PM"),#imageLiteral(resourceName: "Screenshot 2020-01-06 at 6.05.33 PM"),#imageLiteral(resourceName: "Screenshot 2020-01-06 at 6.05.33 PM"),#imageLiteral(resourceName: "Screenshot 2020-01-06 at 6.05.52 PM")]
    var itemNameArray = ["Cidre, Apple","iced Tea, Brisk","iced Tea, Brisk","Cidre, Apple","Cidre, Apple","iced Tea, Brisk"]
    var itemCostArray = ["₹300","₹150","₹150","₹300","₹300","₹150"]
    
    
    override func viewWillAppear(_ animated: Bool) {
         
       
         
         self.navigationController?.isNavigationBarHidden = false
         self.tabBarController?.tabBar.isHidden = false
        
        // self.navigationItem.title = "Dashboard"
         self.navigationController?.navigationBar.barTintColor = UIColor(red: 203/255, green: 8/255, blue: 22/255, alpha: 1.0)
       
         self.navigationController?.navigationBar.tintColor = .white
         self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
         self.navigationController?.navigationBar.isTranslucent = false
         self.navigationController?.view.backgroundColor = .white
       
    UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.gray], for:[])


     }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

 
        
        // Do any additional setup after loading the view.
        
    }
    
    
    @IBAction func pendingBtn(_ sender: Any) {
        
        completdBtn.setTitleColor(grayColour, for: [])
        completedView.backgroundColor = grayColour
        pendingBtn.setTitleColor(redColour, for: [])
        pendingView.backgroundColor = redColour
        orderLbl.text = "XFI0DD147"
        orderLbl2.text = "Currently in transit"
        orderLbl3.text = "Expected Friday,November29"
        deliveryImage.image = UIImage(named: "icons_crop")
        
        
        
    }
    
    
    
    @IBAction func completedBtn(_ sender: Any) {
        
         completdBtn.setTitleColor(redColour, for: [])
         completedView.backgroundColor = redColour
         pendingBtn.setTitleColor(grayColour, for: [])
         pendingView.backgroundColor = grayColour
         orderLbl.text = "XFI0DCB8896"
         orderLbl2.text = "Delivered"
         orderLbl3.text = "Delivered to you Friday,November29"
         deliveryImage.image = UIImage(named: "icons_crop1")
        
    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArray.count
       }
       
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
           
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! HomeCollectionViewCell
                  
        cell.cellImage.image = imageArray[indexPath.row]
        cell.itemName.text = itemNameArray[indexPath.row]
        cell.ItemCost.text = itemCostArray[indexPath.row]
        
        cell.plusBtn2.tag = indexPath.row
        cell.plusBtn2.addTarget(self, action: #selector(self.plusBtnTapped(_:)), for: .touchUpInside)
        
        cell.minusBtn.tag = indexPath.row
        cell.minusBtn.addTarget(self, action: #selector(self.minusBtnTapped(_:)), for: .touchUpInside)
        
        if selectedIndex == indexPath.row {
            cell.minusBtn.isHidden = false
            cell.itemCountLbl.isHidden = false
            cell.addBtn.isHidden = true
           
            cell.itemCountLbl.text = "\(Int(cell.itemCountLbl.text ?? "0")! + 1)"
//        }else{
//
//            cell.itemCountLbl.text = "\(Int(cell.itemCountLbl.text ?? "0")! + 1)"
//
        }
        
        if selectedIndex1 == indexPath.row {
             cell.itemCountLbl.text = "\(Int(cell.itemCountLbl.text ?? "0")! - 1)"
            
            if cell.itemCountLbl.text == "0" {
               cell.minusBtn.isHidden = true
               cell.itemCountLbl.isHidden = true
               cell.addBtn.isHidden = false
            }
            
            
//        }else{
//             cell.itemCountLbl.text = "\(Int(cell.itemCountLbl.text ?? "0")! - 1)"
        }
        
      
        return cell
        
      
        
       }
    

    
      @objc func plusBtnTapped(_ sender: UIButton) {
    

            if self.selectedIndex != sender.tag {
                   self.selectedIndex = sender.tag
               }
               self.collectionData.reloadData()
            
        }
        
        
        @objc func minusBtnTapped(_ sender: UIButton) {
           

            if self.selectedIndex1 == sender.tag {
                    self.selectedIndex1 = sender.tag
                }
                      self.collectionData.reloadData()
                   
        }
               
        
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
        navigationController?.pushViewController(vc, animated: true)
        
    }
        
        
        
        
        


   
      
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

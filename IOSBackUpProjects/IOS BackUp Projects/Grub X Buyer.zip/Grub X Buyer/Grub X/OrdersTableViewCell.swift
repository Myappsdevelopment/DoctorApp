//
//  OrdersTableViewCell.swift
//  Grub X
//
//  Created by MAD-MAC on 10/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit

class OrdersTableViewCell: UITableViewCell {

    
    @IBOutlet weak var cellMainView: UIView!
    
    
    @IBOutlet weak var cellSubView: UIView!
    
    @IBOutlet weak var ImageDisplay: UIImageView!
    
    
    @IBOutlet weak var trackBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

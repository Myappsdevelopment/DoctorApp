//
//  SideMenuViewController.swift
//  Grub X
//
//  Created by MAD-MAC on 03/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit
import SideMenu

class SideMenuViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    
    var sideMenuArray = ["Home","Categories","My Orders","My WishList","Add Business","Switch Business","Rewards","About Us","Invite","Rate Us","Signout"]
    
    

    @IBOutlet weak var table: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

          self.navigationController?.isNavigationBarHidden = true
        // Do any additional setup after loading the view.
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sideMenuArray.count
       }
       
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! SideMenuTableViewCell
        
            cell.namesLbl.text = sideMenuArray[indexPath.row]
        print(cell.namesLbl.text as Any)
            return cell
       }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
       // let menu = SideMenuNavigationController(rootViewController: SideMenuViewController)
         //   let revealViewController: SWRevealViewController = self.revealViewController()
            let cell : SideMenuTableViewCell = tableView.cellForRow(at: indexPath) as! SideMenuTableViewCell
        
            if cell.namesLbl.text == "Home"{
              
              
            let vc = storyboard?.instantiateViewController(withIdentifier: "TabViewController") as! TabViewController
            navigationController?.pushViewController(vc, animated: true)
        
           
            }else if cell.namesLbl.text == "Categories"{
                  
                  
                let vc = storyboard?.instantiateViewController(withIdentifier: "CategoriesViewController") as! CategoriesViewController
                navigationController?.pushViewController(vc, animated: true)
           
                
            }else if cell.namesLbl.text == "My Orders"{
              
              
            let vc = storyboard?.instantiateViewController(withIdentifier: "OrdersViewController") as! OrdersViewController
            navigationController?.pushViewController(vc, animated: true)
               
            }else if cell.namesLbl.text == "My WishList"{
                             
                             
                let vc = storyboard?.instantiateViewController(withIdentifier: "MyWishListViewController") as! MyWishListViewController
                navigationController?.pushViewController(vc, animated: true)
            
                
            }else if cell.namesLbl.text == "Add Business"{
                                            
                                            
                let vc = storyboard?.instantiateViewController(withIdentifier: "AddBusinessViewController") as! AddBusinessViewController
                navigationController?.pushViewController(vc, animated: true)
            
                
            }else if cell.namesLbl.text == "Switch Business"{
                                            
                                            
                let vc = storyboard?.instantiateViewController(withIdentifier: "SwitchViewController") as! SwitchViewController
                navigationController?.pushViewController(vc, animated: true)
               
                
            }else if cell.namesLbl.text == "Rewards"{
                                                       
                                                       
                let vc = storyboard?.instantiateViewController(withIdentifier: "RewardsViewController") as! RewardsViewController
                navigationController?.pushViewController(vc, animated: true)
           
            }else if cell.namesLbl.text == "Signout"{
                
                let alert = UIAlertController(title: "LOGOUT", message: "Are you sure,you want to exit?", preferredStyle: .alert)
                       
                       
                       
                alert.addAction(UIAlertAction(title: "Yes", style: .cancel, handler: { (confirmAction) in
                       
            UserDefaults.standard.removePersistentDomain(forName:Bundle.main.bundleIdentifier!)
                UserDefaults.standard.synchronize()
                
                       
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController")
                       
                self.navigationController?.pushViewController(vc!, animated: true)
                           
            //SingleToneClass.shared.dismissProgressLoadingWithSucess(message: "LogOut Successful")
                           
                //SingleToneClass.shared.dismissProgressLoading(WithDelay: 5)
                       
                       
                       }))
                       
                       
                alert.addAction(UIAlertAction(title: "No", style: .default, handler: { (cancelAction) in }))
                       
                       
                present(alert, animated: true, completion: nil)
                       
                       }
                   
        }
        
   // }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


//func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//
//    let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! sideMenuTableViewCell
//    print(sideMenuList)
//    cell.lbl_names.text = sideMenuList[indexPath.row]
//    return cell
//}
//
//func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//
//    let revealViewController: SWRevealViewController = self.revealViewController()
//    let cell : sideMenuTableViewCell = tableView.cellForRow(at: indexPath) as! sideMenuTableViewCell
//
//    if cell.lbl_names.text == "Home"
//
//    {
//
//
//        DetailsStore.selectedStatus = false
//        DetailsStore.backStatus = true
//        let mainStoryBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//
//
//        let desController = mainStoryBoard.instantiateViewController(withIdentifier: "tabBarVC") as! tabBarVC
//
//
//        let newFrontViewController = UINavigationController.init(rootViewController:desController)
//        revealViewController.pushFrontViewController(newFrontViewController, animated: true)
//
//    }
//
//    if cell.lbl_names.text == "About Us"
//
//    {
//        let mainStoryBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//
//        let desController = mainStoryBoard.instantiateViewController(withIdentifier: "aboutUsVC") as! aboutUsVC
//
//        let newFrontViewController = UINavigationController.init(rootViewController:desController)
//        revealViewController.pushFrontViewController(newFrontViewController, animated: true)
//
//    }
//
//    if cell.lbl_names.text == "Why Us"
//
//    {
//        let mainStoryBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//
//        let desController = mainStoryBoard.instantiateViewController(withIdentifier: "whyUsVC") as! whyUsVC
//
//        let newFrontViewController = UINavigationController.init(rootViewController:desController)
//        revealViewController.pushFrontViewController(newFrontViewController, animated: true)
//
//    }
//    if cell.lbl_names.text == "Terms & Conditions"
//
//    {
//        let mainStoryBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//
//        let desController = mainStoryBoard.instantiateViewController(withIdentifier: "T_CViewController") as! T_CViewController
//
//        let newFrontViewController = UINavigationController.init(rootViewController:desController)
//        revealViewController.pushFrontViewController(newFrontViewController, animated: true)
//
//    }
//    if cell.lbl_names.text == "Privacy Policy"
//
//    {
//        let mainStoryBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//
//        let desController = mainStoryBoard.instantiateViewController(withIdentifier: "PrivacyPolicyViewController") as! PrivacyPolicyViewController
//
//        let newFrontViewController = UINavigationController.init(rootViewController:desController)
//        revealViewController.pushFrontViewController(newFrontViewController, animated: true)
//
//    }
//    if cell.lbl_names.text == "Contact Us"
//
//    {
//        let mainStoryBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//
//        let desController = mainStoryBoard.instantiateViewController(withIdentifier: "contactUsVC") as! contactUsVC
//
//        let newFrontViewController = UINavigationController.init(rootViewController:desController)
//        revealViewController.pushFrontViewController(newFrontViewController, animated: true)
//
//    }
//}

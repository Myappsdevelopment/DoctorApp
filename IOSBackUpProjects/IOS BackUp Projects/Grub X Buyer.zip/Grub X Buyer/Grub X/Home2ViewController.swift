//
//  Home2ViewController.swift
//  Grub X
//
//  Created by MAD-MAC on 03/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit

class Home2ViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate {
   
    
    
    @IBOutlet weak var suppliersBtn: UIButton!
    @IBOutlet weak var suppliersView: UIView!
    @IBOutlet weak var topProductBtn: UIButton!
    @IBOutlet weak var topProductView: UIView!
    
    
   
    
    
    let grayColour = UIColor(red: 143.0/255.0, green: 143.0/255.0, blue: 143.0/255.0, alpha: 1.0)
    let redColour = UIColor(red: 203.0/255.0, green: 8.0/255.0, blue: 22.0/255.0, alpha: 1.0)
    
    
    override func viewWillAppear(_ animated: Bool) {
         
       
         
         self.navigationController?.isNavigationBarHidden = false
        
        // self.navigationItem.title = "Dashboard"
         self.navigationController?.navigationBar.barTintColor = UIColor(red: 203/255, green: 8/255, blue: 22/255, alpha: 1.0)
        // self.tabBarController?.tabBar.barTintColor = UIColor(red: 113/255, green: 188/255, blue: 121/255, alpha: 1.0)
         self.navigationController?.navigationBar.tintColor = .white
         self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
         self.navigationController?.navigationBar.isTranslucent = false
         self.navigationController?.view.backgroundColor = .white
       
      //  SingleToneClass.shared.showProgressLoading(title: "Please Wait")

     }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func suppliersBtn(_ sender: Any) {
        suppliersBtn.setTitleColor(redColour, for: [])
        self.suppliersView.backgroundColor = redColour
        topProductBtn.setTitleColor(grayColour, for: [])
        self.topProductView.backgroundColor = grayColour
        
    }
    
    @IBAction func topProductsBtn(_ sender: Any) {
        suppliersBtn.setTitleColor(grayColour, for: [])
        self.suppliersView.backgroundColor = grayColour
        topProductBtn.setTitleColor(redColour, for: [])
        self.topProductView.backgroundColor = redColour
               
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
          
        return 10
       
    }
       
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! Home2CollectionViewCell
        
        return cell
       
    }
       

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  BeveragesProductsCollectionViewCell.swift
//  Grub X
//
//  Created by MAD-MAC on 08/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit

class BeveragesProductsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var productNameLbl: UILabel!
    
    @IBOutlet weak var productDiscountCostLbl: UILabel!
    
    @IBOutlet weak var productActualCostLbl: UILabel!
    
    @IBOutlet weak var percentageLbl: UILabel!
    
    
    @IBOutlet weak var minusBtn: UIButton!
    
    
    @IBOutlet weak var countLbl: UILabel!
    
    
    @IBOutlet weak var plusBtn: UIButton!
    
    
    
}

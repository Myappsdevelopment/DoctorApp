//
//  LoginViewController.swift
//  Grub X
//
//  Created by MAD-MAC on 03/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    
    
    @IBOutlet weak var requestBtn: UIButton!
    @IBOutlet weak var loginBtn: UIButton!
    
    
   
    
    override func viewWillAppear(_ animated: Bool) {
          self.navigationController?.isNavigationBarHidden = true
          
      }
      
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        requestBtn.layer.cornerRadius = 10
        loginBtn.layer.cornerRadius = 10
        
        
        // Do any additional setup after loading the view.
    }
    

    @IBAction func login(_ sender: Any) {
        
        
        let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let gotoOTP = storyBoard.instantiateViewController(withIdentifier: "TabViewController") as! TabViewController
        self.navigationController?.pushViewController(gotoOTP, animated: true)
                           

        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

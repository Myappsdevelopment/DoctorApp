//
//  ProductDetailsCollectionViewCell.swift
//  Grub X
//
//  Created by MAD-MAC on 07/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit

class ProductDetailsCollectionViewCell: UICollectionViewCell {
    
}

//
//  CategoriesCollectionViewCell.swift
//  Grub X
//
//  Created by MAD-MAC on 08/01/20.
//  Copyright © 2020 My Apps Development. All rights reserved.
//

import UIKit

class CategoriesCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var imageName: UILabel!
    
    
    @IBOutlet weak var productName: UILabel!
    
    
}

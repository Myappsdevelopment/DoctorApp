//
//  loginVc.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 18/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import SVProgressHUD

class loginVc: UIViewController {

    @IBOutlet weak var txt_email: UITextField!
    @IBOutlet weak var txt_lgpwd: UITextField!
    
    @IBOutlet weak var btn_login: UIButton!
    @IBOutlet weak var guestBtn: UIButton!
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
        SingleToneClass.shared.dismissProgressLoading(WithDelay: 5)
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btn_login.layer.cornerRadius = 10
        guestBtn.layer.cornerRadius = 10
        
        SingleToneClass.shared.dismissProgressLoading()
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
        // Do any additional setup after loading the view.
    }
    

    @IBAction func guestBtn(_ sender: Any) {
        
    let vc=self.storyboard?.instantiateViewController(withIdentifier: "SWRevealViewController")as! SWRevealViewController
        
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        appdelegate.window?.rootViewController = vc
        // self.navigationController?.pushViewController(vc, animated: true)
        //SingleToneClass.shared.dismissProgressLoadingWithSucess(message: "LogOut Successful")
  //  self.navigationController?.pushViewController(vc, animated: true)
   // SingleToneClass.shared.dismissProgressLoadingWithSucess(message: "Login Successful")
        
    }
    

    @IBAction func btn_forgotPwd(_ sender: UIButton) {
        
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "forgotVC") as! forgotVC
        self.present(nextViewController, animated:true, completion:nil)
        
    

        
    }
    @IBAction func btn_signUp(_ sender: UIButton) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "signUpVC") as! signUpVC
        self.present(nextViewController, animated:true, completion:nil)
    }
    
    @IBAction func btn_tappedLogin(_ sender: UIButton) {
        
        
        
        if !txt_email.isValidMobileNumberTextField() && !txt_email.isValidEmailTextField() && !txt_email.isValidTextField() {
            
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter Valid mobile number /Valid EmailID / Valid Username") {
                self.txt_email.becomeFirstResponder()
            }

            
        } else if !txt_lgpwd.isValidTextField() {
            
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter password") {
                self.txt_lgpwd.becomeFirstResponder()
            }
            
        } else {
            
            SingleToneClass.shared.showProgressLoading(title: "Please wait...")
            loginServiceCall()
            
        }
        
    }
    
    
    func loginServiceCall () {
        
        let deviceToken = DetailsStore.fcmToken
        
        let params = ["username":txt_email.text!,"password":txt_lgpwd.text!,"device_type":"IOS","device_token":deviceToken]
        print(params)
        
        Service.shared.POSTService(serviceType: API.login, parameters: params ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
            print(message as Any)
            print(responseDetails as Any)
            
            if responseDetails["code"] == "200"{
                
                
                if let userPlan = responseDetails["user_plan"]?.array {
                    
                    let startDate = userPlan[0]["startdate"].string
                    print(startDate as Any)
                    let meals = userPlan[0]["meals"].string
                    let endDate = userPlan[0]["enddate"].string
                    
                    let dateFormatterGet = DateFormatter()
                    dateFormatterGet.dateFormat = "yyyy-MM-dd HH:mm:ss"
                    
                    let dateFormatterPrint = DateFormatter()
                    dateFormatterPrint.dateFormat = "dd-MM-yyyy"
                    
                    if let date = dateFormatterGet.date(from: startDate!) {
                       let displaystartDate = dateFormatterPrint.string(from: date)
                        
                        UserDefaults.standard.set(displaystartDate, forKey: "StartDate")
                        
                    }
                    
                    if let date = dateFormatterGet.date(from: endDate!) {
                        let displaystartDate = dateFormatterPrint.string(from: date)

                        UserDefaults.standard.set(displaystartDate, forKey: "EndDate")

                    }
                   UserDefaults.standard.set(meals, forKey: "Meals")
                    
                }
                
                
                
                
                let data = responseDetails["data"]?.dictionary
                
                let id = data!["ID"]?.string
                let name = data!["fullname"]?.string
                let email = data!["email"]?.string
                let mobile = data!["mobile"]?.string
                let package = data!["package"]?.string
                let address = data!["address"]?.string
                let password = data!["password"]?.string
                let tiffinBox = data!["is_tiffin"]?.string
               
                
                UserDefaults.standard.set(id, forKey: "UserId")
                UserDefaults.standard.set(name, forKey: "userName")
                UserDefaults.standard.set(email, forKey: "emailId")
                UserDefaults.standard.set(mobile, forKey: "mobile")
                UserDefaults.standard.set(package, forKey: "Package")
                UserDefaults.standard.set(address, forKey: "Address")
                UserDefaults.standard.set(password, forKey: "Password")
                UserDefaults.standard.set(tiffinBox, forKey: "TiffinBox")
               
                
                print(data as Any)
                
                DetailsStore.loginDetails = data! 
                
                let vc=self.storyboard?.instantiateViewController(withIdentifier: "SWRevealViewController")as! SWRevealViewController
                
                let appdelegate = UIApplication.shared.delegate as! AppDelegate
               appdelegate.window?.rootViewController = vc
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
           
    }
                
            
            else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
            }
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") { }
            }
        
        }
    
    
    
    }
    
}

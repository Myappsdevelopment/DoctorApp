//
//  forgotVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 18/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
//import SKCountryPicker

class forgotVC: UIViewController {

    @IBOutlet weak var btn_selectCountry: UIButton!
    @IBOutlet weak var txt_phoneNumber: UITextField!
    
  
    
    
    override func viewWillAppear(_ animated: Bool) {
          self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
   
      
        
        txt_phoneNumber.layer.borderWidth = 0
      
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }

        // Do any additional setup after loading the view.
    }
    

   

    @IBAction func btn_tappedNext(_ sender: UIButton) {
        if !txt_phoneNumber.isValidMobileNumberTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter 10 digit mobile number") {
                self.txt_phoneNumber.becomeFirstResponder()
            }
        }else{
          SingleToneClass.shared.showProgressLoading(title: "Please wait...")
        forgotService()
        }
    }
    
    
//    @IBAction func btn_tappedCountry(_ sender: UIButton) {
//
//        let countryController = CountryPickerWithSectionViewController.presentController(on: self) { (country: Country) in
//            //self.countryImageView.image = country.flag
//            self.btn_selectCountry.setTitle(country.dialingCode, for: .normal)
//
//    }
//        countryController.detailColor = UIColor.red
//}
    
    
    func forgotService () {
        
        let params = ["mobile_num":txt_phoneNumber.text!]
        print(params)
        
        Service.shared.POSTService(serviceType: API.forgot, parameters: params ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
          
            if response != "unknown" {
                
            guard let responseDetails = response .dictionary else{return}
            
                let message = responseDetails["message"]?.string
                print(message as Any)
            
            if responseDetails["code"] == "200" {
                
               

                
                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "loginVc") as! loginVc
              
                
                self.present(nextViewController, animated:true, completion:nil)
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
                
                
            }
            }else{
               
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server Problem") {  exit(0) }
                
            }
            
        }
    
    
    }
    
}






/*
 
 APP_PATH="${TARGET_BUILD_DIR}/${WRAPPER_NAME}"
 
 # This script loops through the frameworks embedded in the application and
 # removes unused architectures.
 find "$APP_PATH" -name '*.framework' -type d | while read -r FRAMEWORK
 do
 FRAMEWORK_EXECUTABLE_NAME=$(defaults read "$FRAMEWORK/Info.plist" CFBundleExecutable)
 FRAMEWORK_EXECUTABLE_PATH="$FRAMEWORK/$FRAMEWORK_EXECUTABLE_NAME"
 echo "Executable is $FRAMEWORK_EXECUTABLE_PATH"
 
 EXTRACTED_ARCHS=()
 
 for ARCH in $ARCHS
 do
 echo "Extracting $ARCH from $FRAMEWORK_EXECUTABLE_NAME"
 lipo -extract "$ARCH" "$FRAMEWORK_EXECUTABLE_PATH" -o "$FRAMEWORK_EXECUTABLE_PATH-$ARCH"
 EXTRACTED_ARCHS+=("$FRAMEWORK_EXECUTABLE_PATH-$ARCH")
 done
 
 echo "Merging extracted architectures: ${ARCHS}"
 lipo -o "$FRAMEWORK_EXECUTABLE_PATH-merged" -create "${EXTRACTED_ARCHS[@]}"
 rm "${EXTRACTED_ARCHS[@]}"
 
 echo "Replacing original executable with thinned version"
 rm "$FRAMEWORK_EXECUTABLE_PATH"
 mv "$FRAMEWORK_EXECUTABLE_PATH-merged" "$FRAMEWORK_EXECUTABLE_PATH"
 
 done
*/

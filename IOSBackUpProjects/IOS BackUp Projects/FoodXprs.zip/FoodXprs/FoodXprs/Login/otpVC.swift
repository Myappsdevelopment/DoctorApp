//
//  otpVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 26/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit


class otpVC: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var txt_btn1: UITextField!
    @IBOutlet weak var txt_btn2: UITextField!
    @IBOutlet weak var txt_btn3: UITextField!
    @IBOutlet weak var txt_btn4: UITextField!
    @IBOutlet weak var btn_ok: UIButton!
    
    @IBOutlet weak var otpBtn5: UITextField!
    
    @IBOutlet weak var otpBtn6: UITextField!
    
    @IBOutlet weak var mobileNoLbl: UILabel!
    
    
    //var userData: [String : String]?
    
    
    var userId : String?
    var mobileNo : String?
    var otp: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        self.txt_btn1.layer.cornerRadius = 8
        self.txt_btn2.layer.cornerRadius = 8
        self.txt_btn3.layer.cornerRadius = 8
        self.txt_btn4.layer.cornerRadius = 8
        self.otpBtn5.layer.cornerRadius = 8
        self.otpBtn6.layer.cornerRadius = 8
        self.btn_ok.layer.cornerRadius = 8
        
        
        
        txt_btn1.delegate = self
        txt_btn2.delegate = self
        txt_btn3.delegate = self
        txt_btn4.delegate = self
        otpBtn5.delegate = self
        otpBtn6.delegate = self
        navigationItem.leftBarButtonItem?.tintColor = UIColor.white
        
        
        txt_btn1.textFieldAsLine()
        txt_btn2.textFieldAsLine()
        txt_btn3.textFieldAsLine()
        txt_btn4.textFieldAsLine()
        otpBtn5.textFieldAsLine()
        otpBtn6.textFieldAsLine()
        
        txt_btn1.addTarget(self, action: #selector(generatePasswordTextFieldDidChanged(textField:)), for: .editingChanged)
        txt_btn2.addTarget(self, action: #selector(generatePasswordTextFieldDidChanged(textField:)), for: .editingChanged)
        txt_btn3.addTarget(self, action: #selector(generatePasswordTextFieldDidChanged(textField:)), for: .editingChanged)
        txt_btn4.addTarget(self, action: #selector(generatePasswordTextFieldDidChanged(textField:)), for: .editingChanged)
        otpBtn5.addTarget(self, action: #selector(generatePasswordTextFieldDidChanged(textField:)), for: .editingChanged)
        otpBtn6.addTarget(self, action: #selector(generatePasswordTextFieldDidChanged(textField:)), for: .editingChanged)
      
        
        
        print(mobileNo as Any)
        if let mobileNumber = mobileNo {
            let newMobilleNumber = mobileNumber.dropFirst(7)
            let hiddenMobileNumber = "+91XXXXXXX\(newMobilleNumber)"
            self.mobileNoLbl.text = hiddenMobileNumber
            print(mobileNoLbl as Any)
            
        }
            if SingleToneClass.shared.isInternetAvailable()==false{
                SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                    
                }
            }

        
    
    }

    
    
    @objc func generatePasswordTextFieldDidChanged(textField : UITextField) -> Void {
        
        if (textField.text?.count)! > 0 {
        
      //  if textField.text!.count < 1  && textField.text!.count > 0 {
        
        
            switch textField {
                
            case txt_btn1:
               
                self.txt_btn2.becomeFirstResponder()
                break
                
            case txt_btn2:
                
                self.txt_btn3.becomeFirstResponder()
                break
                
            case txt_btn3:
                
                self.txt_btn4.becomeFirstResponder()
                break
                
            case txt_btn4:
                
                self.otpBtn5.becomeFirstResponder()
                break
                
            case otpBtn5:
                
                self.otpBtn6.becomeFirstResponder()
                break
                
            case otpBtn6:
                
                self.otpBtn6.resignFirstResponder()
                break
                
            default:
                
                break
                
            }
            
        } else {
            
            switch textField {
            case otpBtn6:
                
                self.otpBtn5.becomeFirstResponder()
                break

            case otpBtn5:
                
                self.txt_btn4.becomeFirstResponder()
                break

                
            case txt_btn4:
                
                self.txt_btn3.becomeFirstResponder()
                break
                
            case txt_btn3:
                
                self.txt_btn2.becomeFirstResponder()
                break
                
            case txt_btn2:
                
                self.txt_btn1.becomeFirstResponder()
                break
                
            case txt_btn1:
                
                self.txt_btn1.resignFirstResponder()
                break
                
            default:
                
                break
                
            }
            
        }
        
    }
    
    
    
    
    
    
    
    @IBAction func btn_tappedOk(_ sender: UIButton) {
        
        otp = "\(txt_btn1.text!)\(txt_btn2.text!)\(txt_btn3.text!)\(txt_btn4.text!)\(otpBtn5.text!)\(otpBtn6.text!)"
       
        guard let otpString = otp else { return }
        
        if otpString.count != 6 {
            
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter 6 digit OTP") {
                
                self.txt_btn1.text = ""
                self.txt_btn2.text = ""
                self.txt_btn3.text = ""
                self.txt_btn4.text = ""
                self.otpBtn5.text = ""
                
            }
            
        } else {
          
            
           SingleToneClass.shared.showProgressLoading(title: "Please wait...")
            signUpWithOTPServiceCall()
            
      
        }
        


    }
    
    
    func signUpWithOTPServiceCall()  {
        
        
        print(userId as Any)
        
        let params = ["user_id": userId!,"otp":otp!]
        print(params)
        
        Service.shared.POSTService(serviceType: API.otp, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
        SingleToneClass.shared.dismissProgressLoading()
            
            if response != "unknown" {
            
        guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                print(message as Any)
                print(responseDetails as Any)
        
        
                if responseDetails["code"] == "200" {

                 
                    
                    let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                    let nextViewController = storyBoard.instantiateViewController(withIdentifier: "loginVc") as! loginVc
              
                    
                    self.present(nextViewController, animated:true, completion:nil)
                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
                    
                }else{
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                    
                    
                }
            }else{
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server Problem") {  exit(0) }
                
                }
            }
        
        }
    
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
      
        if textField.text == txt_btn1.text {
        
        let currentCharacterCount = txt_btn1.text?.count ?? 0
        if range.length + range.location > currentCharacterCount {
            return false
        }
        let newLength = currentCharacterCount + string.count - range.length
        return newLength <= 1
    
        } else if textField.text == txt_btn2.text {
            
            let currentCharacterCount = txt_btn2.text?.count ?? 0
            if range.length + range.location > currentCharacterCount {
                return false
            }
            let newLength = currentCharacterCount + string.count - range.length
            return newLength <= 1
        }else if textField.text == txt_btn3.text {
            
            let currentCharacterCount = txt_btn3.text?.count ?? 0
            if range.length + range.location > currentCharacterCount {
                return false
            }
            let newLength = currentCharacterCount + string.count - range.length
            return newLength <= 1
        }else if textField.text == txt_btn4.text {
            
            let currentCharacterCount = txt_btn4.text?.count ?? 0
            if range.length + range.location > currentCharacterCount {
                return false
            }
            let newLength = currentCharacterCount + string.count - range.length
            return newLength <= 1
        }else if textField.text == otpBtn5.text {
            
            let currentCharacterCount = otpBtn5.text?.count ?? 0
            if range.length + range.location > currentCharacterCount {
                return false
            }
            let newLength = currentCharacterCount + string.count - range.length
            return newLength <= 1
        }else if textField.text == otpBtn6.text {
            
            let currentCharacterCount = otpBtn6.text?.count ?? 0
            if range.length + range.location > currentCharacterCount {
                return false
            }
            let newLength = currentCharacterCount + string.count - range.length
            return newLength <= 1
        }
    
        return true
    }
    
}

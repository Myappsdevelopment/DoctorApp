//
//  signUpVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 18/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import SVProgressHUD


class signUpVC: UIViewController,UIPickerViewDelegate, UIPickerViewDataSource,UITextFieldDelegate  {

   
    
 
    @IBOutlet weak var btn_signUp: UIButton!
    @IBOutlet weak var nameTF: TextField!
    @IBOutlet weak var mobileNoTF: TextField!
    @IBOutlet weak var emailTF: TextField!
    @IBOutlet weak var userNameTF: TextField!
    @IBOutlet weak var passwordTF: TextField!
    @IBOutlet weak var retypePasswordTF: TextField!
    @IBOutlet weak var registerFeeTF: TextField!
    
    let picker = UIPickerView()
    var selectedTF = UITextField()
    let toolBar = UIToolbar()
  
   
    var packages:[String]=[]
    var packageIds:[String]=[]
    var selectedpackageId:String = ""
    

 
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        self.navigationController?.isNavigationBarHidden = true
        btn_signUp.layer.cornerRadius = 10
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
       // registerFeeTF.delegate = self
       
        // Do any additional setup after loading the view.
    }
    
    func createPicker(){
        
        picker.delegate = self
        picker.dataSource = self
        
       
        
        
        let pickerView = picker
        pickerView.backgroundColor = .white
        pickerView.showsSelectionIndicator = true
        
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action:#selector(donePicker))
        doneButton.tintColor = UIColor.black
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action:#selector(canclePicker))
        cancelButton.tintColor = UIColor.black
        
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.barTintColor = .white
        
        
        
//        self.registerFeeTF.inputView = pickerView
//        self.registerFeeTF.inputAccessoryView = toolBar
        

        
        
    }
    
    
    @objc func donePicker() {
        
     
        
        if selectedTF == self.registerFeeTF{
            self.selectedpackageId = packageIds[picker.selectedRow(inComponent: 0)]
            print(selectedpackageId)
            self.registerFeeTF.text = packages[picker.selectedRow(inComponent: 0)]
            self.registerFeeTF.resignFirstResponder()
            
        
        }
    }
    
    @objc func canclePicker() {
        
        self.selectedTF.resignFirstResponder()
        
    }

    
    
    @IBAction func btn_alreadyAccount(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
        
    }
    
    
    @IBAction func btn_signUp(_ sender: UIButton) {
        
        
        if !nameTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter your name") {
                self.nameTF.becomeFirstResponder()
            }
        } else if (nameTF.text?.count)! > 70 {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter your name with less than 70 characters") {
                self.nameTF.becomeFirstResponder()
            }
            
        } else if !mobileNoTF.isValidMobileNumberTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter 10 digit mobile number") {
                self.mobileNoTF.becomeFirstResponder()
            }
        } else if !emailTF.isValidEmailTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter valid E-mail ID") {
                self.emailTF.becomeFirstResponder()
                
            }
            
        }else if !registerFeeTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter the Address") {
                self.registerFeeTF.becomeFirstResponder()
                
            }
            
        } else if !userNameTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter UserName") {
                self.passwordTF.becomeFirstResponder()
            }
            
        } else if !passwordTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter password") {
                self.passwordTF.becomeFirstResponder()
            }
        } else if retypePasswordTF.text != passwordTF.text {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Password and confirm password must be same") {
                self.retypePasswordTF.becomeFirstResponder()
            }
            
        } else {

            SingleToneClass.shared.showProgressLoading(title: "Please wait...")
            signUpServiceCall()
            
        }
        
        
        

    }
    
    func signUpServiceCall () {
        
        let deviceToken = DetailsStore.fcmToken
        print(deviceToken)
        
        let params=["user-fullname":"\(nameTF.text!)","user-mobile":"\(mobileNoTF.text!)","user-email":"\(emailTF.text!)","user-name":"\(userNameTF.text!)","user-password":"\(passwordTF.text!)","address":"\(registerFeeTF.text!)","device_token":deviceToken,"device_type":"IOS"]
        

        print(params)
        
        Service.shared.POSTService(serviceType: API.signUp, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
            if response != "unknown" {
                
             guard let responseDetails = response .dictionary else{return}
           
                let message = responseDetails["message"]? .string
                print(message as Any)
        
            if responseDetails["code"] == "200" {
                
                
                let data = responseDetails["data"]?.dictionary
                
                    let id = data!["ID"]?.string
                   let mobile = data!["mobile"]?.string
                
                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "otpVC") as! otpVC
                
                 nextViewController.userId = id
                 nextViewController.mobileNo = mobile
                
                self.present(nextViewController, animated:true, completion:nil)
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
        
            }else {
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
            }
        }else{
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server Problem") {
                    exit(0)
                }
        }
    }
    
    }
    
    func packageService () {
        
        Service.shared.GETService(extraParam: API.package) { (response) -> (Void) in

            print(response)
            
            guard let responseDetails = response .dictionary else{return}
            
            if let packageDetails = responseDetails["data"]?.array{
               
                
                for i in packageDetails{
            
        
                    let packDic = i.dictionary!
                    print(packDic)
                    
                    let packageDetailsNames = packDic["title"]?.string
                    print(packageDetailsNames as Any)
                    

                    self.packages.append(packageDetailsNames!)
                    print(self.packageIds)
            
                
                   if let packageDetailsId = i["ID"].string {
                    self.packageIds.append(packageDetailsId)
                        print(self.packageIds)


                        }
                    
                }
                    
            }
            
        }
            
            
    }
    

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if selectedTF == self.registerFeeTF {
            return packages.count
        }else {
            return 0
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        
        if selectedTF == self.registerFeeTF {
            return packages[row]
        }else {
            return [String]()[row]
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {




           if selectedTF == self.registerFeeTF{
                self.selectedpackageId = packageIds[picker.selectedRow(inComponent: 0)]
                        print(selectedpackageId)
                print(packages)
                    }

    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        self.selectedTF = textField
        return true
        
    }
    
    
    
    
    
    
    
}

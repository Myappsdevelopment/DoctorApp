//
//  congratsVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 26/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class congratsVC: UIViewController {

    @IBOutlet weak var btn_login: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.btn_login.layer.cornerRadius = 10
        self.navigationController?.isNavigationBarHidden = true
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func btn_tappedLogin(_ sender: UIButton) {
        let vc=self.storyboard?.instantiateViewController(withIdentifier: "loginVc")as! loginVc
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
}

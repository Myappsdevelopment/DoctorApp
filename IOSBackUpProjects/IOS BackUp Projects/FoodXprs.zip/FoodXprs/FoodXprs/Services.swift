//
//  shared.swift
//  Mahendra logistics
//
//  Created by VamsiKrishna on 7/13/18.
//  Copyright © 2018 HJSoftware. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class Service{
    
    static let shared=Service()
    init() {
    }
    
    
    
    func GETService(extraParam : String, onTaskCompleted : @escaping (JSON)->(Void) ) {
        
        print(extraParam)
        
        let header = ["API-KEY" : "45F2CFBEDCC104B93181D9CA1ECBD86B","Content-Type" : "application/json"]
        guard let url = URL(string: "\(extraParam)") else { return }
      //  Alamofire.request(url, method: .get,encoding:JSONEncoding.default, headers: header).responseJSON
         Alamofire.request(url, method: .get,encoding:JSONEncoding(options: []), headers: header).responseJSON
            { response in
                
                print(response)
                
                let jsonData = JSON(response.result.value as Any)
                onTaskCompleted(jsonData)
        }
    }
    
    
    func POSTService(serviceType : String,parameters : [String:String], onTaskCompleted : @escaping (JSON)->(Void)) {
        print(serviceType)
        guard let url = URL(string: "\(serviceType)") else { return }
        print(parameters)
        
        
        let header = ["API-KEY" : "45F2CFBEDCC104B93181D9CA1ECBD86B","Content-Type" : "application/json"]
//        Alamofire.request(url, method: .post, parameters: parameters,headers: header).responseJSON{ response in
        
        Alamofire.request(url, method: .post, parameters: parameters,encoding:JSONEncoding(options: []), headers: header).responseJSON{ response in
            
            
            print(response)
            let jsonData = JSON(response.result.value as Any)
            onTaskCompleted(jsonData)
            
        }
    }
    
}


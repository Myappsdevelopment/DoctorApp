//
//  popUpMyAcntVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 19/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class popUpMyAcntVC: UIViewController {

    @IBOutlet var backgroundBtn: UIButton!
    @IBOutlet var popUpVw: UIView!
    
    @IBOutlet var addressBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        popUpVw.layer.cornerRadius = 5.0
        popUpVw.clipsToBounds = true
        
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
    }
    
    @IBAction func onTapBackgroundBtn(_ sender: UIButton) {
        
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func onTapAddressBtn(_ sender: UIButton) {
        
        let alertController = UIAlertController(title: "Hitech City", message: "Enter your address here", preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction (title: "Update", style: .default, handler: { (action:UIAlertAction) in }))

        alertController.addAction(UIAlertAction (title: "Delete", style: .default, handler: { (action:UIAlertAction) in }))
        
        alertController.addAction(UIAlertAction (title: "Cancel", style: .destructive, handler: { (action:UIAlertAction) in }))

        self.present(alertController, animated: true, completion: nil)
    }

    @IBAction func btn_tapOnPayment(_ sender: UIButton) {
        
        let alertController = UIAlertController(title: "Payment", message: "Link Your Wallet", preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction (title: "PayTm", style: .default, handler: { (action:UIAlertAction) in }))
        
        alertController.addAction(UIAlertAction (title: "FreeCharge", style: .default, handler: { (action:UIAlertAction) in }))
        
        alertController.addAction(UIAlertAction (title: "Amazon Pay", style: .default, handler: { (action:UIAlertAction) in }))
        
        alertController.addAction(UIAlertAction (title: "PhonePay", style: .default, handler: { (action:UIAlertAction) in }))
        
        
        alertController.addAction(UIAlertAction (title: "MobiKwik", style: .default, handler: { (action:UIAlertAction) in }))
        
        alertController.addAction(UIAlertAction (title: "Cancel", style: .destructive, handler: { (action:UIAlertAction) in }))
        
        self.present(alertController, animated: true, completion: nil)
        
        
    }
    @IBAction func btn_tappedInvite(_ sender: UIButton) {
        
        let alertController = UIAlertController(title: "Invite", message: "Invite Your Friends and Earn", preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction (title: "Invite", style: .default, handler: { (action:UIAlertAction) in }))
        
        alertController.addAction(UIAlertAction (title: "Cancel", style: .destructive, handler: { (action:UIAlertAction) in }))
        
        self.present(alertController, animated: true, completion: nil)
    }
}




/*
 
 https://foodxprs.com/mobileapi/update_trasaction_id.php
 ["TXNAMOUNT": "1.00", "TXNDATE": "2019-10-15 14:34:47.0", "TXNID": "20191015111212800110168809492763041", "order_id": "505", "user_id": "33", "mobile": "7396334424"]
 SUCCESS: {
 code = 200;
 data =     {
 ID = 505;
 amount = "1.00";
 coupon = "";
 couponamt = "";
 credits = 0;
 enddate = "2019-11-15 00:00:00";
 location = "Hitech City";
 meals = 8;
 "mod_date" = "2019-10-15 09:06:59";
 "order_id" = "";
 paymentsource = paytm;
 "reg_date" = "2019-10-15 14:33:47";
 startdate = "2019-10-17 00:00:00";
 status = 1;
 supplystatus = 1;
 transactiondate = "2019-10-15 14:34:47.0";
 transactionid = 20191015111212800110168809492763041;
 "user_id" = 33;
 };
 messages = "Your order has been placed.";
 userdata =     {
 ID = 33;
 address = madhapur;
 amount = "";
 coupon = "";
 credits = 0;
 "device_token" = "eXeszrZm1Z0:APA91bEAGx-BbDU657vrF9SKHjfvyw4H7LauPUqsO9942wYWufiTd8UAHGmv6u04vTSBQqcAqE_PGJc0V0xh4oHv9fhOKmT-DssjY3vwe-DMtavlFndf3hpMpA_Xw_xhOlRzpGjN6CNV";
 "device_type" = IOS;
 email = "mvamsi233@gmail.com";
 fullname = vamsi;
 mobile = 7396334424;
 "mod_date" = "2019-10-14 07:14:57";
 otp = 7733;
 package = 0;
 password = "$2y$10$oVnhso5iUa5ehaBO8Qi5T.Vnf1RdhLIXph8fSv2cmUNg/Ryp14kaW";
 paymentsource = "";
 "reg_date" = "2019-08-07 10:11:41";
 startdate = "";
 status = Active;
 transactiondate = "";
 transactionid = "";
 "unique_id" = FDXS00033;
 username = vamsi233;
 */

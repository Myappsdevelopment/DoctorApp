//
//  Constants.swift
//  VaniInstitute
//
//  Created by Raju Matta on 03/01/19.
//  Copyright © 2019 VaniInstitute. All rights reserved.
//

import Foundation

class Constants{
    
  static var baseUrl = "https://foodxprs.com/mobileapi/"
    
}
struct API {
    
    static var login = Constants.baseUrl + "login.php"
    static var signUp = Constants.baseUrl + "signup.php"
    static var forgot = Constants.baseUrl + "forgetpwd.php"
    static var otp = Constants.baseUrl + "verifyotp.php"
    static var package = Constants.baseUrl + "packages.php"
    static var createleave = Constants.baseUrl + "createleave.php"
    static var myLeaves = Constants.baseUrl + "myleaves.php"
    static var changePassword = Constants.baseUrl + "changepassword.php"
    static var createOrder = Constants.baseUrl + "create_order.php"
    static var checksum = Constants.baseUrl + "generate_checksum.php"
    static var updateAddress = Constants.baseUrl + "address_update.php"
    static var updateDate = Constants.baseUrl + "update_orderdate.php"
    static var promocode = Constants.baseUrl + "coupan_code_validation.php"
    static var myOrders = Constants.baseUrl + "myorder.php"
    static var updateTransactionId = Constants.baseUrl + "update_trasaction_id.php"
    static var switchPlan = Constants.baseUrl + "switch-meals.php"
    
    static var callPhone = "18001020552"

}


struct DetailsStore {
 //   static var loginDetails:[String:Any] = [:]  //memory is allocated
    static var loginDetails : [String:Any]? // memory not allocated
    static var forgotDetails : String?
    static var packageDetails : [String:Any]?

    
    static  var namesLbl:[String] = []
    static  var imageNames:[String] = []
    static  var contentNames:[String] = []
    static  var prices:[String] = []
    static  var orderId:[String] = []
    static var getTag:Int?

    
    static  var selectedStatus:Bool?
    static  var changeOrderId:Bool?
    
    static  var updated:[String] = []
    static  var img:[String] = []
    static  var orderContent : [String] = []
    static  var orderPrice : [String] = []
    static  var packageOrderId : [String] = []
    
    static  var backStatus = true
    
    static var saveDate = String()
    static var fcmToken = String()
    
    static var selectedDate:[String] = []
    
}

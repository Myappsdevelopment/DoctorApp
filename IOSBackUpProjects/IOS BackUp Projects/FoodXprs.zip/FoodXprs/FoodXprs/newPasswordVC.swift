//
//  newPasswordVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 26/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class newPasswordVC: UIViewController {

    
    var userId : String?
    
    @IBOutlet weak var passwordTF: UITextField!
    
    @IBOutlet weak var confirmPasswordTF: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        // Do any additional setup after loading the view.
    }
    



    @IBAction func btn_tappedNext(_ sender: UIButton) {
        
        if !passwordTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter password") {
                self.passwordTF.becomeFirstResponder()
            }
        } else if confirmPasswordTF.text != passwordTF.text {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Password and confirm password must be same") {
                self.confirmPasswordTF.becomeFirstResponder()
            }
            
        } else {
            
            SingleToneClass.shared.showProgressLoading(title: "Please wait...")
            
            changePasswordService()
            
        }
        
        
//        let vc=self.storyboard?.instantiateViewController(withIdentifier: "congratsVC")as! congratsVC
//        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    
    func changePasswordService()  {
        
        
        print(userId as Any)
        
        let params = ["user_id": userId!,"password":confirmPasswordTF.text!]
        
        print(params)
        
        Service.shared.POSTService(serviceType: API.changePassword, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
            if response != "unknown" {
            
            SingleToneClass.shared.dismissProgressLoading()
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                print(message as Any)
                print(responseDetails as Any)
                
                
                if responseDetails["code"] == "200" {
                    
                    
                    
                    
                    let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                    let nextViewController = storyBoard.instantiateViewController(withIdentifier: "congratsVC") as! congratsVC
                   
                    
                    self.present(nextViewController, animated:true, completion:nil)
                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
                    
                }else{
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                    
                    
                }
            }else{
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server Problem") {  exit(0) }
                }
                
            }
            
        }
        
        
        
        
    }
    
    
    
    
    
    
    
    
}

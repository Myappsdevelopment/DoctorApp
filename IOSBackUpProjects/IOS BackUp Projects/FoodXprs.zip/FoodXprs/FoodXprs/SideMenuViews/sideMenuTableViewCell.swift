//
//  sideMenuTableViewCell.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 22/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class sideMenuTableViewCell: UITableViewCell {

    @IBOutlet weak var lbl_names: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

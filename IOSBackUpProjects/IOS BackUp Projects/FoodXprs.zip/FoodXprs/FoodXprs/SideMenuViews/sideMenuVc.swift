//
//  sideMenuVc.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 22/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class sideMenuVc: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    let sideMenuList = ["Home", "About Us", "Why Us","Terms & Conditions","Privacy Policy", "Contact Us"]
    

   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sideMenuList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! sideMenuTableViewCell
        print(sideMenuList)
        cell.lbl_names.text = sideMenuList[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let revealViewController: SWRevealViewController = self.revealViewController()
        let cell : sideMenuTableViewCell = tableView.cellForRow(at: indexPath) as! sideMenuTableViewCell
        
        if cell.lbl_names.text == "Home"
            
        {
            
            
            DetailsStore.selectedStatus = false
            DetailsStore.backStatus = true
            let mainStoryBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            
            
            let desController = mainStoryBoard.instantiateViewController(withIdentifier: "tabBarVC") as! tabBarVC
            
            
            let newFrontViewController = UINavigationController.init(rootViewController:desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
            
        }
        
        if cell.lbl_names.text == "About Us"
            
        {
            let mainStoryBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            
            let desController = mainStoryBoard.instantiateViewController(withIdentifier: "aboutUsVC") as! aboutUsVC
            
            let newFrontViewController = UINavigationController.init(rootViewController:desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
            
        }
        
        if cell.lbl_names.text == "Why Us"
            
        {
            let mainStoryBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            
            let desController = mainStoryBoard.instantiateViewController(withIdentifier: "whyUsVC") as! whyUsVC
            
            let newFrontViewController = UINavigationController.init(rootViewController:desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
            
        }
        if cell.lbl_names.text == "Terms & Conditions"
            
        {
            let mainStoryBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            
            let desController = mainStoryBoard.instantiateViewController(withIdentifier: "T_CViewController") as! T_CViewController
            
            let newFrontViewController = UINavigationController.init(rootViewController:desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
            
        }
        if cell.lbl_names.text == "Privacy Policy"
            
        {
            let mainStoryBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            
            let desController = mainStoryBoard.instantiateViewController(withIdentifier: "PrivacyPolicyViewController") as! PrivacyPolicyViewController
            
            let newFrontViewController = UINavigationController.init(rootViewController:desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
            
        }
        if cell.lbl_names.text == "Contact Us"
            
        {
            let mainStoryBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            
            let desController = mainStoryBoard.instantiateViewController(withIdentifier: "contactUsVC") as! contactUsVC
            
            let newFrontViewController = UINavigationController.init(rootViewController:desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
            
        }
    }
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
 //       return 60
        
  //  }
    
}

//
//  contactUsVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 26/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class contactUsVC: UIViewController {
    
    @IBOutlet weak var sideMenu: UIBarButtonItem!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.isNavigationBarHidden = false
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 241/255, green: 95/255, blue: 42/255, alpha: 1.0)
        self.title = "Contact Us"
         self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        sideMenu.target = revealViewController()
        sideMenu.action = #selector(SWRevealViewController.revealToggle(_:))
        view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        
       

        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
        
        // Do any additional setup after loading the view.
    }
    

    @IBAction func emailSharing(_ sender: Any) {
        
        
        let activityController = UIActivityViewController(activityItems: ["share"], applicationActivities: nil)
        present(activityController, animated: true, completion: nil)
        
        
    }
    
    @IBAction func TollFree(_ sender: Any) {
        
        
        if let url = URL(string: "telprompt://\(API.callPhone)") {
            
            if #available(iOS 10, *) {
                
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                
            } else {
                
                UIApplication.shared.openURL(url as URL)
                
            }
            
        }
        
        
        
    }
}

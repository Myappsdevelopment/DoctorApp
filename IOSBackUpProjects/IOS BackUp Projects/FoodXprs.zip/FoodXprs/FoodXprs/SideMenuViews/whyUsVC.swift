//
//  whyUsVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 26/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class whyUsVC: UIViewController {
    
@IBOutlet weak var sideMenu: UIBarButtonItem!
    
    @IBOutlet weak var displayData: UITextView!
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.displayData.setContentOffset(CGPoint.zero, animated: false)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Why Us"
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.isNavigationBarHidden = false
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 241/255, green: 95/255, blue: 42/255, alpha: 1.0)
        
        sideMenu.target = revealViewController()
        sideMenu.action = #selector(SWRevealViewController.revealToggle(_:))
        view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        
        let floawLayout = UPCarouselFlowLayout()
        //        floawLayout.itemSize = CGSize(width: UIScreen.main.bounds.size.width - 50 , height: collectionView.frame.size.height)
        floawLayout.scrollDirection = .horizontal
        floawLayout.sideItemScale = 0.8
        floawLayout.sideItemAlpha = 1.0
     //   floawLayout.spacingMode = .fixed(spacing: 10.0)
        //        collectionView.collectionViewLayout = floawLayout
        //        collectionView.isPagingEnabled = true

        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
        
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

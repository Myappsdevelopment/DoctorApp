//
//  paymentVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 24/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit


class paymentVC: UIViewController {

    @IBOutlet weak var btn_saveCard: UIButton!
    
    @IBOutlet weak var btn_payNow: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.btn_saveCard.layer.borderWidth = 1
        self.btn_saveCard.layer.borderColor = UIColor.orange.cgColor
        self.btn_saveCard.tintColor = UIColor.orange
        
        btn_saveCard.setImage(UIImage(named:"checkmarkempty"), for: .normal)
        btn_saveCard.setImage(UIImage(named:"checkmark"), for: .selected)
        
        
    self.btn_payNow.layer.cornerRadius = 8

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func btn_tappedPayNow(_ sender: UIButton) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "successVC") as! successVC
        self.present(nextViewController, animated:true, completion:nil)
        
        
    }
    @IBAction func btn_tappedSaveCard(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.0, delay: 0.0, options: .curveLinear, animations: {
            sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
            
        }) { (success) in
            UIView.animate(withDuration: 0.0, delay: 0.0, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
        
        
    }
    @IBAction func btn_back(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
}

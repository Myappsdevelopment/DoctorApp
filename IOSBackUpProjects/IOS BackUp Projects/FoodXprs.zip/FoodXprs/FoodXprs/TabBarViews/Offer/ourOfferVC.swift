//
//  ourOfferVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 22/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class ourOfferVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout  {

    
    @IBOutlet weak var nameLbl: UIBarButtonItem!
    
    @IBOutlet weak var pageOut: UIPageControl!
    @IBOutlet weak var collectionView: UICollectionView!
    
    let offerImages: [UIImage] = [
        UIImage (named: "our offer-1")!, UIImage (named: "our offerX")!]
    
    let HeaderArray = ["RS.100 CASHBACK ON YOUR FIRST ORDER","GET RS.50 CASHBACK"]
    let couponArray = ["USE CODE : FXPRS100","ON REFERRAL"]
    
    @IBOutlet weak var sideMenu: UIBarButtonItem!
    
    var selectedIndex: Int?
    var coupon = String()
    
    override func viewWillAppear(_ animated: Bool) {
         self.tabBarController?.tabBar.isHidden = false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
//
//        if (DetailsStore.loginDetails?["fullname"] != nil)  {
//
//            print(DetailsStore.loginDetails!)
//            print(DetailsStore.loginDetails!["fullname"]!)
//            self.nameLbl.title = "\(DetailsStore.loginDetails!["fullname"]!)"
//            print(self.nameLbl.title!)
//
//        }else{
//
//            self.nameLbl.title = "Login"
//        }
//
        if UserDefaults.standard.string(forKey: "UserId") != nil {
            
            self.nameLbl.title = UserDefaults.standard.string(forKey: "userName")
        }else{
            self.nameLbl.title = "Login"
        }
        
        
        self.navigationController?.isNavigationBarHidden = false
         self.tabBarController?.tabBar.isHidden = false
        
        
        sideMenu.target = revealViewController()
        sideMenu.action = #selector(SWRevealViewController.revealToggle(_:))
        view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        
        let floawLayout = UPCarouselFlowLayout()
        floawLayout.itemSize = CGSize(width: UIScreen.main.bounds.size.width, height: collectionView.frame.size.height)
        floawLayout.scrollDirection = .horizontal
        floawLayout.sideItemScale = 0.8
        floawLayout.sideItemAlpha = 1.0
        //floawLayout.spacingMode = .fixed(spacing: 10.0)
        collectionView.collectionViewLayout = floawLayout
        collectionView.isPagingEnabled = true
        
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }

        // Do any additional setup after loading the view.
    }
    


    var limit = 0
    var x: Int = 0
    var strIndex:Int = 1
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        
        pageOut.numberOfPages = 2
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! offerCollectionViewCell
        
        cell.photo.image = self.offerImages [indexPath.row]
        cell.headerLbl.text = self.HeaderArray[indexPath.row]
        cell.couponTF.text = self.couponArray[indexPath.row]
        self.coupon = self.couponArray[indexPath.row]
        
        cell.copyBtn.tag = indexPath.row
        
         cell.copyBtn.addTarget(self, action: #selector(ourOfferVC.downArrowTapped(_:)), for: .touchUpInside)
        
        
        
        return cell
    }
    
    @objc func downArrowTapped(_ sender: UIButton) {
        if self.selectedIndex != sender.tag {
            
//            if self.coupon == "USE CODE : FXPRS100" {
//                self.coupon = "FXPRS100"
//            }
            
            UIPasteboard.general.string = self.coupon
            print(UIPasteboard.general.string as Any)
            SingleToneClass.shared.dismissProgressLoadingWithSucess(message: "CouponCode Copied")
            SingleToneClass.shared.dismissProgressLoading(WithDelay: 10)
        }
        
    }
    
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offSet = scrollView.contentOffset.x
        let width = scrollView.frame.width
        let horizontalCenter = width / 2
        
        pageOut.currentPage = Int(offSet + horizontalCenter) / Int(width)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width:collectionView.frame.width, height: collectionView.frame.height)
        
        
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
    {
        var visibleRect = CGRect()
        
        visibleRect.origin = collectionView.contentOffset
        visibleRect.size =  collectionView.bounds.size
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
        guard let indexPath =  collectionView.indexPathForItem(at: visiblePoint) else { return }
        
        x = indexPath.row
        strIndex = indexPath.row
        
        let indexPathrow = IndexPath(item: x, section: 0)
        self.collectionView.scrollToItem(at: indexPathrow, at: .centeredHorizontally, animated: true)
        
        
        
        print(indexPath.row)
    }
    
    
    @IBAction func loginBtn(_ sender: Any) {
        
        
        if nameLbl.title == "Login" {
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "loginVc") as! loginVc
            self.present(nextViewController, animated:true, completion:nil)
        }
        
        
        
    }
    
    
    
    
    

}

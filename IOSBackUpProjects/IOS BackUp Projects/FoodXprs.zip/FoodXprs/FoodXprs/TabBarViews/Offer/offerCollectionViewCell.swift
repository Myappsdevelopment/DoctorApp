//
//  offerCollectionViewCell.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 31/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class offerCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var copyBtn: UIButton!
    
    @IBOutlet weak var couponTF: UILabel!
    @IBOutlet weak var photo: UIImageView!
    
    @IBOutlet weak var couponLbl: UILabel!
    @IBOutlet weak var headerLbl: UILabel!
}

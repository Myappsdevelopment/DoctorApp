//
//  PastOrdersTableViewCell.swift
//  FoodXprs
//
//  Created by MAD-MAC on 04/10/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class PastOrdersTableViewCell: UITableViewCell {

    @IBOutlet weak var priceLbl: UILabel!
    @IBOutlet weak var name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//
//  popUpVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 19/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class popUpVC: UIViewController {
    
    
    
    @IBOutlet var popUpVw: UIView!
    
    
    @IBOutlet weak var currentPlanLbl: UILabel!
    @IBOutlet weak var DateLbl: UILabel!
    
    
    
    
     let currentDate = Date()
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
        self.navigationController?.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        self.tabBarController?.tabBar.isHidden = true
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        popUpVw.layer.cornerRadius = 5.0
        popUpVw.clipsToBounds = true

        
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        DateLbl.text = UserDefaults.standard.object(forKey: "StartDate") as? String ?? "-"
        
         let plan = UserDefaults.standard.object(forKey: "Meals") as? String
        if plan == "9" {
             self.currentPlanLbl.text = "Xprs Classic"
        }else if plan == "8" {
            self.currentPlanLbl.text = "Xprs Standard"
        }else if plan == "7" {
            self.currentPlanLbl.text = "Xprs Fresh"
        }else if plan == "6" {
            self.currentPlanLbl.text = "Xprs Lite"
        }else{
            self.currentPlanLbl.text = "-"
        }
        
    
        
        
        
        
        
        
    }

    

    
    
    
    @IBAction func btn_tappedHere(_ sender: UIButton) {
        
        if DateLbl.text == "-" {
             SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "You have not subscribe any plan") { }
        }else{
        
            
            let date = NSDate()
            let calendar = NSCalendar.current
            let components = calendar.dateComponents([.hour, .minute], from: date as Date)
            let hour = components.hour
            print(hour as Any)
            
            if components.hour! >= 09 && components.hour! < 14 {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please switch your meals in between 2.30 pm to 8.30 am") { }
            }else{
            
            
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "planVC") as! planVC
        nextViewController.currentPlan = self.currentPlanLbl.text!
        
        self.present(nextViewController, animated:true, completion:nil)
            }
        }
    }
    @IBAction func leaveBtn(_ sender: Any) {
        
        
        if UserDefaults.standard.object(forKey: "EndDate") as? String == nil {
             SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "You have not subscribe any plan") { }
        }else{
        
        
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "CalendarViewController") as! CalendarViewController
        self.present(nextViewController, animated:true, completion:nil)
        }
        
    }
    
    @IBAction func onTapBackgroundBtn(_ sender: UIButton) {
        let high = NotificationCenter.default
        high.post(name: Notification.Name("All"), object: nil)

          self.view.removeFromSuperview()
       // self.presentedViewController?.dismiss(animated: true, completion: nil)
        
      //  self.navigationController?.popViewController(animated: true)
    }
    
    
    
    
}

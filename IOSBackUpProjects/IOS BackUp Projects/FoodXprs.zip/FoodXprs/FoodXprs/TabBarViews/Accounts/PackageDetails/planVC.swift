//
//  planVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 24/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit


class planVC: UIViewController {

   
    
    @IBOutlet weak var navigationTitle: UINavigationBar!
    @IBOutlet weak var planTF: TextField!
    @IBOutlet weak var fromDateTF: TextField!
    @IBOutlet weak var toDateTF: TextField!

    @IBOutlet weak var confirmBtn: UIButton!
    
   
    @IBOutlet weak var descriptionTV: UITextView!
    
    
    var planArray = ["XprsClassic","XprsStandard","XprsFresh","XprsLite"]
    var xprsClassic = ["XprsStandard","XprsFresh","XprsLite"]
    var xprsStandard = ["XprsClassic","XprsFresh","XprsLite"]
    var xprsFresh = ["XprsClassic","XprsStandard","XprsLite"]
    var xprsLite = ["XprsClassic","XprsStandard","XprsFresh"]
    
   
    let picker = UIPickerView()
    
    let datepicker=UIDatePicker()
    let timePicker=UIDatePicker()
    
    let finalFormatter = DateFormatter()
    
    let currentDate = Date()
    var eightThirty:Date?
    var twoThirty:Date?
    
    var selectedTF = UITextField()
    let toolBar = UIToolbar()
  
    var currentPlan = String()
    var meals = String()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
 
        planTF.delegate = self
        fromDateTF.delegate = self
        toDateTF.delegate = self
        
      //  let orangeColour =  UIColor(red: 241/255, green: 95/255, blue: 42/255, alpha: 1.0)
        planTF.layer.borderWidth = 1
        planTF.layer.borderColor = UIColor.orange.cgColor
        fromDateTF.layer.borderWidth = 1
        fromDateTF.layer.borderColor = UIColor.orange.cgColor
        toDateTF.layer.borderWidth = 1
        toDateTF.layer.borderColor = UIColor.orange.cgColor
      
        self.confirmBtn.layer.cornerRadius = 10
      
        self.navigationTitle.topItem?.title = currentPlan
        descriptionTV.layer.borderWidth = 1
        descriptionTV.layer.borderColor = UIColor.orange.cgColor
        
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
   
      
        createPicker()
        

    }
    
 
    
    
    func createPicker(){
        
        picker.delegate = self
        picker.dataSource = self
        
        datepicker.datePickerMode = .date
        datepicker.setDate(Date(), animated: true)
        
        timePicker.datePickerMode = .time
        timePicker.setDate(Date(), animated: true)

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        
        
        let pickerView = picker
        pickerView.backgroundColor = .white
        pickerView.showsSelectionIndicator = true
        
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.sizeToFit()
        
    
        
        
        
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action:#selector(donePicker))
        doneButton.tintColor = UIColor.black
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action:#selector(canclePicker))
        cancelButton.tintColor = UIColor.black
        
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.barTintColor = .white
        
        
        
        
        
        let calendar = NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian);
       

        
        let components = calendar?.components([NSCalendar.Unit.year,NSCalendar.Unit.month,NSCalendar.Unit.day,NSCalendar.Unit.hour,NSCalendar.Unit.minute], from: currentDate)
        
        let maximumYear = (components?.year)! - 150
        let maximumMonth = (components?.month)! - 1
        let maximumDay = (components?.day)! - 1
        
        let comps = NSDateComponents();
        comps.year = +maximumYear
        comps.month = +maximumMonth
        comps.day = +maximumDay
        


        
        var nextDay: Date {
            return (Calendar.current as NSCalendar).date(byAdding: .day, value: 30, to: Date(), options: [])!
        }

        let end = UserDefaults.standard.object(forKey: "EndDate") as! String 
        
        let endDate = dateFormatter.date(from: end)
       

        
        
        datepicker.maximumDate = endDate
        datepicker.minimumDate = currentDate
        
        
        
        print(datepicker.maximumDate as Any)
        print(datepicker.minimumDate as Any)
        
     



    
      
        
        self.planTF.inputView = pickerView
        self.planTF.inputAccessoryView = toolBar
        
        self.fromDateTF.inputView = datepicker
        self.fromDateTF.inputAccessoryView = toolBar
        
        self.toDateTF.inputView = datepicker
        self.toDateTF.inputAccessoryView = toolBar
       
        
  
    }
    
    
    @objc func donePicker() {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        

        
        if selectedTF == self.planTF{
            
            if  self.navigationTitle.topItem?.title == "XprsClassic" {
                self.planTF.text = xprsClassic[picker.selectedRow(inComponent: 0)]
                self.planTF.resignFirstResponder()
            }else if  self.navigationTitle.topItem?.title == "XprsStandard" {
                self.planTF.text = xprsStandard[picker.selectedRow(inComponent: 0)]
                self.planTF.resignFirstResponder()
            }else if  self.navigationTitle.topItem?.title == "XprsFresh" {
                self.planTF.text = xprsFresh[picker.selectedRow(inComponent: 0)]
                self.planTF.resignFirstResponder()
            }else if self.navigationTitle.topItem?.title == "Xprs Lite" {
                self.planTF.text = xprsLite[picker.selectedRow(inComponent: 0)]
                self.planTF.resignFirstResponder()
            }else{
                self.planTF.text = planArray[picker.selectedRow(inComponent: 0)]
                self.planTF.resignFirstResponder()
            }
            
            
        } else if selectedTF == self.fromDateTF {
            
           
            let calendar = NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian);
            let weekDay = calendar?.component(.weekday, from:datepicker.date)
            if weekDay == 1 || weekDay == 7 {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select From Monday To Friday") {
                    //self.dateTF.text = ""
                }
            }else{
                
                
                self.fromDateTF.text = dateFormatter.string(from: datepicker.date)
              
                self.fromDateTF.resignFirstResponder()
            }
            
        } else if selectedTF == self.toDateTF {
            
            
            let calendar = NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian);
            let weekDay = calendar?.component(.weekday, from:datepicker.date)
            if weekDay == 1 || weekDay == 7 {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select From Monday To Friday") {
                    //self.dateTF.text = ""
                }
            }else{
                
             
                
                self.toDateTF.text = dateFormatter.string(from: datepicker.date)
                
                self.toDateTF.resignFirstResponder()
            }
            
        }
        
    }
    
    @objc func canclePicker() {
        
        self.selectedTF.resignFirstResponder()
        
    }
    
    
    
    //MARK: - IB ACTIONS
    

    
    
    @IBAction func confirm(_ sender: Any) {
        
        if !planTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Your Plan") {
                self.planTF.becomeFirstResponder()
            }
        }else if !fromDateTF.isValidMobileNumberTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select FromDate") {
                self.fromDateTF.becomeFirstResponder()
            }
        }else if !toDateTF.isValidMobileNumberTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select ToDate") {
                self.toDateTF.becomeFirstResponder()
            }
        }else if descriptionTV.text == nil {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter description") {
                self.descriptionTV.becomeFirstResponder()
            }
        }
        SingleToneClass.shared.showProgressLoading(title: "Please wait...")
       
        switchMeals()
        
    }
    
    
    
    func switchMeals ()  {
        
     
        
        let userId = UserDefaults.standard.object(forKey: "UserId")
 
        if planTF.text == "XprsClassic" {
            meals = "9"
        }else if planTF.text == "XprsStandard"{
            meals = "8"
        }else if planTF.text == "XprsFresh"{
            meals = "7"
        }else if planTF.text == "Xprs Lite"{
            meals = "6"
        }
        
        let params = ["user_id": userId!,"meal_id": meals,"fromdate": fromDateTF.text!,"todate":toDateTF.text!,"description":descriptionTV.text!]
        
        print(params)
        
        Service.shared.POSTService(serviceType: API.switchPlan, parameters: params as! [String : String] ) { (response) -> (Void) in
            
            print(response)
            
            if response != "unknown" {
                
                SingleToneClass.shared.dismissProgressLoading()
                
                guard let responseDetails = response .dictionary else{return}
                
                if let message = responseDetails["message"]?.string {
                    print(message as Any)
                    print(responseDetails as Any)
                    
                    
                    if responseDetails["code"] == 200 {
                        
                        
                        let data = responseDetails["data"]?.dictionary
                        let mealsId = data!["meals"]?.string
                        UserDefaults.standard.set(mealsId, forKey: "Meals")
                        

                       self.dismiss(animated: true)
                        SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
                        
                    }else{
                        
                        SingleToneClass.shared.dismissProgressLoading()
                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                        
                        
                    }
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server Problem") {  exit(0) }
                }
                
            }
            
        }

        
    }
    
    
    
    
    @IBAction func onTapBackBtn(_ sender: UIBarButtonItem) {

        dismiss(animated: true, completion: nil)
    }
}



extension planVC : UIPickerViewDelegate, UIPickerViewDataSource,UITextFieldDelegate {
    
    
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if selectedTF == self.planTF {
            
            if  self.navigationTitle.topItem?.title == "XprsClassic" {
                return xprsClassic.count
            }else if  self.navigationTitle.topItem?.title == "XprsStandard" {
                return xprsStandard.count
            }else if  self.navigationTitle.topItem?.title == "XprsFresh" {
                return xprsFresh.count
            }else if self.navigationTitle.topItem?.title == "Xprs Lite" {
                return xprsLite.count
            }else{
                return planArray.count
            }
        } else {
            return 0
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        
        if selectedTF == self.planTF {
            
            if self.navigationTitle.topItem?.title == "XprsClassic" {
                return xprsClassic[row]
            }else if self.navigationTitle.topItem?.title == "XprsStandard" {
                return xprsStandard[row]
            }else if self.navigationTitle.topItem?.title == "XprsFresh" {
                return xprsFresh[row]
            }else if self.navigationTitle.topItem?.title == "Xprs Lite" {
                return xprsLite[row]
            }else{
                return planArray[row]
            }
           
        } else {
            return [String]()[row]
        }
        
    }
    
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        self.selectedTF = textField
        
        return true
        
    }

    
    
}

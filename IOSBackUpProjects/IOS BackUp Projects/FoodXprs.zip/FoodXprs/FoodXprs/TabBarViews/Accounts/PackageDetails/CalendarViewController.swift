//
//  CalendarViewController.swift
//  FoodXprs
//
//  Created by MAD-MAC on 22/08/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import FSCalendar

class CalendarViewController: UIViewController,FSCalendarDataSource,FSCalendarDelegate,FSCalendarDelegateAppearance {
    
    @IBOutlet weak var leavesCountLbl: UILabel!
    
    @IBOutlet weak var planEndsDateLbl: UILabel!
    @IBOutlet weak var calendarView: FSCalendar!
    
    @IBOutlet weak var SubmitBtn: UIButton!
    
    
    fileprivate let formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    
    fileprivate let gregorian: NSCalendar! = NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian)
    
    
    var selectedDates:[String]=[]
    var selectedDateStr = String()
    let currentDate = Date()
  
    
    var dateGet = String()
    var apiDates:[String]=[]
    var holidayDates = String()
    var countedSet = NSCountedSet()
    
    let userId = UserDefaults.standard.string(forKey: "UserId")
    
  
    
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
//        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = "dd-MM-yyyy"
        
        
        SingleToneClass.shared.showProgressLoading(title: "Please Wait")
        
        myLeavesService()
        
        calendarView.allowsMultipleSelection = true
        calendarView.scrollDirection = .horizontal
      
      //  calendarView.appearance.todayColor = UIColor(red: 241/255, green: 95/255, blue: 42/255, alpha: 1.0)
        calendarView.appearance.weekdayTextColor = UIColor(red: 241/255, green: 95/255, blue: 42/255, alpha: 1.0)
      //  calendarView.appearance.DetailsStore.selectedDate  = UIColor(red: 148/255, green: 17/255, blue: 0/255, alpha: 1.0)
      //  print(DetailsStore.selectedDate.count)
        
        
        calendarView.appearance.headerMinimumDissolvedAlpha = 0.0
        
        
       let planEnds = UserDefaults.standard.object(forKey: "EndDate")
        
        if planEnds == nil {
            self.planEndsDateLbl.text = "No plan is Selected"
        }else{
            self.planEndsDateLbl.text = planEnds as? String
        }
        
      //  print(planEnds as Any)
     // calendarView.select(self.dateFormatter.date(from: planEnds as! String))
      
        
        calendarView.dataSource = self
        calendarView.delegate = self
        
         self.SubmitBtn.layer.cornerRadius = 10

        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
       
        
      
        // Do any additional setup after loading the view.
    }
    
    @IBAction func onTapBackBtn(_ sender: UIBarButtonItem) {
        
        dismiss(animated: true, completion: nil)
    }
    
    
    func myLeavesService ()  {
        
       
        let params = ["user_id":userId!]
        print(params)
        
        Service.shared.POSTService(serviceType: API.myLeaves, parameters: params ) { (response) -> (Void) in
            
                                                                                                                                                                                                                                         print(response)
            SingleToneClass.shared.dismissProgressLoading()
            
            guard let responseDetails = response .dictionary else{return}
            
             let message = responseDetails["message"]?.string
            print(message as Any)
            
                
                if responseDetails["code"] == "200"{
                    
                    let data = responseDetails["data"]?.array
                  
                  
                    
                    for i in data! {
                        
                        let dates = i["selecteddates"].string
                        print(dates as Any)
                     
                        self.apiDates.append(dates!)
                        print(self.apiDates)
                    
                        
                    }
                  
                    print(self.apiDates)
                   
//                    var arr = [String]()
//                    for i in self.apiDates {
//                    var str = ""
//                    str = i.components(separatedBy: ",")
//                    }
                  
                    let a = self.apiDates.map{$0.components(separatedBy: ",")}
                    print(a)
                    let b = Array(a.joined())
                    print(b)
                    print(b.count)
                   
                    self.apiDates = Array(Set(b))
                    print(self.apiDates)
                    
                    
                    print(self.apiDates.count)
                    self.leavesCountLbl.text = "\(self.apiDates.count)"
                    
                    let stringArray = self.apiDates.map{ String($0) }
                    self.holidayDates = stringArray.joined(separator: ",")
                    print(self.holidayDates)
                    self.calendarView.reloadData()
                    print(self.dateGet)
                 self.dateGet = ""
               print(self.dateGet)
                }else{
                    
                    self.leavesCountLbl.text = message
            }
           
        }
        
      
    }
    

    
    

    @IBAction func submitBtn(_ sender: Any) {
        
        if selectedDates == [] {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Dates From Calender") { }
        }else{
            
           
            print(userId! as Any)
            print(selectedDates)
            print(dateGet)
        //    if self.dateGet == "" {
            
            for i in 0..<selectedDates.count{
                
                let d = selectedDates[i]
                print(d)
                print(dateGet)
              //  dateGet = dateGet + "," + d
               dateGet = d + "," + dateGet
                print(dateGet)
                }
            
            
            dateGet.remove(at: dateGet.lastIndex(of: ",")!)
            print(dateGet)
            
           
            let params = ["user_id":userId!,"selecteddates":(dateGet),"message":"leave"]
            print(params)
            
            Service.shared.POSTService(serviceType: API.createleave, parameters: params ) { (response) -> (Void) in
                
                print(response)
                SingleToneClass.shared.dismissProgressLoading()
                    guard let responseDetails = response .dictionary else{return}
                
                if  let message = responseDetails["message"]?.string {
                    print(message as Any)
                    
                    if responseDetails["code"] == "200"{
                        self.apiDates.removeAll()
                        self.myLeavesService()
                       
                        SingleToneClass.shared.dismissProgressLoading()
                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                        
                    }else{
                        
                        SingleToneClass.shared.dismissProgressLoading()
                        SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                    }
                    
                }else {
                    
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") { }
                    
                }
            }

        }
    }
    

    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, titleDefaultColorFor date: Date) -> UIColor? {


        let dateString : String = formatter.string(from:date)
        print(dateString)
        print(holidayDates)
        if self.holidayDates.contains(dateString)
        {
            return UIColor.green
        }
        else{
            return nil
        }
    }
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, fillSelectionColorFor date: Date) -> UIColor? {

        let dateString = self.formatter.string(from: date)

        if self.holidayDates.contains(dateString) {
            return UIColor.orange
        }

        return appearance.selectionColor
    }
    
    func calendar(_ calendar: FSCalendar, shouldSelect date: Date, at monthPosition: FSCalendarMonthPosition) -> Bool {
        print(holidayDates)
        
       
      
        if holidayDates.contains(formatter.string(from: date)) {
            
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Already Applied leave on this day") { }
            return false
        }
        print("calendar should select date \(self.formatter.string(from: date))")
        
        return CheckSatSunday(today: date)
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        selectedDateStr = self.formatter.string(from: date)
        self.selectedDates.append(selectedDateStr)
        print(selectedDates)
        print(selectedDates.count)
        
    }
    
    func calendar(_ calendar: FSCalendar, didDeselect date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        let get = selectedDates.firstIndex(of: self.formatter.string(from: date))
        selectedDates.remove(at: get!)
        print(selectedDates)
        print(selectedDates.count)
       
        
    }
    
    func minimumDate(for calendar: FSCalendar) -> Date {
        
        return currentDate
    }
    

 func maximumDate(for calendar: FSCalendar) -> Date {
    
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "dd-MM-yyyy" //Your date format
   
    let date = dateFormatter.date(from: UserDefaults.standard.object(forKey: "EndDate") as! String)
    print(date as Any)
    
    return date!
 }
    
   
    
    func CheckSatSunday(today:Date) ->Bool{
        
        var DayExist:Bool

        
        let calendar =
            NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian)
        let components = calendar!.components([.weekday], from: today)
        
        if components.weekday == 1 {
            print("Sunday")
              SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select From Monday") { }
            DayExist = false
        } else if components.weekday == 7{
            print("Saturday")
              SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select From Monday") { }
            
            DayExist = false
        } else{
            print("It's not Saturday and  Sunday ")
            
          
            DayExist = true
        }
        print("weekday :\(String(describing: components.weekday)) ")
        return DayExist
    }
    
    

    
    
}

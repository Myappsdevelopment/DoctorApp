//
//  accountVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 19/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class accountVC: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var seeOrdersBtn: UIButton!
    
    @IBOutlet weak var renewalView: UIView!
    @IBOutlet weak var subscriptionView: UIView!
    @IBOutlet weak var nameLbl: UIBarButtonItem!
    @IBOutlet weak var sideMenuBtn: UIBarButtonItem!
    
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var table: UITableView!
    
    @IBOutlet weak var noOrderLbl: UILabel!
    var price:[String] = []
    var itemName:[String] = []
    var date:[String] = []
    
    
    
    
    
    @IBAction func btn_pwd(_ sender: Any) {
        
        
        let vc=self.storyboard?.instantiateViewController(withIdentifier: "changePasswordVC")as! changePasswordVC
        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
         self.tabBarController?.tabBar.isHidden = false
        
       
        
        let startDate = UserDefaults.standard.object(forKey: "StartDate") as? String
        
      
        if startDate == nil {
            
            subscriptionView.isHidden = true
            renewalView.isHidden = true
            
        }else{
            subscriptionView.isHidden = false
            renewalView.isHidden = false
        }
        
       
       
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let all = NotificationCenter.default
        all.addObserver(self, selector: #selector(userAll), name: NSNotification.Name("All"), object: nil)
//
        if UserDefaults.standard.string(forKey: "UserId") != nil {
            SingleToneClass.shared.showProgressLoading(title: "Please wait...")
            self.nameLbl.title = UserDefaults.standard.string(forKey: "userName")
            self.view1.isHidden = true
            self.view2.isHidden = false
             myOrders()
            
        }else{
             SingleToneClass.shared.dismissProgressLoading()
            self.nameLbl.title = "Login"
            self.view1.isHidden = false
            self.view2.isHidden = true
        }
        
        
        sideMenuBtn.target = revealViewController()
        sideMenuBtn.action = #selector(SWRevealViewController.revealToggle(_:))
        view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        
        self.navigationController?.isNavigationBarHidden = false
        self.tabBarController?.tabBar.isHidden = false
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 241/255, green: 95/255, blue: 42/255, alpha: 1.0)
        
        
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
        
       
        
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func accountDetails(_ sender: Any) {
        
        
        if nameLbl.title != "Login"{
        
        let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let gotoPickLocation = storyBoard.instantiateViewController(withIdentifier: "accountEditVC") as! accountEditVC
        
        self.navigationController?.pushViewController(gotoPickLocation, animated: true)
        }
        
    }
    
    @objc func userAll(){
     viewDidLoad()
        print("testnotification")
        
    }


   
    
    @IBAction func btn_popUpSubscription(_ sender: UIButton) {
        
        

        let POPUPVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "popUpVC") as! popUpVC
        self.addChild(POPUPVC)
        POPUPVC.view.frame = self.view.frame
        self.view.addSubview(POPUPVC.view)
        POPUPVC.didMove(toParent: self)

    }
    
    
    
    @IBAction func seeOrdersBtn(_ sender: Any) {
        
        let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let gotoPickLocation = storyBoard.instantiateViewController(withIdentifier: "PastOrdersViewController") as! PastOrdersViewController
        
        self.navigationController?.pushViewController(gotoPickLocation, animated: true)
        
        
        
    }
    
    @IBAction func renewBtn(_ sender: Any) {
        
        
         tabBarController?.selectedIndex = 2
        
    }
    
    func myOrders ()  {
        
        let userId =  UserDefaults.standard.object(forKey: "UserId") as! String
        
        let params = ["user_id":userId]
        print(params)
        
        Service.shared.POSTService(serviceType: API.myOrders, parameters: params ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            
            if response != "unknown" {
                
            guard let responseDetails = response .dictionary else{return}
            
             let message = responseDetails["message"]?.string 
            print(message as Any)
            
            if responseDetails["code"] == "200" {
                self.seeOrdersBtn.isHidden = false
                self.table.isHidden = false
                self.noOrderLbl.isHidden = true
                
                let data = responseDetails["data"]?.array
                
                for i in data! {
                    
                    let name = i["title"].string
                    let cost = i["price"].string
                    let month = i["startdate"].string
                    
                    let dateFormatterGet = DateFormatter()
                    dateFormatterGet.dateFormat = "yyyy-MM-dd HH:mm:ss"
                    
                    let dateFormatterPrint = DateFormatter()
                    dateFormatterPrint.dateFormat = "dd-MM-yyyy"
                    
                    if let date = dateFormatterGet.date(from: month!) {
                        let displayDate = dateFormatterPrint.string(from: date)
                        print(displayDate as Any)
                        self.date.append(displayDate)
                    }
 
                    
                    self.itemName.append(name!)
                    self.price.append(cost!)
                    
                    
               
                }
                
                
                DispatchQueue.main.async {
                    self.table.reloadData()
                }
                
     
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                self.seeOrdersBtn.isHidden = true
                self.table.isHidden = true
                self.noOrderLbl.isHidden = false
            }
            }else{
                SingleToneClass.shared.dismissProgressLoading()
                self.seeOrdersBtn.isHidden = true
                self.table.isHidden = true
                self.noOrderLbl.isHidden = false
            }
        }
        

        
    }
    

    
    
    
    
    
    
    
    
    
    @IBAction func logOut(_ sender: UIButton) {
        
      
        
        let alert = UIAlertController(title: "Confirmation !", message: "Are you sure,you want to Logout?", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (cancelAction) in }))
        
        alert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: { (confirmAction) in
            
            UserDefaults.standard.removePersistentDomain(forName:Bundle.main.bundleIdentifier!)
            UserDefaults.standard.synchronize()
            //   DetailsStore.loginDetails!.removeAll()
            
            let vc=self.storyboard?.instantiateViewController(withIdentifier: "loginVc")as! loginVc
            let appdelegate = UIApplication.shared.delegate as! AppDelegate
            appdelegate.window?.rootViewController = vc
            // self.navigationController?.pushViewController(vc, animated: true)
            SingleToneClass.shared.dismissProgressLoadingWithSucess(message: "LogOut Successful")
            
            
        }))
        
        present(alert, animated: true, completion: nil)
        
            
       
            
     
            
        
    }
    
    @IBAction func nameLbl(_ sender: Any) {
        
        if nameLbl.title == "Login" {
            
            
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "loginVc") as! loginVc
            self.present(nextViewController, animated:true, completion:nil)
            
        }
        
        
        
        
        
    }
    
    
    @IBAction func FAQ(_ sender: Any) {
        
        let vc=self.storyboard?.instantiateViewController(withIdentifier: "FAQViewController")as! FAQViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    

    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! OrdersTableViewCell
        
        cell.ItemNameLbl.text = itemName[indexPath.row]
        let cost = price[indexPath.row]
        let finalDate = date[indexPath.row]
        
        cell.priceLbl.text = "Rs,\(cost)*(\(finalDate))"
        print(cell.priceLbl.text)
        return cell
        
    }
    
    
    
    
    
    
    
}

//
//  OrdersTableViewCell.swift
//  FoodXprs
//
//  Created by MAD-MAC on 25/09/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class OrdersTableViewCell: UITableViewCell {

   
    @IBOutlet weak var ItemNameLbl: UILabel!
    
    
    
    @IBOutlet weak var priceLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//
//  PastOrdersViewController.swift
//  FoodXprs
//
//  Created by MAD-MAC on 04/10/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class PastOrdersViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
 
    

    @IBOutlet weak var noOrdersLbl: UILabel!
    @IBOutlet weak var table: UITableView!
    
     var date:[String] = []
    var price:[String] = []
    var itemName:[String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let imgBack = UIImage(named: "Arrow")
        
        navigationController?.navigationBar.backIndicatorImage = imgBack
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
        
        navigationItem.leftItemsSupplementBackButton = true
        navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        
        self.navigationController?.isNavigationBarHidden = false
        self.tabBarController?.tabBar.isHidden = true
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 241/255, green: 95/255, blue: 42/255, alpha: 1.0)
        self.title = "Past Orders"
        self.navigationController?.navigationBar.tintColor = .white
        //  self.navigationController?.view.backgroundColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        
        SingleToneClass.shared.showProgressLoading(title: "Please Wait")
        myOrders()
        // Do any additional setup after loading the view.
    }
    
    func myOrders ()  {
        
        let userId =  UserDefaults.standard.object(forKey: "UserId") as! String
        
        let params = ["user_id":userId]
        print(params)
        
        Service.shared.POSTService(serviceType: API.myOrders, parameters: params ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            
            if response != "unknown" {
                
                guard let responseDetails = response .dictionary else{return}
                
                let message = responseDetails["message"]?.string
                print(message as Any)
                
                if responseDetails["code"] == "200" {
                   // self.seeOrdersBtn.isHidden = false
                    self.table.isHidden = false
                    self.noOrdersLbl.isHidden = true
                    
                    let data = responseDetails["data"]?.array
                    
                    for i in data! {
                        
                        let name = i["title"].string
                        let cost = i["price"].string
                        let month = i["startdate"].string
                        
                        let dateFormatterGet = DateFormatter()
                        dateFormatterGet.dateFormat = "yyyy-MM-dd HH:mm:ss"
                        
                        let dateFormatterPrint = DateFormatter()
                        dateFormatterPrint.dateFormat = "dd-MM-yyyy"
                        
                        if let date = dateFormatterGet.date(from: month!) {
                            let displayDate = dateFormatterPrint.string(from: date)
                            print(displayDate as Any)
                            self.date.append(displayDate)
                        }
                        
                        
                        self.itemName.append(name!)
                        self.price.append(cost!)
                        
                        
                        
                    }
                    
                    
                    DispatchQueue.main.async {
                        self.table.reloadData()
                    }
                    
                    
                    
                }else{
                    
                    
                   // self.seeOrdersBtn.isHidden = true
                    self.table.isHidden = true
                    self.noOrdersLbl.isHidden = false
                }
            }else{
              //  self.seeOrdersBtn.isHidden = true
                self.table.isHidden = true
                self.noOrdersLbl.isHidden = false
            }
        }
        
        
        
    }
   
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! PastOrdersTableViewCell
        
        cell.name.text = itemName[indexPath.row]
        let cost = price[indexPath.row]
        let finalDate = date[indexPath.row]
        
        cell.priceLbl.text = "Rs,\(cost)*(\(finalDate))"
        print(cell.priceLbl.text as Any)
        return cell
        
    }

}

//
//  changePasswordVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 08/08/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class changePasswordVC: UIViewController {

    @IBOutlet weak var oldPwdTF: UITextField!
    
    @IBOutlet weak var newPwdTF: UITextField!
    
    
    @IBOutlet weak var confirmPwdTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let imgBack = UIImage(named: "Arrow")
        
        navigationController?.navigationBar.backIndicatorImage = imgBack
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
        
        navigationItem.leftItemsSupplementBackButton = true
        navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.isNavigationBarHidden = false
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 241/255, green: 95/255, blue: 42/255, alpha: 1.0)
        self.title = "Change Password"
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white

        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func submit(_ sender: Any) {
        
        if oldPwdTF.text != UserDefaults.standard.object(forKey: "Password") as? String {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter valid old password") {
                self.oldPwdTF.becomeFirstResponder()
            }
        }   else if !newPwdTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter new password") {
                self.newPwdTF.becomeFirstResponder()
            }
        } else if confirmPwdTF.text != newPwdTF.text {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Password and confirm password must be same") {
                self.confirmPwdTF.becomeFirstResponder()
            }
            
        } else {
            SingleToneClass.shared.showProgressLoading(title: "Please Wait...")
            service()
            
        }
        
        
        
        
        
        
    }
    
    
    func service () {

        let userId = UserDefaults.standard.object(forKey: "UserId") as! String
        print(userId)

        let params = ["user_id":userId,"password":confirmPwdTF.text!] as [String : Any]
        print(params)

        Service.shared.POSTService(serviceType: API.changePassword, parameters: params as! [String : String]) { (response) -> (Void) in

            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            print(responseDetails as Any)
            
            if responseDetails["code"] == "200"{
                
                
              self.navigationController?.popToRootViewController(animated: true)
                
//                let vc=self.storyboard?.instantiateViewController(withIdentifier: "SWRevealViewController")as! SWRevealViewController
//
//                let appdelegate = UIApplication.shared.delegate as! AppDelegate
//                appdelegate.window?.rootViewController = vc
                
                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "loginVc") as! loginVc
                self.present(nextViewController, animated:true, completion:nil)

                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
                
            }
                
                
            else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
            }

    }
    
    }
    
}

//
//  FAQ3ViewController.swift
//  FoodXprs
//
//  Created by MAD-MAC on 20/08/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class FAQ3ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    
    var faqArray = ["My promo code is not getting applied","I have not received the promo code for referral","Promo code expired"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return faqArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! FAQ3TableViewCell
        
        cell.faqLbl.text = faqArray[indexPath.row]
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func emailBtn(_ sender: Any) {
        
        let activityController = UIActivityViewController(activityItems: ["share"], applicationActivities: nil)
        present(activityController, animated: true, completion: nil)
    }
    
    
    @IBAction func callBtn(_ sender: Any) {
        
        if let url = URL(string: "telprompt://\(API.callPhone)") {
            
            if #available(iOS 10, *) {
                
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                
            } else {
                
                UIApplication.shared.openURL(url as URL)
                
            }
            
        }
    }
    
    
    
  

}

//
//  FAQViewController.swift
//  FoodXprs
//
//  Created by MAD-MAC on 20/08/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class FAQViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
  
    
    
    var faqArray = ["Issue with an ongoing order","Have a payment issue with My order","Issues with Promo code"]
    

    override func viewDidLoad() {
        super.viewDidLoad()

        
        let imgBack = UIImage(named: "Arrow")
        
        navigationController?.navigationBar.backIndicatorImage = imgBack
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
        
        navigationItem.leftItemsSupplementBackButton = true
        navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.isNavigationBarHidden = false
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 241/255, green: 95/255, blue: 42/255, alpha: 1.0)
        self.title = "Help"
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
        
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return faqArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! FAQTableViewCell
     
        cell.FaqLbl.text = faqArray[indexPath.row]
        return cell
        
    }
    

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0 {
            let vc=self.storyboard?.instantiateViewController(withIdentifier: "FAQ1ViewController")as! FAQ1ViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }else if indexPath.row == 1 {
            let vc=self.storyboard?.instantiateViewController(withIdentifier: "FAQ2ViewController")as! FAQ2ViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }else if indexPath.row == 2 {
            let vc=self.storyboard?.instantiateViewController(withIdentifier: "FAQ3ViewController")as! FAQ3ViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    
    
}

//
//  FAQ3TableViewCell.swift
//  FoodXprs
//
//  Created by MAD-MAC on 20/08/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class FAQ3TableViewCell: UITableViewCell {

    @IBOutlet weak var faqLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//
//  FAQ2ViewController.swift
//  FoodXprs
//
//  Created by MAD-MAC on 20/08/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class FAQ2ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var faqArray = ["Amount is debited from My Account but payment confirmation not received from Food Xprs","Wrong / excess amount debit not credited back into My Account"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return faqArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! FAQ2TableViewCell
        
        cell.faqLbl.text = faqArray[indexPath.row]
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func emailBtn(_ sender: Any) {
        
        let activityController = UIActivityViewController(activityItems: ["share"], applicationActivities: nil)
        present(activityController, animated: true, completion: nil)
    }
    
    
    @IBAction func callBtn(_ sender: Any) {
        
        if let url = URL(string: "telprompt://\(API.callPhone)") {
            
            if #available(iOS 10, *) {
                
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                
            } else {
                
                UIApplication.shared.openURL(url as URL)
                
            }
            
        }
        
    }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  FAQ1ViewController.swift
//  FoodXprs
//
//  Created by MAD-MAC on 20/08/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class FAQ1ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    
    @IBOutlet weak var callBtn: UIButton!
    
    var faqArray = ["Check the status of My order","My order is taking longer than expected","My order has missing or incorrect food items","My order is damaged"]
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return faqArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! FAQ1TableViewCell
        
        cell.faqLbl.text = faqArray[indexPath.row]
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func contactNumber(_ sender: Any) {

        
        if let url = URL(string: "telprompt://\(API.callPhone)") {
            
            if #available(iOS 10, *) {
                
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                
            } else {
                
                UIApplication.shared.openURL(url as URL)
                
            }
            
        }
        
        
        
    }
    
    @IBAction func emailBtn(_ sender: Any) {
        
        let activityController = UIActivityViewController(activityItems: ["share"], applicationActivities: nil)
        present(activityController, animated: true, completion: nil)
    }
    
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  mealVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 23/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import Kingfisher

class mealVC: UIViewController,UITableViewDelegate,UITableViewDataSource {


    @IBOutlet weak var tableView: UITableView!
    


    
   // var DetailsStore.getTag:Int?
    var cellImage:Int?
    
    var priceAll : String?
    var contentAll : String?
    var TitleAll : String?
    var ImageAll : String?
    var titleId : String?
    
    var location :String?
    
    
    let defaultColor = UIColor(red: 62/255.0, green: 61/255.0, blue: 63/255.0, alpha: 1)
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = true
         SingleToneClass.shared.dismissProgressLoading()
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
         SingleToneClass.shared.dismissProgressLoading()              
        print(DetailsStore.getTag as Any)
//
        if DetailsStore.selectedStatus == true{
            DetailsStore.selectedStatus = false

         DetailsStore.getTag = DetailsStore.getTag! - 1

            DetailsStore.namesLbl.remove(at: 0)
            DetailsStore.updated =  DetailsStore.namesLbl


            DetailsStore.imageNames.remove(at: 0)
            DetailsStore.img = DetailsStore.imageNames

            DetailsStore.contentNames.remove(at: 0)
            DetailsStore.orderContent = DetailsStore.contentNames

          print(DetailsStore.prices)
            DetailsStore.prices.remove(at: 0)
            DetailsStore.orderPrice = DetailsStore.prices

//            print(DetailsStore.orderId)
//            DetailsStore.orderId.remove(at: 0)
//            DetailsStore.packageOrderId = DetailsStore.orderId
//            print(DetailsStore.packageOrderId)


            print(DetailsStore.img)
            tableView.reloadData()
      }
           else{

            if DetailsStore.backStatus == true{
                DetailsStore.backStatus = false
                print(DetailsStore.packageOrderId)
                print(DetailsStore.orderPrice)
                print(DetailsStore.orderContent)
                print(DetailsStore.updated)

            //    DetailsStore.packageOrderId.remove(at: 0)
                DetailsStore.img.remove(at: 0)
                DetailsStore.updated.remove(at: 0)
                DetailsStore.orderPrice.remove(at: 0)
                DetailsStore.orderContent.remove(at: 0)
                print(DetailsStore.packageOrderId)
                print(DetailsStore.orderPrice)
                print(DetailsStore.orderContent)
                 print(DetailsStore.updated)
            tableView.reloadData()
            }
        }
//
        
        
        
        
        
        

       
        
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
        
        tableView.delegate = self
        tableView.dataSource = self
  
        let imgBack = UIImage(named: "Arrow")
        
        navigationController?.navigationBar.backIndicatorImage = imgBack
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
        
        navigationItem.leftItemsSupplementBackButton = true
        navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        
        
        self.navigationController?.isNavigationBarHidden = false
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 241/255, green: 95/255, blue: 42/255, alpha: 1.0)
        self.title = "Select Your Meal"
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
    
    }
    



    
    @IBAction func btn_tappedNext(_ sender: UIButton) {
        
        
        print(contentAll as Any)
        print(TitleAll as Any)
        print(priceAll as Any)
        print(ImageAll as Any)
        print(location as Any)
        print(titleId as Any)
        
        if (ImageAll == nil) {
            
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select one package") { }
        }else {
          SingleToneClass.shared.showProgressLoading(title: "Please wait...")
          createOrderService()
        }
        
    }
    
 
    
    
    func createOrderService()  {
        
        //  let userId =  UserDefaults.standard.object(forKey: "UserId")
        let userName = UserDefaults.standard.object(forKey: "userName") as! String
        let userId =  UserDefaults.standard.object(forKey: "UserId") as! String
        let startDate = DetailsStore.saveDate
        
        
        
        let params = ["user_id":userId,"username":userName,"location":location!,"meal":TitleAll!,"startdate":startDate,"meal_id":titleId!]
        
        print(params)
        
        Service.shared.POSTService(serviceType: API.createOrder, parameters: params ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                print(message as Any)
                print(responseDetails as Any)
                
                if responseDetails["code"] == "200"{
                    
                    let data = responseDetails["data"]?.dictionary
                    
                     let orderId = data!["ID"]?.string
                     DetailsStore.changeOrderId = true
//                    self.redeemLbl.text = data!["credits"]?.string
//                    self.itemTotalLbl.text = data!["amount"]?.string
//                    // let coupon = data!["coupon"]?.string
//
//
//                    if self.itemTotalLbl.text == "" {
//                        self.itemTotalLbl.text = "1200"
//                    }
                    
                    
                    let vc=self.storyboard?.instantiateViewController(withIdentifier: "PriceDetailsViewController")as! PriceDetailsViewController
                    
                    
                    vc.finalContent = self.contentAll
                    vc.finalTitle = self.TitleAll
                    vc.finalprice = self.priceAll
                    vc.finalImage = self.ImageAll
                    vc.orderId = orderId
                    vc.location = self.location
                    vc.titleID = self.titleId
                    self.navigationController?.pushViewController(vc, animated: true)
               
                    
                    
                    
                    
                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message)
                    
                }
                    
                    
                else{
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") { }
            }
            
        }
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if DetailsStore.selectedStatus == true{
            return DetailsStore.namesLbl.count
        }else{
            return DetailsStore.updated.count
            
        }
       
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! MealsVcTableViewCell

      
         cell.buttonImage1.addTarget(self, action: #selector(btn1), for: .touchUpInside)
         cell.buttonImage2.addTarget(self, action: #selector(btn2), for: .touchUpInside)
        
        cell.buttonImage1.tag = indexPath.row
        cell.buttonImage2.tag = indexPath.row
        
        if DetailsStore.selectedStatus == true{
            print(DetailsStore.getTag as Any)
            print(indexPath.row)
            if DetailsStore.getTag == indexPath.row {
                print(DetailsStore.getTag as Any)
                cell.buttonImage2.isHidden = false
                cell.buttonImage1.isHidden = true
                let modifier = AnyImageModifier { return $0.withRenderingMode(.alwaysOriginal) }
                
                cell.nameLbl.text = DetailsStore.namesLbl[indexPath.row]
                self.titleId = DetailsStore.orderId[indexPath.row]
                print(titleId as Any)
                
                let ImageSize = URL(string:DetailsStore.imageNames[indexPath.row])
                cell.buttonImage2.kf.setImage(with: ImageSize, for: .normal,options: [.imageModifier(modifier)])
                cell.buttonImage1.kf.setImage(with: ImageSize, for: .normal,options: [.imageModifier(modifier)])
                TitleAll = cell.nameLbl.text
                print(TitleAll as Any)
                ImageAll = DetailsStore.imageNames[indexPath.row]
                priceAll = DetailsStore.prices[indexPath.row]
                print(priceAll as Any)
                contentAll = DetailsStore.contentNames[indexPath.row]
                print(contentAll as Any)
                cell.buttonImage1.isHidden = true

                
                cell.buttonImage1.layer.borderWidth = 3
                cell.buttonImage2.layer.borderWidth = 3
                cell.buttonImage2.layer.borderColor = defaultColor.cgColor
                
                
               
                
            } else {
                
                cell.buttonImage1.isHidden = false
                cell.buttonImage2.isHidden = true
                let modifier = AnyImageModifier { return $0.withRenderingMode(.alwaysOriginal) }
                
                
                let ImageSize = URL(string: DetailsStore.imageNames[indexPath.row])
                cell.nameLbl.text = DetailsStore.namesLbl[indexPath.row]
            
                cell.buttonImage1.kf.setImage(with: ImageSize!, for: .normal,options: [.imageModifier(modifier)])
                cell.buttonImage2.kf.setImage(with: ImageSize, for: .normal,options: [.imageModifier(modifier)])
                cell.buttonImage2.isHidden = true
                
                
                
                cell.buttonImage1.layer.borderColor = defaultColor.cgColor
                cell.buttonImage1.layer.borderWidth = 3
                cell.buttonImage2.layer.borderWidth = 3
                
                
            }
        }
        else{
            if DetailsStore.getTag == indexPath.row {
                print(DetailsStore.getTag as Any)
                cell.buttonImage2.isHidden = false
                cell.buttonImage1.isHidden = true
                let modifier = AnyImageModifier { return $0.withRenderingMode(.alwaysOriginal) }
                
                cell.nameLbl.text = DetailsStore.updated[indexPath.row]
                 self.titleId = DetailsStore.packageOrderId[indexPath.row]
                print(titleId as Any)
                let ImageSize = URL(string:DetailsStore.img[indexPath.row])
                
                cell.buttonImage2.kf.setImage(with: ImageSize, for: .normal,options: [.imageModifier(modifier)])
                cell.buttonImage1.kf.setImage(with: ImageSize, for: .normal,options: [.imageModifier(modifier)])
                cell.buttonImage1.isHidden = true
                
                TitleAll = cell.nameLbl.text
                print(TitleAll as Any)
                ImageAll = DetailsStore.img[indexPath.row]
                priceAll = DetailsStore.orderPrice[indexPath.row]
                print(DetailsStore.orderPrice[indexPath.row])
                print(priceAll as Any)
                contentAll = DetailsStore.orderContent[indexPath.row]
                print(contentAll as Any)
                
             
                
                cell.buttonImage1.layer.borderWidth = 3
                cell.buttonImage2.layer.borderWidth = 3
                cell.buttonImage2.layer.borderColor = defaultColor.cgColor
                
               
                
            } else {
                
                cell.buttonImage1.isHidden = false
                cell.buttonImage2.isHidden = true
                let modifier = AnyImageModifier { return $0.withRenderingMode(.alwaysOriginal) }
                
                
                let ImageSize = URL(string: DetailsStore.img[indexPath.row])
                cell.nameLbl.text = DetailsStore.updated[indexPath.row]
                
                
                print(cell.nameLbl.text as Any)
                cell.buttonImage1.kf.setImage(with: ImageSize, for: .normal,options: [.imageModifier(modifier)])
                cell.buttonImage2.kf.setImage(with: ImageSize, for: .normal,options: [.imageModifier(modifier)])
                cell.buttonImage2.isHidden = true
                
              
                cell.buttonImage1.layer.borderColor = defaultColor.cgColor
                cell.buttonImage1.layer.borderWidth = 3
                cell.buttonImage2.layer.borderWidth = 3
                
                
            }
            
        }
        return cell
        
    }
    
    @objc func btn1(sender:UIButton){
        DetailsStore.getTag = sender.tag
        tableView.reloadData()
        
        
    }
    @objc func btn2(sender:UIButton){
        // getTag = sender.tag
        // tableView.reloadData()
        ImageAll = nil
    }
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
//    {
//        return tableView.frame.size.height/4
//    }
    
}

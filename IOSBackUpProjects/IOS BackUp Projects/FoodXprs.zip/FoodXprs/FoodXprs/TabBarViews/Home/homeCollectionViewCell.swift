//
//  homeCollectionViewCell.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 31/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class homeCollectionViewCell: UICollectionViewCell {
    
   
    @IBOutlet weak var month: UILabel!
    @IBOutlet weak var imageName: UIImageView!
    
    @IBOutlet weak var boxImage: UIImageView!
    @IBOutlet weak var ImageNameLbl: UILabel!
    @IBOutlet weak var costLbl: UILabel!
    @IBOutlet weak var itemsLbl: UILabel!
    @IBOutlet weak var favoriteButton: UIButton!
    
   var b1Change:Bool = true
    
   
    
    @IBAction func favoriteBtn(_ sender: Any) {
        
        
              b1Change = !b1Change
                print(b1Change)
        
                if b1Change {
                    favoriteButton.setImage(UIImage(named: "Favourite"), for: .normal)
                } else {
                    favoriteButton.setImage(UIImage(named: "Favourite icon stroke"), for: .normal)
                }
        
        
    }
    
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        DispatchQueue.main.async {
//            imageName.roundCorners([.topLeft, .topRight], radius: 10)
//            self.imageName.roundCorners([.topRight,.topLeft], radius: 8)
//            self.imageName.layer.masksToBounds = true
//        }
//    }
   
    
}

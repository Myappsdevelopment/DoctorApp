//
//  homePageVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 22/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import Kingfisher

class homePageVC: UIViewController {

    @IBOutlet weak var sideMenu: UIBarButtonItem!
    @IBOutlet weak var nameBtn: UIBarButtonItem!
    @IBOutlet weak var page: UIPageControl!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var tagImages:[Int] = []
 
    
    
    var limit = 0
    var x: Int = 0
    var strIndex:Int = 1
    var image:String?
    var favorateBtn:Bool = true
    
 
    var price:[String] = []
    var content:[String]=[]
    var packageName:[String]=[]
    var imageItem:[String]=[]
    var packageID:[String]=[]
    

    
    
    
    override func viewWillAppear(_ animated: Bool) {
        scrollViewDidEndDecelerating(collectionView)
         self.tabBarController?.tabBar.isHidden = false
       
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
       
        packageService()
         SingleToneClass.shared.showProgressLoading(title: "Please wait...")
        
        if UserDefaults.standard.string(forKey: "userName") != nil {
            
            self.nameBtn.title = UserDefaults.standard.string(forKey: "userName")
            print(self.nameBtn.title as Any)
            
        }else{
            self.nameBtn.title = "Login"
        }
        
        
        
        self.navigationController?.isNavigationBarHidden = false
        
       
        sideMenu.target = revealViewController()
        sideMenu.action = #selector(SWRevealViewController.revealToggle(_:))
       // view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())   
        
        let floawLayout = UPCarouselFlowLayout()
        floawLayout.itemSize = CGSize(width: UIScreen.main.bounds.size.width, height: collectionView.frame.size.height)
        floawLayout.scrollDirection = .horizontal
      //  floawLayout.scrollDirection = .vertical
        floawLayout.sideItemScale = 0.8
        floawLayout.sideItemAlpha = 1.0
       // floawLayout.spacingMode = .fixed(spacing: 05.0)
        collectionView.collectionViewLayout = floawLayout
       // UIView.transition(with: , duration: 0.3, options: .transitionFlipFromLeft, animations: nil, completion: nil)
        collectionView.isPagingEnabled = true
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                exit(0)
                
            }
        }
        
       
    }
   
    
  
    @IBAction func loginBtn(_ sender: Any) {
        
        if nameBtn.title == "Login" {
            
            
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "loginVc") as! loginVc
            self.present(nextViewController, animated:true, completion:nil)
            
            
            
        }
        
        
    }
    
    func packageService()  {
        
         SingleToneClass.shared.showProgressLoading(title: "Please wait...")
        Service.shared.GETService(extraParam: API.package) { (response) -> (Void) in
            
            print(response)
              SingleToneClass.shared.dismissProgressLoading()
            print(response .dictionary as Any)
          // guard let responseDetails = response.dictionary else{return}
            if let reponseDetails = response.dictionary {
            
                let message = reponseDetails["message"]?.string
            print(message as Any)
                let imagePath = reponseDetails["image_path"]?.string
            print(imagePath as Any)
                if reponseDetails["code"] == "200" {
               
                    if let data = reponseDetails["data"]?.array {
                    
                    self.imageItem.append("box")
                    self.price.append("")
                    self.content.append("")
                    self.packageName.append("")
//
                
                for i in data {
                    
                    let packageId = i["ID"].string
                    print(packageId as Any)
    
                    let packageDetailsNames = i["title"].string
                    print(packageDetailsNames as Any)
                    let packageContent = i["content"].string
                    print(packageContent as Any)
                    let packagePrice = i["price"].string
                    print(packagePrice as Any)
                    let packageImage = i["image"].string
                    self.image = imagePath! + packageImage!
                    
                   self.packageID.append(packageId!)
                    print(self.packageID)
        
                self.packageName.append(packageDetailsNames!)
                    print(self.packageName)
                self.content.append(packageContent!)
                    print(self.content)
                self.price.append(packagePrice!)
                   print(self.price)
                self.imageItem.append(self.image!)
                    print(self.imageItem)
                    
                
            }
                    DetailsStore.updated = self.packageName
                    DetailsStore.img = self.imageItem
                    DetailsStore.orderContent = self.content
                    DetailsStore.orderPrice = self.price
                    DetailsStore.packageOrderId = self.packageID
                        
                    print(self.packageID.count)
                    print(self.packageName.count)
                    print(self.content.count)
                    print(self.price.count)
                    print(self.imageItem.count)
                        
                        
                    DispatchQueue.main.async {
                        self.collectionView.reloadData()
                    }
                    
        
                }
        
                }else{
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
                }
        
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") {
                    exit(0)
                }
                
            }
   
    }
    
 }
    
}


extension homePageVC: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    
        page.numberOfPages=self.packageName.count
        return self.packageName.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
   
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! homeCollectionViewCell
        
        print(indexPath.row)
        print(cell)
        
        cell.costLbl.text = self.price[indexPath.row]
        cell.ImageNameLbl.text = self.packageName[indexPath.row]
        cell.itemsLbl.text = self.content[indexPath.row]
        
//        cell.ImageNameLbl.font = UIFont(name: "Rancho-Regular.ttf", size: 15.0)
//        cell.ImageNameLbl.font = UIFont(name: "Rancho-Regular", size: 15)
        
        
        if indexPath.row == 0{
            cell.month.text = ""
            cell.boxImage.isHidden = false
            cell.boxImage.image = UIImage(named: "box")
        }else{
            cell.boxImage.isHidden = true
            let ImageSize = URL(string: imageItem[indexPath.row])
            cell.imageName.kf.setImage(with:ImageSize!)
            cell.month.text = "*/month"
        }
      

        
        cell.imageName.layer.cornerRadius = cell.imageName.frame.size.width / 2
        cell.imageName.clipsToBounds = true
        cell.imageName.layer.borderWidth = 05
        cell.imageName.layer.borderColor = UIColor.white.cgColor
        
        tagImages.append(indexPath.row)
        
        

        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        let rotationAngleInRadians = 360 * CGFloat(.pi/360.0)
        let rotationTransform = CATransform3DMakeRotation(rotationAngleInRadians, 0, 100, 0)
        cell.layer.transform = rotationTransform
        UIView.animate(withDuration: 1.0, animations: {
            cell.alpha = 1.0
            cell.layer.transform = CATransform3DIdentity
        })
        if indexPath.row == imageItem.count - 1{
            limit = limit + 1
//            self.getURL()
//            self.prograssion.stopAnimating()
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offSet = scrollView.contentOffset.x
        print(offSet)
        let width = scrollView.frame.width
        let horizontalCenter = width / 2
        
        
        page.currentPage = Int(offSet + horizontalCenter) / Int(width)
        print(page.currentPage)
        
       
      
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width:collectionView.frame.width, height: collectionView.frame.height)
        
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if nameBtn.title == "Login" {
            
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "loginVc") as! loginVc
            self.present(nextViewController, animated:true, completion:nil)
        } else {
        
            
            if indexPath.row == 0{
                
            }else{
                
    
            
            DetailsStore.selectedStatus = true


            DetailsStore.namesLbl = packageName
            DetailsStore.imageNames = imageItem
            DetailsStore.contentNames = content
            DetailsStore.prices = price
            DetailsStore.orderId = packageID
            DetailsStore.getTag = tagImages[indexPath.row]
        
             tabBarController?.selectedIndex = 2
           

            

            }
            
            
        }
        
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
    {
        var visibleRect = CGRect()
        
        visibleRect.origin = collectionView.contentOffset
        visibleRect.size =  collectionView.bounds.size
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
        print(visiblePoint)
        guard let indexPath =  collectionView.indexPathForItem(at: visiblePoint) else { return }
        
        x = indexPath.row
        
        print(x)
        strIndex = indexPath.row
        print(strIndex)
        
        let indexPathrow = IndexPath(item: x, section: 0)
        self.collectionView.scrollToItem(at: indexPathrow, at: .centeredHorizontally, animated: true)
        
  
        print(indexPath.row)
    }
    
    
}
extension UIImageView {
    public func roundCorners(_ corners: UIRectCorner, radius: CGFloat) {
        let maskPath = UIBezierPath(roundedRect: bounds,
                                    byRoundingCorners: corners,
                                    cornerRadii: CGSize(width: radius, height: radius))
        let shape = CAShapeLayer()
        shape.path = maskPath.cgPath
        layer.mask = shape
    }
}

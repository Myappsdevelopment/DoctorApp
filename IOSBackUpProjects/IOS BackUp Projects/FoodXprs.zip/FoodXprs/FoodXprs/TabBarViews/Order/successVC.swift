//
//  successVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 29/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class successVC: UIViewController {

    @IBOutlet weak var btn_home: UIButton!
    
    
    override func viewWillAppear(_ animated: Bool) {
         self.navigationController?.isNavigationBarHidden = true
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        self.btn_home.layer.cornerRadius = 8
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        // Do any additional setup after loading the view.
    }
    



    @IBAction func btn_tappedHome(_ sender: UIButton) {

        DetailsStore.selectedStatus = false
         DetailsStore.backStatus = true
        let vc=self.storyboard?.instantiateViewController(withIdentifier: "tabBarVC")as! tabBarVC
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
}

//
//  PriceDetailsViewController.swift
//  FoodXprs
//
//  Created by MAD-MAC on 05/08/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import Kingfisher
import PaymentSDK


class PriceDetailsViewController: UIViewController,UITextFieldDelegate,PGTransactionDelegate {

   
    @IBOutlet weak var promoCodeBtn: UIButton!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var contentLbl: UILabel!
    @IBOutlet weak var priceLbl: UILabel!
    @IBOutlet weak var itemImage: UIImageView!
    
    @IBOutlet weak var itemTotalLbl: UILabel!
    @IBOutlet weak var netPayableLbl: UILabel!
    @IBOutlet weak var gstLbl: UILabel!
    @IBOutlet weak var discountLbl: UILabel!
    @IBOutlet weak var redeemLbl: UILabel!
    
    @IBOutlet weak var payLbl: UILabel!
    @IBOutlet weak var startDateTF: TextField!
    
    @IBOutlet weak var endDateTF: TextField!
    @IBOutlet weak var checkMarkBtn: UIButton!
    @IBOutlet weak var promocodeTF: UITextField!
    @IBOutlet weak var steelBox: UIStackView!
    @IBOutlet weak var steelBoxAmtLbl: UILabel!
    
    var finalprice : String?
    var finalContent : String?
    var finalTitle : String?
    var finalImage : String?
    var titleID : String?
    
    
     let picker = UIPickerView()
     let datepicker=UIDatePicker()
     let currentDate = Date()
     let finalFormatter = DateFormatter()
     var selectedTF = UITextField()
     let toolBar = UIToolbar()
    
    var unchecked = true
    var promocodeCheck = true
    var redeemCheck = true
    
    var location :String?
    var orderId : String?
    var endDate : String?
//    var couponValidation : String?
//    var couponAmount : String?
    
    
    var promoDiscountAmt = Int()
    var itemTotalAmt = Int()
    var steelBoxAmt = Int()
    var gstAmt = Int()
   
    
    var creditsAmt = Int()
    var netPayableAmt = Int()
    var payAmt = Int()
    
    
    var txnId = String()
    var txnAmount = String()
    var txnDate = String()
  
    let userId =  UserDefaults.standard.object(forKey: "UserId") as! String
    let mobileNo = UserDefaults.standard.object(forKey: "mobile") as! String
    let emailId = UserDefaults.standard.object(forKey: "emailId") as! String
    
    var txnController = PGTransactionViewController()
    var serv = PGServerEnvironment()
    var checksumValue = String()
    var midValue = String()
    var callBackUrlValue = String()
    
 
    let defaultColor = UIColor(red: 241/255.0, green: 95/255.0, blue: 42/255.0, alpha: 1)
  
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      self.startDateTF.text = DetailsStore.saveDate
        
        updateDate()
        
        createPicker()
        
        
        let imgBack = UIImage(named: "Arrow")
        
        navigationController?.navigationBar.backIndicatorImage = imgBack
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
        
        navigationItem.leftItemsSupplementBackButton = true
        navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        
        self.navigationController?.isNavigationBarHidden = false
        self.tabBarController?.tabBar.isHidden = true
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 241/255, green: 95/255, blue: 42/255, alpha: 1.0)
        self.title = "Payment Details"
        self.navigationController?.navigationBar.tintColor = .white
        //  self.navigationController?.view.backgroundColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false
        // Do any additional setup after loading the view.
        
        promocodeTF.delegate = self
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
        promoCodeBtn.layer.cornerRadius = 10
        promoCodeBtn.clipsToBounds = true
        itemImage.layer.borderWidth = 3
        itemImage.layer.borderColor = defaultColor.cgColor
       // itemImage.layer.cornerRadius = 40
        itemImage.layer.cornerRadius = itemImage.frame.size.width / 2
        checkMarkBtn.layer.borderWidth = 1
        checkMarkBtn.layer.borderColor = UIColor.orange.cgColor
        startDateTF.layer.borderWidth = 1
        endDateTF.layer.borderWidth = 1
        startDateTF.layer.borderColor = defaultColor.cgColor
        endDateTF.layer.borderColor = defaultColor.cgColor
        
        
        
        
        
        
        startDateTF.delegate = self
        endDateTF.delegate = self
        
        checkMarkBtn.setImage( UIImage(named:"Untitled-3"), for:[])
        
        
        
        
        let steelBoxDisplay = UserDefaults.standard.object(forKey: "TiffinBox") as! String
        
        if steelBoxDisplay == "0" {
            self.steelBox.isHidden = false
            steelBoxAmtLbl.text = "500"
            self.steelBoxAmt = 500
            self.gstAmt = 85
            
        }else{
            self.steelBox.isHidden = true
             steelBoxAmtLbl.text = "0"
            steelBoxAmt = 0
            self.gstAmt = 60
        }
        
      
        
        titleLbl.text = finalTitle
        print(titleLbl.text as Any)
        
        contentLbl.text = finalContent!
        priceLbl.text = finalprice!
        
        
        let url = URL(string: finalImage!)!
        itemImage.kf.setImage(with: url)
        
        
        
    }
        

    
    
    
    
    @IBAction func payBtn(_ sender: Any) {
        
          SingleToneClass.shared.showProgressLoading(title: "Please wait...")

        if DetailsStore.changeOrderId == false {
            createOrderService()

        }else{
            DetailsStore.changeOrderId = false
             checksumService()
        }


        
        
    }
    
    
    func createPicker(){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
       
        
        datepicker.datePickerMode = .date
        datepicker.setDate(Date(), animated: true)

        
        
        let pickerView = picker
        pickerView.backgroundColor = .white
        pickerView.showsSelectionIndicator = true
        
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action:#selector(donePicker))
        doneButton.tintColor = UIColor.black
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action:#selector(canclePicker))
        cancelButton.tintColor = UIColor.black
        
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.barTintColor = .white
        
        
        
        
        
        let calendar = NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian);
        
        let components = calendar?.components([NSCalendar.Unit.year,NSCalendar.Unit.month,NSCalendar.Unit.day,NSCalendar.Unit.hour,NSCalendar.Unit.minute], from: currentDate )
        
        let maximumYear = (components?.year)! - 150
        let maximumMonth = (components?.month)! - 1
        let maximumDay = (components?.day)! - 1
        
        let comps = NSDateComponents();
        comps.year = +maximumYear
        comps.month = +maximumMonth
        comps.day = +maximumDay
        
        
        var thirtyDaysfromNow: Date {
            return (Calendar.current as NSCalendar).date(byAdding: .day, value: 30, to: Date(), options: [])!
        }
        

        
        
        datepicker.maximumDate = thirtyDaysfromNow
        datepicker.minimumDate = datepicker.date
        
        
        self.startDateTF.inputView = datepicker
        self.startDateTF.inputAccessoryView = toolBar
        
       
        
        
    }
    
    
    @objc func donePicker() {
        
        let dateFormatter = DateFormatter()
      //  dateFormatter.dateFormat = "MM/dd/yyyy"
          dateFormatter.dateFormat = "dd-MM-yyyy"
        
       

        if selectedTF == self.startDateTF {
            
           
            let calendar = NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian);
            let weekDay = calendar?.component(.weekday, from:datepicker.date)
            if weekDay == 1 || weekDay == 7 {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select From Monday") {
                    //self.dateTF.text = ""
                }
            }else{
                self.startDateTF.text = dateFormatter.string(from: datepicker.date)
                //self.endDateTF.text = dateFormatter.string(from: endDate)
                updateDate()
                self.startDateTF.resignFirstResponder()
            }
            
            
            
            
           
            
        }
    }
    
    @objc func canclePicker() {
        
        self.selectedTF.resignFirstResponder()
        
    }
    
  
    @IBAction func promocodeBtn(_ sender: Any) {
        
        
      if !promocodeTF.isValidTextField() {
        
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter promocode") {
                
                self.discountLbl.text = "0"
                
                if self.unchecked == false {
                    
                    self.payAmt = (self.itemTotalAmt + self.gstAmt + self.steelBoxAmt) - (self.creditsAmt)
                    print(self.payAmt)
                    
                }else {
                    
                    self.payAmt = (self.itemTotalAmt + self.gstAmt + self.steelBoxAmt)
                    print(self.payAmt)
                    
                }
                
                self.netPayableLbl.text = "\(self.payAmt)"
                self.payLbl.text = "\(self.payAmt)"
                
                
                self.promocodeTF.becomeFirstResponder()
            }
        
        }else if promoCodeBtn.titleLabel?.text == "APPLY" {
                SingleToneClass.shared.showProgressLoading(title: "Please Wait")
               self.promocodeService()
       
                

        }else{
                self.promocodeTF.text = ""
                 promoCodeBtn.setTitle("APPLY", for: [])
                 self.promocodeTF.isEnabled = true

                if unchecked == false {

                    self.payAmt = (itemTotalAmt + gstAmt + steelBoxAmt) - (creditsAmt)
                    print(self.payAmt)

                }else {

                    self.payAmt = (itemTotalAmt + gstAmt + steelBoxAmt)
                    print(self.payAmt)

                }

                self.discountLbl.text = "0"



                self.netPayableLbl.text = "\(payAmt)"
                self.payLbl.text = "\(payAmt)"
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: "Promocode Removed")
                SingleToneClass.shared.dismissProgressLoading(WithDelay: 5)
                promocodeCheck = true

        }
        

        
    }
    
    
    
    func promocodeService ()  {
        

        
            let params = ["user_id":userId,"coucode":promocodeTF.text!]
        
        print(params)
        
        Service.shared.POSTService(serviceType: API.promocode, parameters: params ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["text"]?.string {
                print(message as Any)
                print(responseDetails as Any)
                
                if responseDetails["code"] == "200"{
                    self.promoDiscountAmt = 100
                  //  self.promocodeTF.text = "100"
                    
                    self.promocodeTF.isEnabled = false
                    self.promoCodeBtn.setTitle("REMOVE", for: [])


                    self.discountLbl.text = "\(self.promoDiscountAmt)"

                    if self.unchecked == false {

                        self.payAmt = (self.itemTotalAmt + self.gstAmt + self.steelBoxAmt) - (self.promoDiscountAmt + self.creditsAmt)
                        print(self.payAmt)

                    }else {

                        self.payAmt = (self.itemTotalAmt + self.gstAmt + self.steelBoxAmt) - (self.promoDiscountAmt)
                        print(self.payAmt)

                    }


                    self.netPayableLbl.text = "\(self.payAmt)"
                    self.payLbl.text = "\(self.payAmt)"

                    SingleToneClass.shared.dismissProgressLoadingWithSucess(message: "Promocode applied successfully")
                    SingleToneClass.shared.dismissProgressLoading(WithDelay: 5)
                    self.promocodeCheck = false

                    
                }
                    
                    
                else{
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") { }
            }
            
        }
        
        
        
        
    }
    
    
    
    
    
    
    @IBAction func redeemCheckmarkBtn(_ sender: Any) {
        
        
        if unchecked {
            
            //check
             checkMarkBtn.setImage( UIImage(named:"Untitled-2"), for:[])
          
            if promocodeCheck == false {
            
            self.payAmt = (itemTotalAmt + gstAmt  + steelBoxAmt) - (promoDiscountAmt + creditsAmt)
            print(self.payAmt)
                
            }else{
                
                self.payAmt = (itemTotalAmt + gstAmt  + steelBoxAmt) - (creditsAmt)
                print(self.payAmt)
                
            }
            
            self.netPayableLbl.text = "\(payAmt)"
            self.payLbl.text = "\(payAmt)"
            
             unchecked = false

        }
        else {
            //uncheck
             checkMarkBtn.setImage(UIImage(named:"Untitled-3"), for: [])
           
            if promocodeCheck == false {
                
                self.payAmt = (itemTotalAmt + gstAmt  + steelBoxAmt) - (promoDiscountAmt)
                print(self.payAmt)
                
            }else{
                
                self.payAmt = (itemTotalAmt + gstAmt  + steelBoxAmt)
                print(self.payAmt)
                
            }
            
            
            
          
            self.netPayableLbl.text = "\(payAmt)"
            self.payLbl.text = "\(payAmt)"
             unchecked = true

        }
        
        
        
        
        
        
    }
    
    func createOrderService()  {
        
        
        let userName = UserDefaults.standard.object(forKey: "userName") as! String
       
        
        
        
        let params = ["user_id":userId,"username":userName,"location":location,"meal":titleLbl.text,"startdate":startDateTF.text!,"meal_id":titleID!]
        
        print(params)
        
        Service.shared.POSTService(serviceType: API.createOrder, parameters: params as! [String : String] ) { (response) -> (Void) in
            
            print(response)
            SingleToneClass.shared.dismissProgressLoading()
            
            guard let responseDetails = response .dictionary else{return}
            
            if let message = responseDetails["message"]?.string {
                print(message as Any)
                print(responseDetails as Any)
                
                if responseDetails["code"] == "200"{
                    
                    let data = responseDetails["data"]?.dictionary
                    
                    self.orderId = data!["ID"]?.string
                    
                 //   self.checksumService()
         
                }
                    
                    
                else{
                    
                    SingleToneClass.shared.dismissProgressLoading()
                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message) { }
                }
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server problem") { }
            }
            
        }
        
        
        
    }
    
    
    
    func updateDate()  {

        let params = ["user_id":userId,"order_id":orderId!,"startdate":startDateTF.text!]
        print(params)
        
        Service.shared.POSTService(serviceType: API.updateDate, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            
            if responseDetails["code"] == "200" {
                
            let data = responseDetails["data"]?.dictionary
                
            let resultDate = data!["enddate"]?.string
           
                let dateFormatterGet = DateFormatter()
                dateFormatterGet.dateFormat = "yyyy-MM-dd HH:mm:ss"
                
                let dateFormatterPrint = DateFormatter()
                dateFormatterPrint.dateFormat = "dd-MM-yyyy"
                
                if let date = dateFormatterGet.date(from: resultDate!) {
                    self.endDateTF.text = dateFormatterPrint.string(from: date)
                 
                    print(self.endDateTF.text as Any)
                }
                
                
                
            self.itemTotalLbl.text = data!["amount"]?.string
            self.redeemLbl.text = data!["credits"]?.string
          
                
                
                if self.itemTotalLbl.text == "" {
                self.itemTotalLbl.text = "1200"
                }
                   
                self.itemTotalAmt = Int(self.itemTotalLbl.text!) ?? 1200
                
           
                self.creditsAmt = Int(self.redeemLbl.text!) ?? 0
                
                self.gstLbl.text = "\(self.gstAmt)"
                
                self.payAmt = (self.itemTotalAmt + self.gstAmt + self.steelBoxAmt)
                
                print(self.payAmt as Any)
                
                self.netPayableLbl.text = "\(self.payAmt)"
                self.payLbl.text = "\(self.payAmt)"
                
    
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
                SingleToneClass.shared.dismissProgressLoading(WithDelay: 5)
                
                
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
                
                
            }
        }
        
        
        
        
        
        
    }
  

    func checksumService () {
       // self.payLbl.text = "1"

        let params = ["user_id":userId,"mobile":mobileNo,"email":emailId,"order_id":orderId!,"amount":payLbl.text!]
            print(params)

        Service.shared.POSTService(serviceType: API.checksum, parameters: params ) { (response) -> (Void) in

            print(response)
            SingleToneClass.shared.dismissProgressLoading()

            if response != "unknown" {

            guard let responseDetails = response .dictionary else{return}


            if responseDetails["code"] == "200" {

                self.checksumValue = (responseDetails["checksum"]?.string)!

                let paytmData = responseDetails["patmdata"]?.dictionary

                self.midValue = paytmData?["MID"]?.string ?? "yduJpK07121855010845"
                print(self.midValue)
                self.callBackUrlValue = paytmData?["CALLBACK_URL"]?.string ?? "https://securegw.paytm.in/theia/paytmCallback?ORDER_ID="+self.orderId!

                print(self.callBackUrlValue)

                 SingleToneClass.shared.dismissProgressLoading()

                self.beginPayment()

            }else{
                let message = responseDetails["message"]?.string

                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }


                }
            }else{

                    SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Server Problem") { }
                }
        }


    }


    func beginPayment() {
     //   self.payLbl.text = "1"

        serv = serv.createProductionEnvironment()
        let type :ServerType = .eServerTypeProduction

        let order = PGOrder(orderID: orderId!, customerID: userId , amount: payLbl.text!, eMail: emailId , mobile: mobileNo )
        order.params = ["MID": midValue,
                        "ORDER_ID": orderId!,
                        "CUST_ID": userId,
                        "MOBILE_NO": mobileNo,
                        "EMAIL": emailId,
                        "CHANNEL_ID": "WAP",
                        "WEBSITE": "DEFAULT",
                        "TXN_AMOUNT": payLbl.text!,
                        "INDUSTRY_TYPE_ID": "Retail",
                        "CHECKSUMHASH": checksumValue,
                        "CALLBACK_URL": callBackUrlValue]

            print(order.params)


        self.txnController =  (self.txnController.initTransaction(for: order) as? PGTransactionViewController)!
        self.txnController.title = "Paytm Payments"
        self.txnController.setLoggingEnabled(true)

        if(type != ServerType.eServerTypeNone) {
            self.txnController.serverType = type;
        } else {
            return
        }

        self.txnController.merchant = PGMerchantConfiguration.defaultConfiguration()
        self.txnController.delegate = self
        self.navigationController?.pushViewController(self.txnController, animated: true)

    }


    func didFinishedResponse(_ controller: PGTransactionViewController, response responseString: String) {

        print(responseString)

        let msg : String = responseString
        print(msg)

        var titlemsg : String = ""

        if let data = responseString.data(using: String.Encoding.utf8) {
            do {
                if let jsonresponse = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String:Any] , jsonresponse.count > 0{
                    titlemsg = jsonresponse["STATUS"] as? String ?? ""
                    self.txnId = jsonresponse["TXNID"] as? String ?? "0"
                    self.txnAmount = jsonresponse["TXNAMOUNT"] as? String ?? "0"
                    self.txnDate = jsonresponse["TXNDATE"] as? String ?? ""

                }
            } catch {
                print("Something went wrong")
            }
        }

//        let actionSheetController: UIAlertController = UIAlertController(title: titlemsg , message: msg, preferredStyle: .alert)
//        let cancelAction : UIAlertAction = UIAlertAction(title: "OK", style: .cancel) {
//            action -> Void in
//
//
//
//        }
//        actionSheetController.addAction(cancelAction)
//        self.present(actionSheetController, animated: true, completion: nil)


        if titlemsg == "TXN_SUCCESS"{
            self.updateTransactionId()
        }else{
            controller.navigationController?.popViewController(animated: true)
        }

    }


    //this function triggers when transaction gets cancelled
    func didCancelTrasaction(_ controller : PGTransactionViewController) {
        controller.navigationController?.popViewController(animated: true)
    }
    //Called when a required parameter is missing.
    func errorMisssingParameter(_ controller : PGTransactionViewController, error : NSError?) {
        controller.navigationController?.popViewController(animated: true)
    }

    
    func updateTransactionId ()  {
        
        
        let params = ["user_id":userId,"mobile":mobileNo,"order_id":orderId!,"TXNID":txnId,"TXNAMOUNT":txnAmount,"TXNDATE":txnDate]
        print(params)
        
        Service.shared.POSTService(serviceType: API.updateTransactionId, parameters: params ) { (response) -> (Void) in
            
            print(response)
            
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["messages"]?.string
            print(message as Any)
            if responseDetails["code"] == "200" {
                
              if let data = responseDetails["data"]?.dictionary {
                    
                    let startDate = data["startdate"]?.string
                    let meals = data["meals"]?.string
                    let endDate = data["enddate"]?.string
                    print(endDate as Any)
                
                    let tiffinBox = data["is_tiffin"]
                    let dateFormatterGet = DateFormatter()
                    dateFormatterGet.dateFormat = "yyyy-MM-dd HH:mm:ss"
                    
                    let dateFormatterPrint = DateFormatter()
                    dateFormatterPrint.dateFormat = "dd-MM-yyyy"
                    
                    if let date = dateFormatterGet.date(from: startDate!) {
                        let displaystartDate = dateFormatterPrint.string(from: date)
                        
                        UserDefaults.standard.set(displaystartDate, forKey: "StartDate")
                       
                    }
                
                if let date = dateFormatterGet.date(from: endDate!) {
                    let displaystartDate = dateFormatterPrint.string(from: date)

                    UserDefaults.standard.set(displaystartDate, forKey: "EndDate")

                }
         
                 UserDefaults.standard.set(meals, forKey: "Meals")
                 UserDefaults.standard.set(tiffinBox, forKey: "TiffinBox")
                
                }
                
                
                
                
                if let userdata = responseDetails["userdata"]?.dictionary{
                    let package = userdata["package"]?.string
                    UserDefaults.standard.set(package, forKey: "Package")
                }
                
                let vc=self.storyboard?.instantiateViewController(withIdentifier: "successVC")as! successVC
           
                self.navigationController?.pushViewController(vc, animated: true)
                
                
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
                SingleToneClass.shared.dismissProgressLoading(WithDelay: 20)

            }else{
               
                
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
                
                
            }
        }
        
        
        
        
        
        
        
        
    }
    

    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        self.selectedTF = textField
        return true
        
    }
    
    
    
   
        
       
    }
    
    




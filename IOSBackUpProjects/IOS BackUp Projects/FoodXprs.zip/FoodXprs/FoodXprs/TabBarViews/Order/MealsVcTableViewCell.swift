//
//  MealsVcTableViewCell.swiftmeal
//  FoodXprs
//
//  Created by Raju Matta on 09/08/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit

class MealsVcTableViewCell: UITableViewCell {

    @IBOutlet weak var view: UIView!
    @IBOutlet weak var nameLbl: UILabel!
   
    @IBOutlet weak var buttonImage2: UIButton!
    @IBOutlet weak var buttonImage1: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
      //  view.layer.cornerRadius = 55
       view.layer.cornerRadius = buttonImage1.frame.size.width / 2
       buttonImage1.layer.cornerRadius = buttonImage1.frame.size.width / 2
        buttonImage2.layer.cornerRadius = buttonImage2.frame.size.width / 2
        buttonImage1.contentVerticalAlignment = .fill
        buttonImage2.contentHorizontalAlignment = .fill
      
       // buttonImage1.layer.cornerRadius = 40
        buttonImage1.clipsToBounds = true
       // buttonImage2.layer.cornerRadius = 40
        buttonImage2.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func btn2(_ sender: UIButton) {
        
            self.buttonImage1.isHidden = false
            self.buttonImage2.isHidden = true

    }
    
    @IBAction func btn1(_ sender: UIButton) {
        
        buttonImage2.isHidden = false
        buttonImage1.isHidden = true
    }
}

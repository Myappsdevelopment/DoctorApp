//
//  accountEditVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 19/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import Crashlytics

class accountEditVC: UIViewController {

   
    @IBOutlet weak var emailTF: TextField!
    @IBOutlet weak var mobileNoTF: TextField!
    @IBOutlet weak var view2: UIView!

    
    @IBOutlet weak var addressTF: TextField!
    
    @IBOutlet weak var updateBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        self.emailTF.text = UserDefaults.standard.string(forKey: "emailId")
        self.mobileNoTF.text = UserDefaults.standard.string(forKey: "mobile")
        self.addressTF.text = UserDefaults.standard.string(forKey: "Address")
        
        let imgBack = UIImage(named: "Arrow")
        
        navigationController?.navigationBar.backIndicatorImage = imgBack
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = imgBack
        
        navigationItem.leftItemsSupplementBackButton = true
        navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        self.navigationController?.isNavigationBarHidden = false
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .white

         updateBtn.layer.cornerRadius = 10
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
        
        
      
        // Do any additional setup after loading the view.
    }
    
   
    
    @IBAction func update(_ sender: Any) {
        
        if !mobileNoTF.isValidMobileNumberTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter 10 digit mobile number") {
                self.mobileNoTF.becomeFirstResponder()
            }
        }else if !addressTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter the Address") {
                self.addressTF.becomeFirstResponder()
                
            }
            
        } else {

            SingleToneClass.shared.showProgressLoading(title: "Please wait...")
            updateAddress()
        }
        
    }
   

    func updateAddress()  {
        
        let userId =  UserDefaults.standard.object(forKey: "UserId") as! String
        let params = ["user_id":userId,"address":addressTF.text!,"mobile":mobileNoTF.text!]
        print(params)
        
        Service.shared.POSTService(serviceType: API.updateAddress, parameters: params ) { (response) -> (Void) in
            
            print(response)
             SingleToneClass.shared.dismissProgressLoading()
            guard let responseDetails = response .dictionary else{return}
            
            let message = responseDetails["message"]?.string
            print(message as Any)
            
            if responseDetails["code"] == "200" {
                
                let data = responseDetails["data"]?.dictionary
                
                let address = data!["address"]?.string
                let mobile = data!["mobile"]?.string
                
                 UserDefaults.standard.set(address, forKey: "Address")
                 UserDefaults.standard.set(mobile, forKey: "mobile")
                
                
                self.navigationController?.popViewController(animated: true)
                
                
                
//                let mobile = data!["mobile"]?.string
//                //
//                //                let responseNumber = responseDetails["password"]?.string
//                //
//                //                DetailsStore.forgotDetails = responseNumber
//                //                print(DetailsStore.forgotDetails as Any)
//
//                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
//                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "otpVC") as! otpVC
//                nextViewController.userId = id
//                nextViewController.mobileNo = mobile
//
//                self.present(nextViewController, animated:true, completion:nil)
                SingleToneClass.shared.dismissProgressLoadingWithSucess(message: message!)
                SingleToneClass.shared.dismissProgressLoading(WithDelay: 10)
            }else{
                
                SingleToneClass.shared.dismissProgressLoading()
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: message!) { }
                
                
            }
        }
        
        
        
        
        
        
        
        
    }
    
    
    

}

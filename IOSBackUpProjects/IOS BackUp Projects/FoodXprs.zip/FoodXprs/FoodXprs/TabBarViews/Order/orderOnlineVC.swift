//
//  orderViewVC.swift
//  FoodXprs
//
//  Created by Karthik Varkola on 22/07/19.
//  Copyright © 2019 MAD. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift


class orderOnlineVC: UIViewController,UIPickerViewDelegate, UIPickerViewDataSource,UITextFieldDelegate {

   
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var nameLbl: UIBarButtonItem!
    @IBOutlet weak var view2: UIView!
    
    @IBOutlet weak var sideMenu: UIBarButtonItem!
    @IBOutlet weak var locationTF: TextFieldHelper!
    
    @IBOutlet weak var btn_next: UIButton!
    
    @IBOutlet weak var NameTF: TextFieldHelper!
    
    @IBOutlet weak var adressTF: TextFieldHelper!
    
    @IBOutlet weak var mobileNoTF: TextFieldHelper!
    
    @IBOutlet weak var dateTF: TextField!
    
    
    let datepicker=UIDatePicker()
    let currentDate = Date()
    let finalFormatter = DateFormatter()
    
    let picker = UIPickerView()
    var selectedTF = UITextField()
    let toolBar = UIToolbar()
    
    
    let citySelection = ["Hitech City", "Madhapur", "Kavuri Hills", "Kondapur", "Gachibowli", "Jubilee Hills Rd.No.01", "Jubilee Hills Rd.No.10", "Jubilee Hills Rd.No.36", "KPHB Colony"]
    
   
  var getTag:Int?
    
    override func viewWillAppear(_ animated: Bool) {
         self.tabBarController?.tabBar.isHidden = false
        if UserDefaults.standard.string(forKey: "UserId") != nil {
            
            self.nameLbl.title = UserDefaults.standard.string(forKey: "userName")
            self.NameTF.text = UserDefaults.standard.string(forKey: "userName")
            self.mobileNoTF.text = UserDefaults.standard.string(forKey: "mobile")
            self.adressTF.text = UserDefaults.standard.string(forKey: "Address")
            
            
            //  print(self.adressTF.text as Any)
            self.view2.isHidden = false
            self.view1.isHidden = true
            
        }else{
            
            self.nameLbl.title = "Login"
            self.view2.isHidden = true
            self.view1.isHidden = false
            
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(DetailsStore.getTag as Any)

       
        
        
        
        
        btn_next.layer.cornerRadius = 10
        
        self.navigationController?.isNavigationBarHidden = false
         self.tabBarController?.tabBar.isHidden = false
       
        
        sideMenu.target = revealViewController()
        sideMenu.action = #selector(SWRevealViewController.revealToggle(_:))
        view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        // Do any additional setup after loading the view.
        
        
        if SingleToneClass.shared.isInternetAvailable()==false{
            SingleToneClass.shared.showValidationAlert(target: self, title: "No Internet Connection", message:  "") {
                
            }
        }
        
        locationTF.delegate = self
        dateTF.delegate = self
        createPicker()
    }
    

    

    
    
    @IBAction func Edit(_ sender: Any) {
        
        
        let storyBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let gotoPickLocation = storyBoard.instantiateViewController(withIdentifier: "accountEditVC") as! accountEditVC
       
        self.navigationController?.pushViewController(gotoPickLocation, animated: true)
     
        
        
    }
    


    @IBAction func btn_tappedNext(_ sender: UIButton) {
        

        if !NameTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter UserName") {
                self.NameTF.becomeFirstResponder()
            }
        }   else if !mobileNoTF.isValidMobileNumberTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter 10 digit mobile number") {
                self.mobileNoTF.becomeFirstResponder()
            }
        }   else if !locationTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Valid Location") {
                self.locationTF.becomeFirstResponder()
            }
        }    else if !adressTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please enter Valid Address") {
                self.adressTF.becomeFirstResponder()
            }
        } else if !dateTF.isValidTextField() {
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please Select Date") {
                self.adressTF.becomeFirstResponder()
            }
        } else {
            
            
            
            
        SingleToneClass.shared.showProgressLoading(title: "Please wait...")
            
            if DetailsStore.selectedStatus == true{
            DetailsStore.selectedStatus = true
                 DetailsStore.backStatus = false
            }
           
        
        let vc=self.storyboard?.instantiateViewController(withIdentifier: "mealVC")as! mealVC
            
           // vc.getTag = getTag
            vc.location = locationTF.text
            
        self.navigationController?.pushViewController(vc, animated: true)
            
        }
    }
    
    
    @IBAction func loginBtn(_ sender: Any) {
        
        
        if nameLbl.title == "Login" {
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "loginVc") as! loginVc
            self.present(nextViewController, animated:true, completion:nil)
        }
        
        
        
    }
    
//    func dateValidation ()  {
//        let calendar = NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian);
//        let weekDay = calendar?.component(.weekday, from:datepicker.date)
//        if weekDay == 1 || weekDay == 7 {
//            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select From Monday") {
//                self.dateTF.text = ""
//
//            }
//    }
//
//    }
    
    
    
    
    func createPicker() {
    
    picker.delegate = self
    picker.dataSource = self
    
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        
        
        datepicker.datePickerMode = .date
        datepicker.setDate(Date(), animated: true)
    
    
    let pickerView = picker
    pickerView.backgroundColor = .white
    pickerView.showsSelectionIndicator = true
    
    
    toolBar.barStyle = UIBarStyle.default
    toolBar.isTranslucent = true
    toolBar.sizeToFit()
    
    let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action:#selector(donePicker))
    doneButton.tintColor = UIColor.black
    let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
    let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action:#selector(canclePicker))
    cancelButton.tintColor = UIColor.black
    //datepicker.addTarget(self, action: #selector(datePickerValueChange), for:.valueChanged )
    toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
    toolBar.barTintColor = .white
    

        let calendar = NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian);
        
        let components = calendar?.components([NSCalendar.Unit.year,NSCalendar.Unit.month,NSCalendar.Unit.day,NSCalendar.Unit.hour,NSCalendar.Unit.minute], from: currentDate )
        
        let maximumYear = (components?.year)!
        print(maximumYear)
        let maximumMonth = (components?.month)!
        let maximumDay = (components?.day)!
        
        let comps = NSDateComponents();
        comps.year = +maximumYear
        comps.month = +maximumMonth
        comps.day = +maximumDay
        print(comps.day)
        
//        var thirtyDaysfromNow: Date {
//            return (Calendar.current as NSCalendar).date(byAdding: .day, value: 30, to: Date(), options: [])!
//        }
//
        
       
        
        var nextDay: Date {
            return (Calendar.current as NSCalendar).date(byAdding: .day, value: 2, to: Date(), options: [])!
        }
        var fridayDay: Date {
            return (Calendar.current as NSCalendar).date(byAdding: .day, value: 3, to: Date(), options: [])!
        }
        var thrusdayDay: Date {
            return (Calendar.current as NSCalendar).date(byAdding: .day, value: 4, to: Date(), options: [])!
        }
        
        
        let weekDay = calendar?.component(.weekday, from: currentDate)
       
        if weekDay == 5 {
            self.dateTF.text = dateFormatter.string(from: thrusdayDay)
            DetailsStore.saveDate = self.dateTF.text!
        }else if weekDay == 6 {
            self.dateTF.text = dateFormatter.string(from: fridayDay)
            DetailsStore.saveDate = self.dateTF.text!
        }else{
            self.dateTF.text = dateFormatter.string(from: nextDay)
            DetailsStore.saveDate = self.dateTF.text!
        }
        
    
        self.locationTF.inputView = pickerView
        self.locationTF.inputAccessoryView = toolBar
    
    
       // datepicker.maximumDate = nextDay
        datepicker.minimumDate = nextDay
        
        
        self.dateTF.inputView = datepicker
        self.dateTF.inputAccessoryView = toolBar
        
    
    }
    
    
    
    
    @objc func donePicker() {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
    

        if selectedTF == self.dateTF {
            
            let calendar = NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian);
            let weekDay = calendar?.component(.weekday, from:datepicker.date)
            if weekDay == 1 || weekDay == 7 {
                SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select From Monday To Friday") {
                    //self.dateTF.text = ""
                }
            }else{
                self.dateTF.text = dateFormatter.string(from: datepicker.date)
                self.dateTF.resignFirstResponder()
            }
      // self.dateTF.text = dateFormatter.string(from: datepicker.date)
            
        }
        
        if selectedTF == self.locationTF{
            self.locationTF.text = citySelection[picker.selectedRow(inComponent: 0)]
            self.locationTF.resignFirstResponder()
        }
    }
    
    @objc func canclePicker() {
        
        self.selectedTF.resignFirstResponder()
        
    }
    
    
   func cutOffTime(datePickerDate: Date) {
        
      //  var DayExist:Bool
        // let today = NSDate()
        
        let calendar =
            NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian)
        let components = calendar!.components([.weekday], from: currentDate)
        
        if components.weekday == 1 {
            print("Sunday")
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select From Monday To Friday") { }
           // DayExist = false
        } else if components.weekday == 7{
            print("Saturday")
            SingleToneClass.shared.showValidationAlert(target: self, title: "Alert !", message: "Please select From Monday To Friday") { }
        }
          //  DayExist = false
//        } else{
//            print("It's not Saturday and  Sunday ")
//
//
//            DayExist = true
//        }
//        print("weekday :\(String(describing: components.weekday)) ")
//        return DayExist
    }
    
    
    
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if selectedTF == self.locationTF {
            return citySelection.count
        }else {
            return 0
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        
        if selectedTF == self.locationTF {
            return citySelection[row]
        }else {
            return [String]()[row]
        }
        
    }
    
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        self.selectedTF = textField
        return true
        
    }
    
    
}
